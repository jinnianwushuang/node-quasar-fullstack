/*
 * @Date           : 2020-09-13 01:00:30
 * @FilePath       : /node-quasar-fullstack/src/pages/operatelog/mock/index.js
 * @Description    :
 */

let obj = {
  title: "quasar 学习",
  description: "我教我的 沙雕 老婆 学习前端",
  published: true,
  createdAt: "2020-09-12T15:59:10.360Z",
  updatedAt: "2020-09-12T15:59:10.360Z",
  id: "5f5cf04eebcd17489cdc3dce"
};
