/*
 * @Date           : 2020-10-15 00:58:40
 * @FilePath       : /backend-web/src/config/menu.js
 * @Description    : 
 */

const menu_data = [
  {
    title: '操作日志',
    path: 'operatelog',
    name:"operatelog",
  },
  {
    title: '异常日志',
    path: 'exceptionLog',
    name:"exceptionLog",
  },
  {
    title: 'TG业务',
    path: 'tgbusiness',
    name:"tgbusiness",
  },

];
export default menu_data