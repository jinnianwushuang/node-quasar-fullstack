package com.account.move.service.impl;


import com.account.move.entity.log.SystemExceptionLog;
import com.account.move.entity.log.SystemOperateLogEntity;
import com.account.move.service.ISystemLogService;
import com.account.move.utils.NetWorkUtils;
import com.account.move.vo.base.BasePage;
import com.account.move.vo.log.SystemLogRequestVo;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import java.util.List;

@Slf4j
@Service
public class SystemLogServiceImpl implements ISystemLogService {

    @Autowired
    MongoTemplate mongoTemplate;

    /**
     * @return org.springframework.data.domain.Page
     * @Author
     * @Description 分页条件查询系统正常操作日志
     * @Date 2021/6/3
     * @Param [vo]
     **/
    @Override
    public Page<SystemOperateLogEntity> querySystemOperationLog(SystemLogRequestVo vo) {
        Query query = new Query();
        if (!StringUtils.isEmpty(vo.getUserId())) {
            query.addCriteria(Criteria.where("userId").is(vo.getUserId()));
        }
        if (!StringUtils.isEmpty(vo.getStartTime()) && !StringUtils.isEmpty(vo.getEndTime())) {
            query.addCriteria(Criteria.where("operationTime").gte(vo.getStartTime()).lte(vo.getEndTime()));
        }
        if (!StringUtils.isEmpty(vo.getModuleCode())) {
            query.addCriteria(Criteria.where("moduleCode").is(vo.getModuleCode()));
        }
        if (!StringUtils.isEmpty(vo.getOperationCode())) {
            query.addCriteria(Criteria.where("operationCode").is(vo.getOperationCode()));
        }
        query.addCriteria(Criteria.where("serverUrl").is(NetWorkUtils.serverUrl));

        long count = mongoTemplate.count(query, SystemOperateLogEntity.class);
        Pageable pageable = PageRequest.of(Integer.parseInt(String.valueOf(vo.getPage().getCurrent() - 1)), Integer.parseInt(String.valueOf(vo.getPage().getSize())));
        query.with(Sort.by(Sort.Order.desc("operationTime")));
        List<SystemOperateLogEntity> systemOperateLogEntities = mongoTemplate.find(query.with(pageable), SystemOperateLogEntity.class);
        BasePage page = vo.getPage();
        page.setTotal(count);
        page.setRecords(systemOperateLogEntities);
        return page;
    }


    /**
     * @return org.springframework.data.domain.Page
     * @Author
     * @Description 分页条件查询系统异常操作日志
     * @Date 2021/6/3
     * @Param [vo]
     **/
    @Override
    public Page querySystemException(SystemLogRequestVo vo) {
        Query query = Query.query(Criteria.where("_id").exists(true));
        if (!StringUtils.isEmpty(vo.getUserId())) {
            query.addCriteria(Criteria.where("userId").is(vo.getUserId()));
        }
        if (!StringUtils.isEmpty(vo.getStartTime()) && !StringUtils.isEmpty(vo.getEndTime())) {
            query.addCriteria(Criteria.where("operationTime").gte(vo.getStartTime()).lte(vo.getEndTime()));
        }
        query.addCriteria(Criteria.where("serverUrl").is(NetWorkUtils.serverUrl));
        Pageable pageable = PageRequest.of(Integer.parseInt(String.valueOf(vo.getPage().getCurrent() - 1)), Integer.parseInt(String.valueOf(vo.getPage().getSize())));
        query.with(Sort.by(Sort.Order.desc("operationTime")));
        List<SystemExceptionLog> systemExceptionLogs = mongoTemplate.find(query.with(pageable), SystemExceptionLog.class);
        BasePage page = vo.getPage();
        page.setTotal(mongoTemplate.count(query, SystemExceptionLog.class));
        page.setRecords(systemExceptionLogs);
        return page;
    }


}
