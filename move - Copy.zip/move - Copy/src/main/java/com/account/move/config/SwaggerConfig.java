package com.account.move.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import springfox.documentation.builders.ApiInfoBuilder;
import springfox.documentation.builders.ParameterBuilder;
import springfox.documentation.builders.PathSelectors;
import springfox.documentation.builders.RequestHandlerSelectors;
import springfox.documentation.schema.ModelRef;
import springfox.documentation.service.ApiInfo;
import springfox.documentation.service.Parameter;
import springfox.documentation.spi.DocumentationType;
import springfox.documentation.spring.web.plugins.Docket;
import springfox.documentation.swagger2.annotations.EnableSwagger2;

import java.util.ArrayList;
import java.util.List;

/**
 * @ClassNmae SwaggerConfig
 * @Description Swagger配置
 * @Author writer
 * @Date 2020/4/22  10:37
 * http://localhost:port/swagger-ui.html
 **/
@Configuration
@EnableSwagger2
public class SwaggerConfig {

    @Value("${swagger.enable}")
    private Boolean enable;

    @Bean
    public Docket createRestApi() {

        ParameterBuilder ticketPar = new ParameterBuilder();
        List<Parameter> pars = new ArrayList<>();
        /*** Token 以及Authorization 为自定义的参数，session保存的名字是哪个就可以写成那个 ***/
        ticketPar.name(SystemUserSomeSegment.token).description("user ticket")
                /*** header中的ticket参数非必填，传空也可以 ***/
                .modelRef(new ModelRef("string")).parameterType("header")
                .required(false).build();
        /*** 根据每个方法名也知道当前方法在设置什么参数 ***/
        pars.add(ticketPar.build());

        return new Docket(DocumentationType.SWAGGER_2)
                .enable(enable)
                .apiInfo(apiInfo())
                .select()
                .apis(RequestHandlerSelectors.basePackage("com.account.move"))
                .paths(PathSelectors.any())
                .build().globalOperationParameters(pars);
    }

    /**
     * 项目信息
     */
    private ApiInfo apiInfo() {
        return new ApiInfoBuilder()
                .title("操作控制台接口")
                .version("1.0")
                .build();
    }

}
