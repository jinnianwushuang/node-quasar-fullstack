package com.account.move.vo.telegrambusiness;

import com.account.move.vo.base.BasePage;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.NotNull;

@Data
public class QueryGroupVo {

    @ApiModelProperty("分页参数")
    @NotNull(message = "分页参数不能为空")
    BasePage page;

    @ApiModelProperty("被查询的群组名称关键字")
    String title;

}
