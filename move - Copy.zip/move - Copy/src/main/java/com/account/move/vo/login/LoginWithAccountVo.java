package com.account.move.vo.login;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@Data
public class LoginWithAccountVo {

    private String account;

    @ApiModelProperty("密码.明文密码的sha1值")
    private String password;
}
