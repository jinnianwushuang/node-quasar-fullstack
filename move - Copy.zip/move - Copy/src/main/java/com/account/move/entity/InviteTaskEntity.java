package com.account.move.entity;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.util.List;

@Data
public class InviteTaskEntity {

    @ApiModelProperty("群组id_yyyy_mm_dd_hh")
    public String id;

    @ApiModelProperty("源聊天id")
    public Long srcChatId;

    @ApiModelProperty("源聊天群标题")
    public String srcChatTitle;

    @ApiModelProperty("目标聊天id")
    public Long dstChatId;

    @ApiModelProperty("目标天群标题")
    public String dstChatTitle;

    @ApiModelProperty("tg显示的群组人数")
    public Integer memberCount;

    @ApiModelProperty("实际搜索出来的群组人数")
    public Integer actualMemberCount;

    @ApiModelProperty("邀请已经处理的群组人数")
    public Integer invitedUserNumber;

    @ApiModelProperty("剩余待邀请人数(memberCount - invitedUserNumber)")
    public Integer leftUserNumber;

    @ApiModelProperty("邀请执行次数")
    public Integer step;

    @ApiModelProperty("创建时间戳")
    public Long createTimeStamp;

    public List<InviteOperationRecord> inviteOperationRecord;

    /*** 每次定时任务邀请的用户个数    ***/
    public static Integer userNumberPerInvite = 20;
}
