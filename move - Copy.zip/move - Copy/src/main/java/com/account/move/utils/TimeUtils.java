package com.account.move.utils;

import javafx.util.Pair;
import lombok.extern.slf4j.Slf4j;

import java.text.SimpleDateFormat;
import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.Date;

/**
 * @ClassNmae TimeUtils
 * @Description
 * @Author writer
 * @Date 2021/2/15  18:30
 **/
@Slf4j
public class TimeUtils {

    /*** 10天共有多少秒 ***/
    private final static Long second10Days = 10 * 24 * 3600L;

    /*** 12 小时有多少毫秒 ***/
    private final static Long second12Hour = 12 * 3600L;

    /*** 2天共有多少毫秒 ***/
    private final static Long milliSecondTwoDays = 2 * 24 * 3600 * 1000L;

    /*** 7天共有多少毫秒 ***/
    private final static Long milliSecondSevenDays = 7 * 24 * 3600 * 1000L;

    /*** 7天共有多少毫秒 ***/
    private final static Long milliSecond15Days = 15 * 24 * 3600 * 1000L;

    /*** 一天有多少毫秒 ***/
    private final static Long milliSecondOneDay = 24 * 3600 * 1000L;

    /*** 一小时有多少毫秒 ***/
    private final static Long milliSecondOneHour = 1 * 3600 * 1000L;

    /*** 12 小时有多少毫秒 ***/
    private final static Long milliSecond12Hour = 12 * 3600 * 1000L;

    /*** 18 小时有多少毫秒 ***/
    private final static Long milliSecond18Hour = 18 * 3600 * 1000L;

    /*** 2分钟有多少毫秒 ***/
    private final static Long milliSecondTwoMinutes = 2 * 60 * 1000L;

    /*** 5分钟内多少毫秒 ***/
    public static final Long milliSecondPerFiveMinutes = 5 * 60 * 1000L;

    /*** 15分钟内多少毫秒 ***/
    public static final Long milliSecondPerQuarter = 15 * 60 * 1000L;

    /*** 一年共有多少毫秒,按照365天计算 ***/
    public static final Long milliSecond365Days = 31536000000L;

    /*** 一个月共有多少毫秒  ***/
    public static final Long milliSecondOneMonth = 31536000000L / 12;

    /*** 两小时内多少毫秒  ***/
    public static final Long milliSecondTwoHours = 2 * 60 * 60 * 1000L;


    /**
     * 计算15分钟有多少毫秒
     *
     * @param
     * @return java.lang.Long
     * @Description //TODO
     * @Date
     * @author writer
     **/
    public static Long getMilliSecondPerQuarter() {
        return milliSecondPerQuarter;
    }

    /**
     * 计算两小时有多少毫秒
     *
     * @param
     * @return java.lang.Long
     * @Description 计算两小时有多少毫秒
     * @Date
     * @author writer
     **/
    public static Long getMilliSecondTwoHours() {
        return milliSecondTwoHours;
    }

    /**
     * 计算指定时间戳需要分配在那个15分钟的时间槽内
     *
     * @param timeStamp 精确到毫秒时间戳
     * @return java.lang.Long
     * @Description
     * @Date
     * @author writer
     **/
    public static Long getMilliSecondPerQuarter(Long timeStamp) {
        return (timeStamp / milliSecondPerQuarter) * milliSecondPerQuarter;
    }

    /**
     * 查询两天共有多少毫秒
     *
     * @param
     * @return java.lang.Long
     * @Description
     * @Date
     * @author writer
     **/
    public static Long getMilliSecondTwoDays() {
        return milliSecondTwoDays;
    }

    /**
     * 查询 7 天共有多少毫秒
     *
     * @return java.lang.Long
     * @Description
     * @Date
     * @author writer
     **/
    public static Long getMilliSecondSevenDays() {
        return milliSecondSevenDays;
    }

    /**
     * 查询 15 天共有多少毫秒
     *
     * @return java.lang.Long
     * @Description
     * @Date
     * @author writer
     **/
    public static Long getMilliSecond15Days() {
        return milliSecond15Days;
    }

    /**
     * 查询 365 天共有多少毫秒
     *
     * @return java.lang.Long
     * @Description
     * @Date
     * @author writer
     **/
    public static Long getMilliSecond365Days() {
        return milliSecond365Days;
    }


    /**
     * @param
     * @return java.lang.Long 10天的秒数
     * @description 获取 10 天的秒数
     * @author liubaohong
     * @date 2021/5/7
     */
    public static Long getSecond10Days() {
        return second10Days;
    }

    /**
     * @param
     * @return java.lang.Long 12小时的秒数
     * @description 获取 12 小时的秒数
     * @author liubaohong
     * @date 2021/5/7
     */
    public static Long getSecond12Hour() {
        return second12Hour;
    }

    /**
     * 查询2分钟共有多少毫秒
     *
     * @param
     * @return java.lang.Long
     * @Description
     * @Date
     * @author writer
     **/
    public static Long getMilliSecondTwoMinutes() {
        return milliSecondTwoMinutes;
    }

    /**
     * @param stamp 时间戳 ，精确到毫秒
     * @return java.lang.String  yyyy-mm-dd
     * @Description 时间戳转换日期
     * @Date 2021/2/13 17:05
     * @Author writer
     */
    public static String stampToTimeYmdWithUnderline(Long stamp) {
        String sd = "";
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        // 时间戳转换日期
        sd = sdf.format(new Date(stamp));
        return sd;
    }


    public static String stampToTimeYmWithUnderline(Long stamp) {
        String sd = "";
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM");
        // 时间戳转换日期
        sd = sdf.format(new Date(stamp));
        return sd;
    }

    public static String stampToTimeYWithUnderline(Long stamp) {
        String sd = "";
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy");
        // 时间戳转换日期
        sd = sdf.format(new Date(stamp));
        return sd;
    }

    /**
     * 吧指定时间戳的日期转换为 yymmddhhmm 的格式,精确到分
     *
     * @param stamp 时间戳
     * @return java.lang.String
     * @Description //TODO
     * @Date
     * @author writer
     **/
    public static String stampToTimeYmdHm(Long stamp) {
        String sd = "";
        SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmm");
        // 时间戳转换日期
        sd = sdf.format(new Date(stamp));
        return sd;
    }

    /**
     * 吧指定时间戳的日期转换为 yymmddhhmmss 的格式,精确到分
     *
     * @param stamp 时间戳
     * @return java.lang.String
     **/
    public static String stampToTimeYmdHms(Long stamp) {
        String sd = "";
        SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmmss");
        // 时间戳转换日期
        sd = sdf.format(new Date(stamp));
        return sd;
    }

    public static String stampToTimeYmdHmsWithUnderLine(Long stamp) {
        String sd = "";
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd hh-mm-ss");
        // 时间戳转换日期
        sd = sdf.format(new Date(stamp));
        return sd;
    }

    public static String stampToTimeYmdHmsWithUnderLine2(Long stamp) {
        String sd = "";
        SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd_hhmmss");
        // 时间戳转换日期
        sd = sdf.format(new Date(stamp));
        return sd;
    }

    /**
     * 把指定时间戳的日期转换为 yymmddhh 的格式,精确到小时
     *
     * @param stamp 时间戳
     * @return java.lang.String
     * @Description
     * @Date
     * @author writer
     **/
    public static String stampToTimeYmdh(Long stamp) {
        String sd = "";
        SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHH");
        // 时间戳转换日期
        sd = sdf.format(new Date(stamp));
        return sd;
    }

    public static String stampToTimeYearMonthWithUnderLine(Long stamp) {
        String sd = "";
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM");
        // 时间戳转换日期
        sd = sdf.format(new Date(stamp));
        return sd;
    }

    /**
     * 从时间戳获取年、月
     *
     * @param stamp 时间戳
     * @return 年、月
     */
    public static Pair<Integer, Integer> stampToYm(Long stamp) {
        LocalDateTime date = LocalDateTime.ofInstant(Instant.ofEpochMilli(stamp), ZoneId.systemDefault());
        return new Pair<>(date.getYear(), date.getMonth().getValue());
    }

    /**
     * 计算今天的第一秒的时间戳(精确到毫秒)
     *
     * @param
     * @return java.lang.Long
     * @Description
     * @Date
     * @author writer
     **/
    public static Long getTodayTimeStamp() {
        Long now = System.currentTimeMillis();
        return (now / milliSecondOneDay) * milliSecondOneDay;
    }

    public static Long getMilliSecondOneMonth() {
        return milliSecondOneMonth;
    }

    /**
     * 计算半个月共有多少天(30天算1个月)
     *
     * @param
     * @return java.lang.Integer
     * @Description
     * @Date
     * @author writer
     **/
    public static Integer getDayNumberForHalfMonth() {
        return 15;
    }

    /**
     * 获取一天内有多少毫秒
     *
     * @param
     * @return java.lang.Long
     * @Description
     * @Date
     * @author writer
     **/
    public static Long getMilliSecondOneDay() {
        return milliSecondOneDay;
    }

    /**
     * 获取一小时有多少毫秒
     *
     * @return java.lang.Long
     * @Description
     * @Date
     * @author writer
     **/
    public static Long getMilliSecondOneHour() {
        return milliSecondOneHour;
    }

    /**
     * 获取12小时有多少毫秒
     *
     * @return java.lang.Long
     * @Description
     * @Date
     * @author writer
     **/
    public static Long getMilliSecond12Hour() {
        return milliSecond12Hour;
    }

    /**
     * 获取18小时有多少毫秒
     *
     * @return java.lang.Long
     * @Description
     * @Date
     * @author writer
     **/
    public static Long getMilliSecond18Hour() {
        return milliSecond18Hour;
    }

    /**
     * 查询5分钟内有多少毫秒
     *
     * @param
     * @return java.lang.Long
     * @Description
     * @Date
     * @author writer
     **/
    public static Long getMilliSecondPerFiveMinutes() {
        return milliSecondPerFiveMinutes;
    }

    /**
     * 根据字符串的日期计算对应的时间戳
     * @Description
     * @Date
     * @param  dateString
     * @return java.lang.Long
     * @author writer
     **/
    public static Long getTimeStampByDate(String dateString) {
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        try {
            Date date = simpleDateFormat.parse(dateString);
            return date.getTime();
        }catch (Exception e) {
            log.error("时间转换时间戳出错:" + dateString, e.getMessage());
        }
        return 0L;
    }

    /**
     * 计算指定时间戳所在天的0点时间戳
     *
     * @param timeStamp 指定的时间戳
     * @return java.lang.Long
     * @Description //TODO
     * @Date
     * @author writer
     **/
    public static Long getZeroTimeStampByTimeStamp(Long timeStamp) {
        return (timeStamp / milliSecondOneDay) * milliSecondOneDay;
    }

    /**
     * @param timeStamp 时间戳
     * @return java.lang.Long 对齐后的时间戳
     * @description 将时间戳对齐到 5 分钟
     * @author liubaohong
     * @date 2021/5/28
     */
    public static Long alignToFiveMinutes(Long timeStamp) {
        return alignTimestamp(timeStamp, milliSecondPerFiveMinutes);
    }

    /**
     * @param timeStamp 时间戳
     * @return java.lang.Long 对齐后的时间戳
     * @description 将时间戳对齐到 15 分钟
     * @author liubaohong
     * @date 2021/5/28
     */
    public static long alignTo15Minutes(long timeStamp) {
        return alignTimestamp(timeStamp, milliSecondPerQuarter);
    }

    /**
     * @param timeStamp 时间戳
     * @return java.lang.Long 对齐后的时间戳
     * @description 将时间戳对齐到 1小时
     * @author liubaohong
     * @date 2021/5/28
     */
    public static long alignTo1Hour(long timeStamp) {
        return alignTimestamp(timeStamp, milliSecondOneHour);
    }

    /**
     * @param timestamp 时间戳
     * @param timeLen   要对齐的时长
     * @return java.lang.Long 对齐后的时间戳
     * @description 将时间戳对齐到 timeLen 毫秒
     * @author liubaohong
     * @date 2021/5/28
     */
    public static long alignTimestamp(long timestamp, long timeLen) {
        return (timestamp / timeLen) * timeLen;
    }

    /**
     * 根据时间字符串计算从当天 0 点开始的分钟数
     *
     * @param timeStr 时间字符串，格式为 HH:MM
     * @return
     */
    public static Integer calcMinutesByHHMM(String timeStr, int defaultVal) {
        String[] strArray = timeStr.split(":");
        if (strArray.length != 2) {
            return defaultVal;
        }
        return Integer.valueOf(strArray[0], 10) * 60 + Integer.valueOf(strArray[1], 10);
    }

    /**
     * 将从当天 0 点开始的分钟数转换为 HH:MM 格式的字符串
     *
     * @param time 从当天 0 点开始的分钟数
     * @return
     */
    public static String generateHHMMByMinutes(int time) {
        return String.format("%02d:%02d", time / 60, time % 60);
    }
}
