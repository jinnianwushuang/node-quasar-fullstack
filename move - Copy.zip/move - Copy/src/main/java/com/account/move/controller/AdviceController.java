package com.account.move.controller;



import com.account.move.config.ErrorCode;
import com.account.move.vo.R;
import lombok.extern.slf4j.Slf4j;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpServletRequest;

/**
 * @ClassNmae AdviceController
 * @Description 全局异常处理器
 * @Author writer
 * @Date 2020/4/21  17:52
 **/
@Slf4j
@ControllerAdvice
public class AdviceController {

    @ResponseBody
    @ExceptionHandler(value = MethodArgumentNotValidException.class)
    public R methodArgumentValid(HttpServletRequest req, MethodArgumentNotValidException e) {
        StringBuffer stringBuffer = new StringBuffer();
        /*** 按需重新封装需要返回的错误信息 ***/

        /*** 解析原错误信息，封装后返回，此处返回非法的字段名称，原始值，错误信息 ***/
        for (FieldError error : e.getBindingResult().getFieldErrors()) {
            stringBuffer.append("字段 ");
            stringBuffer.append(error.getField());
            stringBuffer.append(" 传值错误");
            stringBuffer.append(error.getDefaultMessage());
            stringBuffer.append(";");
        }
        return R.failed(stringBuffer.toString());
    }

    @ResponseBody
    @ExceptionHandler(value = Exception.class)
    public R defaultException(HttpServletRequest req, Exception e) {
        /*** 按需重新封装需要返回的错误信息 ***/
        log.info("操作操作报错:{}", e.getStackTrace());
        log.info("操作报错,错误信息:{}", e.getMessage());
        return R.failed(ErrorCode.SYSTEM_BUSY);
    }
}
