package com.account.move.vo.telegrambusiness;

import lombok.Data;

import java.util.List;

@Data
public class AddMultiUser {
    Long chatId;
    List<Long> userIds;
}
