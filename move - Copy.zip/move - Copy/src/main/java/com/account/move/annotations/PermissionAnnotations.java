package com.account.move.annotations;

import io.swagger.annotations.ApiModelProperty;

import java.lang.annotation.*;

/**
 * @author ：Guo Tao
 * @date ：Created in 2021/4/15 18:30
 * @description：操作权限注解
 * @modified By：
 * @version: 0.0.1
 */
@Documented
@Retention(RetentionPolicy.RUNTIME)
@Target({ElementType.METHOD})
public @interface PermissionAnnotations {

    /**
     * default extension name
     */
    @ApiModelProperty(value="需要的权限码")
    String permissionCode()  default "";
}
