package com.account.move.utils;


import com.account.move.entity.TokenEntity;
import com.account.move.entity.VerifyCodeEntity;

import java.util.concurrent.ConcurrentHashMap;

/**
 * @author writer
 * @title: TokenCollection
 * @projectName checkAccount
 * @description: 用户登录的token个管理容器
 * @date 2021/12/1414:57
 */
public class TokenCollection {

    /***  Map:  key: 管理员的token; value : userId;  ; ***/
    public static ConcurrentHashMap<String, Long> tokenMap = new ConcurrentHashMap<>();

    /***  Map:  key: 管理员的电话号码; value : TokenEntity;  ; ***/
    public static ConcurrentHashMap<String, VerifyCodeEntity> verifyCodeMap = new ConcurrentHashMap<>();

    /***  Map:  key: 管理员的id; value : 用户登录的token;  ; ***/
    public static ConcurrentHashMap<Long, String> uidToken = new ConcurrentHashMap<>();

    public void cleanExpireData() {
        /***  TODO  清理过期的 verifyCodeMap ***/

        /***  TODO  清理过期的 tokenMap ***/
    }



}
