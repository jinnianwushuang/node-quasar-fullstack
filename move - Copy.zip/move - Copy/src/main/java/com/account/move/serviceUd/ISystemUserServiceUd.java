package com.account.move.serviceUd;

import com.account.move.entity.SystemUser;

/**
 * @author writer
 * @title: ISystemUserService
 * @projectName checkAccount
 * @description:
 * @date 2021/12/1415:56
 */
public interface ISystemUserServiceUd extends IBaseFreshDataService {


    void addDefaultSystemUser();

    /***
     * @description: 根据id查询指定的系统管理员用户
     * @param
     * @return com.account.core.db.collect_user.entity.SystemUser
     * @throws
     * @author writer
     * @date 2021/12/14 16:07
     ****/
    SystemUser getUserById(Long userId);

    /***
     * @description: 根据电话号码查询指定的系统管理员用户
     * @param
     * @return com.account.core.db.collect_user.entity.SystemUser
     * @throws
     * @author writer
     * @date 2021/12/14 16:07
     ****/
    SystemUser getUserByTelephone(String telephone);

    /***
     * @description: 根据账号查询指定的系统管理员用户
     * @param
     * @return com.account.core.db.collect_user.entity.SystemUser
     * @throws
     * @author writer
     * @date 2021/12/14 16:07
     ****/
    SystemUser getUserByAccount(String account);

}
