package com.account.move.entity;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * @author writer
 * @title: TokenEntity
 * @projectName checkAccount
 * @description:
 * @date 2021/12/1415:11
 */
@Data
public class TokenEntity {

    @ApiModelProperty("用户id")
    private Long userId;

    @ApiModelProperty("过期时间戳(单位：毫秒)")
    private Long expireTime;

    public TokenEntity(Long userId, Long expireTime) {
        this.userId = userId;
        this.expireTime = expireTime;
    }
}
