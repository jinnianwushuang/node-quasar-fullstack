package com.account.move.annotations;

import io.swagger.annotations.ApiModelProperty;

import java.lang.annotation.*;

/**
 * @author ：Guo Tao
 * @date ：Created in 2021/4/15 18:30
 * @description：系统日志注解
 * @modified By：
 * @version: 0.0.1
 */
@Documented
@Retention(RetentionPolicy.RUNTIME)
@Target({ElementType.METHOD})
public @interface SystemLogType {

    /**
     * default extension name
     */
    @ApiModelProperty(value="模块码")
    String moduleCode() default "";

    /**
     * default extension name
     */
    @ApiModelProperty(value="模块名称")
    String moduleName() default "";

    /**
     * default extension name
     */
    @ApiModelProperty(value="操作码")
    String operationCode()  default "";

    /**
     * default extension name
     */
    @ApiModelProperty(value="操作名称")
    String operationName()  default "";
}
