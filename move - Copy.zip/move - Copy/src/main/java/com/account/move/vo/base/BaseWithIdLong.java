package com.account.move.vo.base;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.NotNull;
import java.io.Serializable;

/**
 * @ClassNmae BaseWithIdLong
 * @Description
 * @Author liubaohong
 * @Date 2021/6/7  17:51
 **/
@Data
public class BaseWithIdLong implements Serializable {

    @ApiModelProperty("需要指定的数据")
    @NotNull(message = "需要指定的数据不能为空")
    protected Long  id;
}
