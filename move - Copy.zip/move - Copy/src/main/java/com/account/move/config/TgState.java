package com.account.move.config;

import io.swagger.annotations.ApiModelProperty;

public enum TgState {

    @ApiModelProperty("AuthorizationStateReady")
    ONLINE(-1834871737,"已登陆"),


    @ApiModelProperty("AuthorizationStateWaitPhoneNumber")
    WAIT_PHONE_NUMBER (306402531,"待输入电话号码"),

    @ApiModelProperty("AuthorizationStateWaitCode")
    WAIT_VERIFY_CODE(52643073,"待输入验证码");

    /**
     * 枚举码值  AuthorizationStateWaitCode.CONSTRUCTOR
     */
    private Integer code;

    /**
     * 状态码的中文描述
     */
    private String description;

    private TgState(Integer code, String description) {
        this.code = code;
        this.description = description;
    }

    public Integer getCode() {
        return code;
    }

    public void setCode(int code) {
        this.code = code;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public static String getDescriptionByCode(int code) {
        for (TgState e : TgState.values()) {
             if(e.getCode().equals(code)) {
                 return e.description;
             }
        }
        return "unknown:" + code;
    }

}
