package com.account.move.utils;

import com.account.move.serviceUd.ISystemUserServiceUd;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import javax.annotation.PostConstruct;
import javax.servlet.http.HttpServletRequest;
import java.net.InetAddress;
import java.net.UnknownHostException;

/**
 * @ClassNmae NetWorkUtils
 * @Description 网络相关的工具类
 * @Author writer
 * @Date 2021/2/13  18:02
 **/
@Slf4j
@Component
public class NetWorkUtils {

    /*** 将ip地址的数字转换为字母的  数字 字母编码表(下标为数字) ***/
    static final char[] numberCodeMap = {'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j'};

    /*** 将ip地址的数字转换为字母的  字母 数字编码表(下标为字母的顺序值) ***/
    static final char[] codNumberMap = {'0', '1', '2', '3', '4', '5', '6', '7', '8', '9'};

    public static String serverPort;

    public static String serverIp;

    public static String serverUrl;

    @Autowired
    ISystemUserServiceUd systemUserServiceUd;

    @Value("${server.port}")
    private String port;

    @PostConstruct
    public void initial() {
        NetWorkUtils.serverPort = this.port;
        InetAddress address = null;
        try {
            address = InetAddress.getLocalHost();
        } catch (Exception e) {

        }
        NetWorkUtils.serverIp = address.getHostAddress();
        NetWorkUtils.serverUrl = NetWorkUtils.serverIp + ":" + NetWorkUtils.serverPort;
        systemUserServiceUd.addDefaultSystemUser();
    }


    /**
     * 将ip地址转换为编码
     *
     * @param ipAddress
     * @return java.lang.String
     * @Description
     * @Date
     * @author writer
     **/
    public static String convertIpAddressToCode(String ipAddress) {
        if (StringUtils.isEmpty(ipAddress)) {
            return "";
        }
        log.info("ip地址转换为编码：{}", ipAddress);
        String returnCode = "";
        int size = ipAddress.length();
        for (int i = 0; i < size; i++) {
            /***  character是一个数字型的字符 ***/
            char character = ipAddress.charAt(i);
            int index = character - '0';
            if ('.' == character) {
                returnCode = returnCode + "+";
                continue;
            }
            if (index < 10) {
                returnCode = returnCode + numberCodeMap[index];
            }
        }
        return returnCode;
    }

    /**
     * 将ip地址码 转换为ip地址
     *
     * @param ipAddressCode
     * @return java.lang.String
     * @Description
     * @Date
     * @author writer
     **/
    public static String convertCodeToIpAddress(String ipAddressCode) {
        if (StringUtils.isEmpty(ipAddressCode)) {
            return "";
        }
        log.info("编码转换为ip地址：{}", ipAddressCode);
        ipAddressCode = ipAddressCode.toLowerCase();
        String returnCode = "";
        int size = ipAddressCode.length();
        for (int i = 0; i < size; i++) {
            /***  character是一个字母型的字符,需要专业为ip地址 ***/
            char character = ipAddressCode.charAt(i);
            if ('+' == character) {
                returnCode = returnCode + ".";
                continue;
            }
            int index = character - 'a';
            if (index < 10) {
                returnCode = returnCode + codNumberMap[index];
            }
        }
        return returnCode;
    }


    /**
     * 查询访问句柄
     *
     * @param
     * @return java.lang.String
     * @Description
     * @Date
     * @author writer
     **/
    public static String getIpAddrByRequest() {
        ServletRequestAttributes attributes = (ServletRequestAttributes) RequestContextHolder.getRequestAttributes();
        HttpServletRequest request = attributes.getRequest();
        return getIpAddrByRequest(request);
    }

    /**
     * 根据指定的句柄查询访问的ip地址
     *
     * @param request
     * @return java.lang.String
     * @Description
     * @Date
     * @author writer
     **/
    public static String getIpAddrByRequest(HttpServletRequest request) {

        String ipAddress = request.getHeader("x-forwarded-for");
        if (ipAddress == null || ipAddress.length() == 0 || "unknown".equalsIgnoreCase(ipAddress)) {
            ipAddress = request.getHeader("Proxy-Client-IP");
        }
        if (ipAddress == null || ipAddress.length() == 0 || "unknown".equalsIgnoreCase(ipAddress)) {
            ipAddress = request.getHeader("WL-Proxy-Client-IP");
        }
        if (ipAddress == null || ipAddress.length() == 0 || "unknown".equalsIgnoreCase(ipAddress)) {
            ipAddress = request.getRemoteAddr();
            String localIp = "127.0.0.1";
            String localIpv6 = "0:0:0:0:0:0:0:1";
            if (ipAddress.equals(localIp) || ipAddress.equals(localIpv6)) {
                // 根据网卡取本机配置的IP
                InetAddress inet = null;
                try {
                    inet = InetAddress.getLocalHost();
                    ipAddress = inet.getHostAddress();
                } catch (UnknownHostException e) {
                    e.printStackTrace();
                }
            }
        }
        // 对于通过多个代理的情况，第一个IP为客户端真实IP,多个IP按照','分割
        String ipSeparate = ",";
        int ipLength = 15;
        if (ipAddress != null && ipAddress.length() > ipLength) {
            if (ipAddress.indexOf(ipSeparate) > 0) {
                ipAddress = ipAddress.substring(0, ipAddress.indexOf(ipSeparate));
            }
        }
        return ipAddress;
    }

    /**
     * 合并 url 连接
     *
     * @param domain 域名,不以"/"结尾
     * @param url    url路径
     * @return 完整的 url
     */
    public static String combineUrl(String domain, String url) {
        if (url.startsWith("/")) {
            return domain + url;
        } else {
            return domain + "/" + url;
        }
    }
}
