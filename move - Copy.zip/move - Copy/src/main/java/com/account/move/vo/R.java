
package com.account.move.vo;

import com.account.move.config.CommonConstants;
import com.account.move.config.ErrorCode;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.Accessors;

import java.io.Serializable;


/**
 * 响应信息主体
 *
 * @param <T>
 * @author lengleng
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Accessors(chain = true)
@ApiModel(description = "响应对象")
public class R<T> implements Serializable {

    private static final long serialVersionUID = 1L;

    @ApiModelProperty(value = "响应码", name = "code", required = true)
    private long code;

    @ApiModelProperty(value = "响应消息", name = "msg")
    private String msg;

    @ApiModelProperty(value = "响应需要携带的数据", name = "data")
    private T data;

    public boolean success() {
        return CommonConstants.SUCCESS == this.code;
    }

    public static <T> R<T> ok() {
        return restResult(null, CommonConstants.SUCCESS, null);
    }

    public static <T> R<T> ok(T data) {
        return restResult(data, CommonConstants.SUCCESS, "");
    }

    public static <T> R<T> ok(T data, String msg) {
        return restResult(data, CommonConstants.SUCCESS, msg);
    }

    public static <T> R<T> failed() {
        return restResult(null, CommonConstants.FAIL, "");
    }

    public static <T> R<T> failed(String msg) {
        return restResult(null, CommonConstants.FAIL, msg);
    }

    public static <T> R<T> failed(T data) {
        return restResult(data, CommonConstants.FAIL, null);
    }

    public static <T> R<T> failed(T data, String msg) {
        return restResult(data, CommonConstants.FAIL, msg);
    }

    public static <T> R<T> failed(long code, String msg, T data) {
        return restResult(data, code, msg);
    }

    public static <T> R<T> failed(ErrorCode code, T data) {
        return restResult(data, code.getCode(), code.getDescription());
    }

    public static <T> R<T> failed(ErrorCode code) {
        return restResult(null, code.getCode(), code.getDescription());
    }

    public static <T> R<T> failed(T data, ErrorCode code) {
        return restResult(data, code.getCode(), code.getDescription());
    }

    public static <T> R<T> result(boolean bResult) {
        return bResult ? ok() : failed();
    }

    private static <T> R<T> restResult(T data, long code, String msg) {
        R<T> r = new R<>();
        r.setCode(code);
        r.setData(data);
        r.setMsg(msg);
        return r;
    }
}

