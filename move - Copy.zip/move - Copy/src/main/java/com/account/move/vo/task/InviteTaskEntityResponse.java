package com.account.move.vo.task;

import com.account.move.entity.InviteTaskEntity;
import lombok.Data;

@Data
public class InviteTaskEntityResponse extends InviteTaskEntity {

    private boolean finish;

}
