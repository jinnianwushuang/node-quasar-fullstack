package com.account.move.service;


import com.account.move.vo.log.SystemLogRequestVo;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;

/**
 * @Author sk
 * @Description 分页条件查询系统正常操作日志
 * @Date 2021/6/3
 * @Param
 * @return
 **/
public interface ISystemLogService {

    /**
     * @return org.springframework.data.domain.Page
     * @Author
     * @Description 分页条件查询系统正常操作日志
     * @Date 2021/6/3
     * @Param [vo]   条件查询的vo
     **/
    Page querySystemOperationLog(SystemLogRequestVo vo);


    /**
     * @return org.springframework.data.domain.Page
     * @Author
     * @Description 分页条件查询系统异常操作日志
     * @Date 2021/6/3
     * @Param [vo]  条件查询的vo
     **/
    Page querySystemException(SystemLogRequestVo vo);


}
