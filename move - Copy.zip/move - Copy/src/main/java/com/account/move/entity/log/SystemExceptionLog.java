package com.account.move.entity.log;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * @author ：Guo Tao
 * @date ：Created in 2021/3/22 18:41
 * @description：系统操作异常的日志
 * @modified By：
 * @version: 0.0.1
 */
@Data
public class SystemExceptionLog {

    @ApiModelProperty("系统用户id")
    private Long userId;

    @ApiModelProperty("操作人员真实姓名")
    private String realName;

    @ApiModelProperty("操作人员账号")
    private String userName;

    @ApiModelProperty("失败的消息")
    private String errorMessage;

    @ApiModelProperty("方法名称")
    private String method;

    @ApiModelProperty("操作的参数")
    private String params;

    @ApiModelProperty("操作发生时的时间戳(精确到毫秒)")
    private Long operationTime;

    @ApiModelProperty("创建时间(yyyy-MM-dd-HH:mm:ss)")
    private String createDate;

    @ApiModelProperty("操作的url地址")
    private String operationUrl;

    @ApiModelProperty("操作者使用的ip")
    private String operationIp;

}
