package com.account.move.service.impl;

import com.account.move.entity.InviteTaskEntity;
import com.account.move.service.IInviteTaskService;
import com.account.move.vo.base.BasePage;
import com.account.move.vo.task.InviteTaskRequestVo;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.mongodb.client.result.DeleteResult;
import lombok.extern.slf4j.Slf4j;
import org.drinkless.tdlib.TdApi;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import java.util.List;

@Slf4j
@Service
public class InviteTaskServiceImpl implements IInviteTaskService {

    @Autowired
    MongoTemplate mongoTemplate;

    @Override
    public Page queryInviteTask(InviteTaskRequestVo vo) {

        Query query = new Query();
        if (!StringUtils.isEmpty(vo.getTitle())) {
            query.addCriteria(Criteria.where("srcChatTitle").regex(".*?\\" + vo.getTitle() + ".*"));
        }
        if (!StringUtils.isEmpty(vo.getTitle())) {
            query.addCriteria(Criteria.where("dstChatTitle").regex(".*?\\" + vo.getTitle() + ".*"));
        }
        long count = mongoTemplate.count(query, InviteTaskEntity.class);
        BasePage page = vo.getPage();
        Pageable pageable = PageRequest.of((int) (page.getCurrent() - 1), (int) page.getSize());
        query.with(Sort.by(Sort.Order.desc("_id")));
        List<InviteTaskEntity> systemOperateLogEntities = mongoTemplate.find(query.with(pageable), InviteTaskEntity.class);
        page.setRecords(systemOperateLogEntities);
        page.setTotal(count);
        return page;
    }

    @Override
    public boolean deleteById(String id) {
        Query query = Query.query(Criteria.where("_id").is(id));
        DeleteResult deleteResult = mongoTemplate.remove(query, InviteTaskEntity.class);
        return 1 == deleteResult.getDeletedCount();
    }
}
