package com.account.move.vo.telegrambusiness;

import com.account.move.vo.base.BaseWithId;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.NotNull;

/**
 * @author writer
 * @title: MigrateGroupVo
 * @projectName collectUser
 * @description:
 * @date 2021/12/821:28
 */
@Data
public class MigrateGroupVo extends BaseWithId {

    @ApiModelProperty("待发送的验证码")
    @NotNull(message = "做为数据源的群不能为空")
    private Long srcGroupId;

    @ApiModelProperty("待发送的验证码")
    @NotNull(message = "做为迁移目标的群不能为空")
    private Long dstGroupId;
}
