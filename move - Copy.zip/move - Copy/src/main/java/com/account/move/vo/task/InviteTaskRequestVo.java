package com.account.move.vo.task;


import com.account.move.vo.base.BasePage;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * @ClassNmae SystemOperationLogRequestVo
 * @Description 操作日志查询VO
 * @Author writer
 * @Date 2021/1/27  13:42
 **/

@Data
public class InviteTaskRequestVo {

    @ApiModelProperty("分页参数")
    BasePage page;

    @ApiModelProperty("源群组标题")
    private String title;
}
