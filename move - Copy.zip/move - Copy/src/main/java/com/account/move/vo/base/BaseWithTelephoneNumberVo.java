package com.account.move.vo.base;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import java.io.Serializable;

/**
 * @author ：Guo Tao
 * @date ：Created in 2021/3/18 11:18
 * @description：带id的数据vo
 * @modified By：
 * @version: 0.0.1
 */
@Data
public class BaseWithTelephoneNumberVo implements Serializable {

    @ApiModelProperty("电话号码")
    @NotNull(message = "电话号码不能为空")
    @Pattern(regexp = "^1[3-9][0-9]{9}$", message = "手机号码错误")
    private String telephoneNumber;
}
