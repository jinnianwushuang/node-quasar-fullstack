package com.account.move.controller;

import com.account.move.service.ISystemLogService;
import com.account.move.service.IUserLoginService;
import com.account.move.vo.R;
import com.account.move.vo.log.SystemLogRequestVo;
import com.account.move.vo.login.TelephoneBaseVo;
import com.account.move.vo.login.TelephoneVerifyCodeVo;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * @author writer
 * @title: SystemOperationLogController
 * @projectName checkAccount
 * @description:
 * @date 2021/12/1412:34
 */
@Slf4j
@RestController
@RequestMapping("api/log")
@Api(value = "日志查询控制器", tags = {"日志查询控制器"})
public class SystemOperationLogController {

    @Autowired
    ISystemLogService systemLogService;

    @PostMapping("/queryOperateLog")
    @ApiOperation(value = "获取验证码", notes = "获取验证码")
    public R queryOperateLog(@RequestBody @Validated SystemLogRequestVo vo) {
        return R.ok(systemLogService.querySystemOperationLog(vo));
    }

    /**
     * @return org.springframework.data.domain.Page
     * @Author
     * @Description 分页条件查询系统异常操作日志
     * @Date 2021/6/3
     * @Param [vo]  条件查询的vo
     **/
    @PostMapping("/queryExceptionLog")
    @ApiOperation(value = "查询异常日志", notes = "查询异常日志")
    public R queryExceptionLog(@RequestBody @Validated SystemLogRequestVo vo) {
        return R.ok(systemLogService.querySystemException(vo));
    }
}
