package com.account.move.entity;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;

/*** 查询超级群组上下文的    ***/

@Data
public class GetSuperGroupMemberContext {

    @ApiModelProperty("需要查询的chat id")
    private Long srcGroupId;

    @ApiModelProperty("用户个数")
    private int memberCount;

    @ApiModelProperty("服务器通知的用户个数")
    private AtomicInteger updatedMemberCount;

    @ApiModelProperty("是否更新完成")
    private AtomicBoolean whetherFinish;

    @ApiModelProperty("查询失败的错误信息")
    private ConcurrentHashMap<String, Object> errorMsg;

    @ApiModelProperty("保存群组用户id 的对象. key:用户id;value:用户id")
    private ConcurrentHashMap<Long, Long> groupMember;

    public GetSuperGroupMemberContext(Long srcGroupId) {
        this.srcGroupId = srcGroupId;
        this.errorMsg = new ConcurrentHashMap<>();
        this.groupMember = new ConcurrentHashMap<>();
        this.updatedMemberCount = new AtomicInteger(0);
    }

    public GetSuperGroupMemberContext(Long srcGroupId, int memberCount) {
        this.srcGroupId = srcGroupId;
        this.memberCount = memberCount;
        this.errorMsg = new ConcurrentHashMap<>();
        this.groupMember = new ConcurrentHashMap<>();
        this.updatedMemberCount = new AtomicInteger(0);
        this.whetherFinish = new AtomicBoolean(false);
    }
}
