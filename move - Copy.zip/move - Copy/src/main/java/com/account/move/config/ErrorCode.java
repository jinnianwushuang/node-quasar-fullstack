package com.account.move.config;

/**
 * @EnumNmae ErrorCode
 * @Description
 * @Author writer
 * @Date 2020/4/25  16:28
 **/
public enum ErrorCode {

    SYSTEM_BUSY(9999, "系统繁忙,请稍后重试"),
    OPERATE_FAIL(10000, "操作失败"),
    AUTHOR_FAIL(10001, "无权操作"),
    REGION_CODE_NOT_ALLOW_MODIFY(10002, "区号和电话号码不允许修改"),
    ACCOUNT_EXIST(10003, "账号已经处于准备登录中"),
    WRONG_ACCOUNT_PASSWORD(10004, "账号或密码错误"),
    DST_SRC_REPEATED_20_MINUTES(10005, "同样2个群之间的用户导入20分钟内只能执行一次"),
    VERIFY_CODE_WRONG(10006, "验证码错误"),
    VERIFY_CODE_EXPIRE(10007, "验证码过期"),
    ACCOUNT_EMPTY(10008, "账号或者密码为空"),
    MODIFIED_DATA_EMPTY(10009, "要修改的信息为空"),
    OPERATED_GROUP_MUST_NOT_CHANNEL(10010, "被导出用户的群组不能是频道"),
    SOURCE_GROUP_CAN_NOT_QUERY(10011, "指定的群组不允许被查询用户"),
    GROUP_MEMBER_ONLY_ONE(10012, "指定的群组的用户数不能小于2"),
    EMPTY_DATA(10013, "无数据"),
    DST_GROUP_NO_CHAT(10014, "指定群组没有聊天id,请在群内发消息1分钟后在观察"),
    STATUS_NOT_WAIT_VERIFY_CODE(10047, "当前状态无需发送验证码"),
    STATUS_NOT_WAIT_TELEPHONE(10048, "当前状态无需手机号码"),
    SERVER_NO_RESPONSE(10049, "TG服务器尚无响应"),
    NO_ACCOUNT(10013, "用户不存在"),
    NEITHER_EMPTY(10014, "被修改的群组信息不能都为空"),
    CHAT_NO_GROUP_ID(10015, "该聊天没有群组id,无法查询该聊天的用户列表"),
    CHAT_NO_MEMBER_COUNT(10016, "当前聊天暂无用户个数数据"),
    TOO_LARGE_FILE(10017, "文件太大，无法上传"),
    ERROR_REGION(10018, "申请必须 包含区域数据"),
    OPERATE_TOO_FAST(10019, "操作过于频繁,请稍后重试"),
    SLIDER_TYPE_ERROR(10020, "轮播图类型错误"),
    TYPE_ERROR(10021, "数据类型错误"),
    DATA_REPEAT(10022, "数据重复"),
    CLASSIFY_ERROR(10023, "商品分类错误"),
    COMMODITY_NOT_EXIST(10024, "商品不存在"),
    TARGET_NOT_DOCTOR(10025, "被关注用户不是医生"),
    LOGIN_PLEASE(10026, "用户未登录,请先登录"),
    SERVICE_NUMBER_DATA_REPEAT(10027, "问诊日期重复"),
    SERVICE_NUMBER_DATA_NOT_EXIST(10028, "指定日期的问诊数据不存在"),
    NOT_ALLOW_NO_LOGIN(10029, "非登录用户不允许该操作"),
    NOT_ALLOW_NON_MEMBERSHIP(10030, "非会员不能做该操作,请先开通会员"),
    REPORT_NOT_EXIST(10031, "选择的体检报告不存在"),
    REPORT_NOT_ALLOWED_MODIFY(10032, "2个月以前的体检报告不允许被修改"),
    HEALTH_REPORT_TOO_MUCH(10033, "一个月最多添加1个体检报告"),
    ORDER_NOT_ALLOWED(10034, "订单不支持该操作"),
    THIRD_PAYER_FAIL(10035, "支付商退款失败"),
    COMMODITY_SEND_ALREADY(10036, "商品已发货"),
    WAIT_PAY_CONSULT_ORDER(10037, "有未支付的问诊订单,暂不能购买问诊服务,请于10分钟后尝试"),
    MEDIA_NOT_SUPPORT_EDIT(10038, "已经通过审核的多媒体不支持修改"),
    DATA_OFFLINE(10039,  "已经被下架"),
    DATA_DELETED(10040,  "数据已经被删除"),
    DOCTOR_WITH_HOSPITAL(10041,  "当前医生已经有所属医院"),
    COMMODITY_DELETE_ALREADY(10042,  "该商品已下架"),
    USER_IS_DOCTOR(10043,  "该用户是医生,不能直接注销,建议解除合作关系后再注销"),
    USER_IS_ORGANIZATION(10044,  "该用户是商家,不能直接注销,建议解除合作关系后再注销"),
    LOGIN_OPERATION_EXPIRE(10045, "二维码过期,请刷新重试"),
    USER_INFO_NOT_ENOUGH(10046, "真实姓名和头像信息不全"),
    DATA_NUMBER_EXCEED_LIMIT(10048, "超过限制"),
    NO_SERVICE(10049, "不支持当前业务"),
    NOT_SUPPORT_THIS_AMOUNT(10050, "不支持当前的提款金额"),
    COMMODITY_TYPE_NOT_EXIST(10051, "商品分类的上一级不存在"),
    USER_TYPE_ERROR(10052, "用户的身份类型数字错误"),
    DOCTOR_EXTRA_FEE_ALREADY(10053, "医生的额外介绍费已经发放"),


    DOCTOR_WRONG(19998, "医生信息错误"),
    DOCTOR_BUSY(19999, "医生信息错误"),
    CONSULT_TYPE_ERROR(20000, "问诊类型错误"),
    SERVICE_TYPE_ERROR(20001, "服务类型错误"),
    ORDER_REPEAT(20002, "订单号重复"),
    COLUMN_WRONG(20003, "指定的知识专栏不存在"),
    NUMBER_NOT_ENOUGH(20004, "医生服务数量不足"),
    EXPIRE_OPERATE_TIME(20005, "订单超过2天时间,已经退款"),
    NOT_ALLOWED_OPERATION(20006, "当前订单状态不支持该操作"),
    MODIFY_TOO_FAST(20007, "修改接单状态太频繁"),
    DOCTOR_NOT_SERVER(20008, "该医生目前不接诊"),
    OPERATION_NOT_ALLOW(20009, "不支持当前操作"),
    OPERATOR_NOT_EXIST(20010, "操作对象不存在"),
    REPEAT(20011, "重复操作"),
    ORDER_WRONG(20012, "订单号错误"),
    COLUMN_NOT_BUY(20013, "无法评价未购买的专栏，请先购买该专栏"),
    MEDIA_NOT_BUY(20014, "未购买的内容无法留言，请先购买该内容"),
    MEDIA_TYPE_ERROR(20015, "媒体类型错误"),
    CHECK_FAIL(20016, "数据校验失败"),
    CANNOT_UPDATE_USING(20017, "正在使用的数据不能被修改"),
    USER_PRIVACY_VERSION_WRONG(20018, "用户隐私协议版本错误"),
    MEMBER_ONLY_EXIST(20019, "目前还有其他会员专享活动,请结束之前的活动后再开始新活动"),
    MEMBER_ONLY_NOT_EXIST(20020, "会员专享活动不存在"),
    MEMBER_ONLY_COMMODITY_TOO_MUCH(20021, "会员专享活动的商品太多"),
    COMMODITY_EXIST_MEMBER_ONLY(20022, "该商品已经在会员专享中"),
    DOCTOR_LEAVE_PLATE_ALREADY(20023, "平台暂未与该医生签约"),
    CHECK_REPORT_REPEATED(20024, "体检报告重复上传"),

    NOT_DOCTOR(30000, "身份类型错误"),
    CASH_NOT_ENOUGH(30001, "资金不足"),
    BANK_CARD_EMPTY(30002, "无银行卡"),
    TRY_LATER(30003, "系统繁忙,请稍后重试"),
    BANK_NOT_SUPPORT(30004, "不支持当前银行"),
    TITLE_EXIST_ALREADY(30005, "标题已存在"),
    NOT_ORG(40001, "当前用户不是商户"),
    TIME_PROMOTION_MUST_WITH_COMMODITY(40002, "限时优惠必须跟具体的商品或者服务相关联"),
    ORGANIZATION_CASH_NOT_ENOUGH(40003, "商户余额不足"),
    ORGANIZATION_CAN_CASH_NOT_ENOUGH(40004, "保证金不足"),
    ORGANIZATION_NO_BANK(40005, "当前商户没有绑定银行卡"),
    APPLY_NOT_SUPPORT(40006, "当前申请不支持该操作"),
    ORG_FROZEN(40007, "商户已经被冻结"),
    ORG_NAME_EXIST(40008, "商户名称已存在，请使用其它名称"),


    DEPARTMENT_ROLE_BIND(60001, "该部门与角色存在绑定关系，删除失败"),
    DEPARTMENT_USER_BIND(60002, "该部门与用户存在绑定关系，删除失败"),
    HAVE_CHILDREN_DEPARTMENT(60003, "该部门下有子部门,请先删除子部门"),
    ROLE_USER_BIND(60004, "该角色与用户存在绑定关系，删除失败"),
    DEPARTMENT_ROLE_USER_BIND(60005, "该部门角色和系统用户存在绑定关系，删除失败"),
    DEPARTMENT_ROLE_PERMISSION_BIND(60006, "该部门角色和权限存在绑定关系，删除失败"),
    TARGET_ENTITY_NOT_DELETED(60007, "被删除的数据已经有审核通过的数据,请先删除审核后的数据"),
    COMMODITY_SERVICE_NOT_DELETED(60008, "该商户下的商品和服务没有被全部删除"),
    WITH_OTHER_ORGANIZATION(60009, "已有其他机构,请更换账号申请"),
    COMMODITY_ACTIVE(60010, "商品在搞活动,暂时不能删除"),
    COMMODITY_NOT_ACTIVE(60013, "商品被商户下架"),

    FILE_SERVER_ERROR(50000, "文件服务器错误"),


     ;
    /**
     * 错误码
     */
    private long code;

    /**
     * 错误描述
     */
    private String description;

    private ErrorCode(long code, String description) {
        this.code = code;
        this.description = description;
    }

    public long getCode() {
        return code;
    }

    public void setCode(long code) {
        this.code = code;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }
}
