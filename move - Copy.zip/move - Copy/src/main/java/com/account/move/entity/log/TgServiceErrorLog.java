package com.account.move.entity.log;

import lombok.Data;

@Data
public class TgServiceErrorLog {

    public  String operateFunction;

    public  Long dataId;

    public  String dataIdDescription;


    public String errorMsg;

}
