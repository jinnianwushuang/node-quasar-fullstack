package com.account.move.utils;

import com.baomidou.mybatisplus.core.toolkit.StringPool;
import com.baomidou.mybatisplus.generator.AutoGenerator;
import com.baomidou.mybatisplus.generator.InjectionConfig;
import com.baomidou.mybatisplus.generator.config.*;
import com.baomidou.mybatisplus.generator.config.converts.MySqlTypeConvert;
import com.baomidou.mybatisplus.generator.config.po.TableInfo;
import com.baomidou.mybatisplus.generator.config.rules.IColumnType;
import com.baomidou.mybatisplus.generator.config.rules.NamingStrategy;
import com.baomidou.mybatisplus.generator.engine.AbstractTemplateEngine;
import com.baomidou.mybatisplus.generator.engine.BeetlTemplateEngine;
import org.springframework.util.StringUtils;

import java.util.ArrayList;
import java.util.List;

/**
 * @ClassNmae Generate
 * @Description 自动生成 代码工具类
 * @Autho writer
 * @Date 2020/4/22  19:34
 **/
public class GenerateCode {

    protected ITypeConvert getDataTypeConvert() {
        ITypeConvert dataTypeConvert = new MySqlTypeConvert() {
            @Override
            public IColumnType processTypeConvert(GlobalConfig globalConfig, String fieldType) {
                if (fieldType.toLowerCase().contains("bigint")) {
                    //return DbColumnType.BASE_LONG;
                }
                if (fieldType.toLowerCase().contains("int")) {
                    //return DbColumnType.BASE_INT;
                }
                return super.processTypeConvert(globalConfig, fieldType);
            }
        };
        return dataTypeConvert;
    }

    public void generate(String dbName) {
        // 代码生成器
        AutoGenerator mpg = new AutoGenerator();
        String tableNames = "";
        // 全局配置
        GlobalConfig gc = new GlobalConfig();
        String projectPath = System.getProperty("user.dir");
        gc.setOutputDir(projectPath + "/src/main/java/");
        gc.setAuthor("goodCreater");
        gc.setOpen(false);
        // gc.setActiveRecord(true);
        gc.setSwagger2(true);
        gc.setFileOverride(true);
        mpg.setGlobalConfig(gc);
        // 数据源配置
        DataSourceConfig dsc = new DataSourceConfig();          //
        dsc.setUrl("jdbc:mysql://localhost:3306/" + dbName + "?characterEncoding=utf-8&serverTimezone=Asia/Shanghai");
        dsc.setDriverName("com.mysql.cj.jdbc.Driver");
        dsc.setUsername("root");
        dsc.setPassword("root@123");
        dsc.setTypeConvert(getDataTypeConvert());
        mpg.setDataSource(dsc);
        String basePackageName = this.getClass().getPackage().getName();
        String[] all = basePackageName.split("\\.");
        int size = all.length;
        String usedPackage = "";
        if (size > 3) {
            basePackageName = basePackageName.substring(0, basePackageName.lastIndexOf("."));
        }
        usedPackage = basePackageName + ".db";
        // 包配置
        PackageConfig pc = new PackageConfig();
        // pc.setMapper( "mapper." + dbName);
        // pc.setXml(dbName + ".mapper.xml" );
        pc.setModuleName(dbName);
        /***  在哪个父目录下创建包 ***/
        pc.setParent(usedPackage);
        mpg.setPackageInfo(pc);

        // 自定义配置
        InjectionConfig cfg = new InjectionConfig() {
            @Override
            public void initMap() {
                // to do nothing
            }
        };

        String suffix = "btl";

        AbstractTemplateEngine templateEngine = null;
        try {
            templateEngine = new BeetlTemplateEngine();
        } catch (Exception e) {
            System.out.println(e);
        }
        // String suffix = "vm";
        // AbstractTemplateEngine templateEngine = new VelocityTemplateEngine();
        // String suffix = "ftl";
        // AbstractTemplateEngine templateEngine = new FreemarkerTemplateEngine();
        // 如果模板引擎是 freemarker
        String templatePath = "templates/mapper.xml." + suffix;
        // 如果模板引擎是 velocity
        // 自定义输出配置
        List<FileOutConfig> focList = new ArrayList<>();
        // 自定义配置会被优先输出
        focList.add(new FileOutConfig(templatePath) {
            @Override
            public String outputFile(TableInfo tableInfo) {
                // 自定义输出文件名 ， 如果你 Entity 设置了前后缀、此处注意 xml 的名称会跟着发生变化！！
                String moduleName = "";
                if (!StringUtils.isEmpty(pc.getModuleName())) {
                    moduleName = pc.getModuleName() + "/";
                }
                return projectPath + "/src/main/resources/mapper/" + "/" + moduleName + tableInfo.getEntityName() + "Mapper" + StringPool.DOT_XML;
            }
        });
        /*
        cfg.setFileCreate(new IFileCreate() {
            @Override
            public boolean isCreate(ConfigBuilder configBuilder, FileType fileType, String filePath) {
                // 判断自定义文件夹是否需要创建
                checkDir("调用默认方法创建的目录");
                return false;
            }
        });
        */
        cfg.setFileOutConfigList(focList);
        mpg.setCfg(cfg);

        // 配置模板
        TemplateConfig templateConfig = new TemplateConfig();
        // 配置自定义输出模板
        //指定自定义模板路径，注意不要带上.ftl/.vm, 会根据使用的模板引擎自动识别
        templateConfig.setEntity("templates/entity.java");
        templateConfig.setService("templates/service.java");
        templateConfig.setServiceImpl("templates/serviceImpl.java");
        templateConfig.setMapper("templates/mapper.java");
        templateConfig.setController(null);
        templateConfig.setXml(null);
        mpg.setTemplate(templateConfig);

        // 策略配置,数据库表配置
        StrategyConfig strategy = new StrategyConfig();
        //数据库表映射到实体的命名策略
        strategy.setNaming(NamingStrategy.underline_to_camel);
        //数据库表字段映射到实体类的命名策略
        strategy.setColumnNaming(NamingStrategy.underline_to_camel);
        //自定义继承entity类，添加这一个会在生成实体类的时候继承entity
        //strategy.setSuperEntityClass("com.thyd.manager.entity.BaseEntity");
        //实体是否为lombok模型
        strategy.setEntityLombokModel(true);
        //生成@RestController控制器
        strategy.setRestControllerStyle(false);
        //是否继承controller ALTER TABLE `health_manage`.`system_income_record`
        //ADD COLUMN `target_name` varchar(64) NULL DEFAULT '' COMMENT '被购买商品的名称' AFTER `pay_reference`,
        //ADD COLUMN `picture` varchar(64) NULL DEFAULT '' COMMENT '被购买放物品的图片' AFTER `target_name`;
        // strategy.setSuperControllerClass("com.wy.testCodeGenerator.controller");
         //strategy.setInclude("meeting_activity_apply", "meeting_activity_entity");
//        strategy.setExclude(tableNames.split(","));
        //strategy.setExclude(tableNames.split(","));
        //String[] ignore = {"create_time", "modify_time"};
        //strategy.setSuperEntityColumns(ignore);
        //驼峰转连字符串
        //strategy.setControllerMappingHyphenStyle(true);
        //表前缀
        strategy.setTablePrefix(pc.getModuleName() + "_");
        mpg.setStrategy(strategy);
        mpg.setTemplateEngine(templateEngine);
        mpg.execute();
    }

    public static void main(String[] args) {
        List<String> names = new ArrayList<>();

        names.add("collect_user");
        /***
         names.add("users");
         names.add("order_user");
         names.add("health_manage");
         names.add("health_basic");
         names.add("multi_media");
         ***/
        GenerateCode gc = new  GenerateCode();
        names.forEach(e -> gc.generate(e));
        return;
    }
}
