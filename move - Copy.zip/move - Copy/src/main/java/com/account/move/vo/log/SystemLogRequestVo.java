package com.account.move.vo.log;


import com.account.move.entity.log.SystemOperateLogEntity;
import com.account.move.vo.base.BasePage;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * @ClassNmae SystemOperationLogRequestVo
 * @Description 操作日志查询VO
 * @Author writer
 * @Date 2021/1/27  13:42
 **/

@Data
public class SystemLogRequestVo {

    @ApiModelProperty("分页参数")
    BasePage page;

    @ApiModelProperty("系统用户id")
    private Long userId;

    @ApiModelProperty("模块码")
    private String moduleCode;

    @ApiModelProperty("操作码")
    private String operationCode;

    @ApiModelProperty("开始时间(时间戳)")
    private Long startTime;

    @ApiModelProperty("结束时间(时间戳)")
    private Long endTime;



}
