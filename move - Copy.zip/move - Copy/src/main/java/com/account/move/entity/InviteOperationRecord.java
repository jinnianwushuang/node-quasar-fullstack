package com.account.move.entity;

import lombok.Data;

@Data
public class InviteOperationRecord {

    /*** 本次邀请的人数    ***/
    private Integer inviteTotal;

    /*** 邀请发生成功的次数    ***/
    private Integer inviteSucceed;
    
    /*** 邀请发生错误的次数    ***/
    private Integer inviteError;

    /*** 邀请开始时间     ***/
    private Long beginTimeStamp;

    /*** 邀请结束时间     ***/
    private Long endTimeStamp;
}
