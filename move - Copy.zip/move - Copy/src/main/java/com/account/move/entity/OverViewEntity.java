package com.account.move.entity;

import com.account.move.entity.log.SystemOperateLogEntity;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.util.List;

@Data
public class OverViewEntity {

    private AccountLoginEntity entity;

    @ApiModelProperty("最新操作日志")
    List<SystemOperateLogEntity> lastLogs;

    @ApiModelProperty("邀请任务信息")
    List<InviteTaskEntity> inviteTaskEntities;
}
