package com.account.move.serviceUd.impl;


import com.account.move.entity.SystemUser;
import com.account.move.serviceUd.ISystemUserServiceUd;
import com.account.move.utils.AdminCommonMethod;
import com.account.move.utils.NetWorkUtils;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.annotation.PostConstruct;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

/**
 * @author writer
 * @title: SystemUserServiceImplUd
 * @projectName checkAccount
 * @description:
 * @date 2021/12/1416:11
 */
@Slf4j
@Service
public class SystemUserServiceImplUd implements ISystemUserServiceUd {

    SystemUser defaultUser;

    private List<SystemUser> systemUsers;

    private Map<Long, SystemUser> systemUserMapKeyId;

    private Map<String, SystemUser> systemUserMapKeyTelephone;

    private Map<String, SystemUser> systemUserMapKeyUsername;


    public void  addDefaultSystemUser() {
        defaultUser = new SystemUser();
        defaultUser.setId(0L);
        defaultUser.setUsername(NetWorkUtils.serverIp);
        defaultUser.setPassword(AdminCommonMethod.getUserPasswordStoreInDatabase(NetWorkUtils.serverPort, ""));
    }

    /***
     * @description: 根据id查询指定的系统管理员用户
     * @param userId
     * @return com.account.core.db.collect_user.entity.SystemUser
     * @throws
     * @author writer
     * @date 2021/12/14 16:07
     ****/
    @Override
    public SystemUser getUserById(Long userId) {
        if(0L == userId) {
            return defaultUser;
        }
        return systemUserMapKeyId.get(userId);
    }

    /***
     * @description: 根据电话号码查询指定的系统管理员用户
     * @param telephone
     * @return com.account.core.db.collect_user.entity.SystemUser
     * @throws
     * @author writer
     * @date 2021/12/14 16:07
     ****/
    @Override
    public SystemUser getUserByTelephone(String telephone) {
        return systemUserMapKeyTelephone.get(telephone);
    }

    /***
     * @description: 根据账号查询指定的系统管理员用户
     * @param account
     * @return com.account.core.db.collect_user.entity.SystemUser
     * @throws
     * @author writer
     * @date 2021/12/14 16:07
     ****/
    @Override
    public SystemUser getUserByAccount(String account) {
        return systemUserMapKeyUsername.get(account);
    }

    /**
     * 定时更新内存中的数据的接口
     *
     * @return void
     * @Description
     * @Date
     * @author writer
     **/
    @Override
    public void reload() {

    }

    /**
     * 是否需要重新加载当前服务所维护的数据
     *
     * @param updateBasicDataList 被更新的数据类型
     * @return boolean true:需要重新加载;false:不需要重新加载
     * @Description
     * @Date
     * @author writer
     **/
    @Override
    public boolean needReload(Set<String> updateBasicDataList) {
        return updateBasicDataList.contains(SystemUser.class.getSimpleName());
    }
}
