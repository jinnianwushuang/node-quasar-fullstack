package com.account.move.filter;

import com.account.move.config.ErrorCode;
import com.account.move.config.SystemUserSomeSegment;
import com.account.move.entity.SystemUser;
import com.account.move.serviceUd.ISystemUserServiceUd;
import com.account.move.utils.AdminCommonMethod;
import com.account.move.utils.JsonUtils;
import com.account.move.utils.TokenCollection;
import com.account.move.vo.R;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.ObjectUtils;
import org.springframework.util.StringUtils;
import org.springframework.web.method.HandlerMethod;
import org.springframework.web.servlet.HandlerInterceptor;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.PrintWriter;

/**
 * @author ：Guo Tao
 * @date ：Created in 2021/2/8 11:27
 * @description：非正常用户操作拦截器
 * @modified By：
 * @version: 0.0.1
 */
@Slf4j
@Component
public class AdminInterceptor implements HandlerInterceptor {

    @Autowired
    ISystemUserServiceUd systemUserServiceUd;

    @Data
    public static class CheckContext {

        @ApiModelProperty("系统用户携带的token")
        private String token;

        @ApiModelProperty("系统用户")
        SystemUser systemUser;

        @ApiModelProperty("句柄")
        Object handler;
    }

    /**
     * 判断当前登录用户是否登录
     *
     * @param context 拦截器上下文对象
     * @return boolean  true:已经登录； false:未登录
     * @Description
     * @Date
     * @author writer
     **/
    private boolean whetherIsLogin(CheckContext context) {
        /*** 接收到请求，记录请求内容 ***/
        String token = context.getToken();
        String failMsg = "请先登录";
        if (StringUtils.isEmpty(token)) {
            log.info(failMsg);
            return false;
        }
        Long uid = TokenCollection.tokenMap.get(token);
        if (ObjectUtils.isEmpty(uid)) {
            return false;
        }
        String tokenMemory = TokenCollection.uidToken.get(uid);
        if (!token.equals(tokenMemory)) {
            return false;
        }
        return true;
    }

    /**
     * 判断当前登录用户对当前的操作是否有权限
     *
     * @return boolean  true: 有操作权限； false: 无操作权限
     * @Description
     * @Date
     * @author writer
     **/
//    private boolean whetherHasPermission(CheckContext context) {
//        /*** 获取方法上的权限注解  ***/
//
//        HandlerMethod handlerMethod = (HandlerMethod) context.getHandler();
//        PermissionAnnotations requiredPermission = handlerMethod.getMethod().getAnnotation(PermissionAnnotations.class);
//        if (null == requiredPermission) {
//            /*** 如果没有权限,则可以操作。 这就意味着 除了登录登出之外, 其他每个方法都必须要加权限限制 ***/
//            return true;
//        }
//        /*** 当前方法的权限码 ***/
//        String permissionCode = requiredPermission.permissionCode();
//        /*** 计算当前用户的所有权限码 ***/
//        /*** 计算当前操作用户的所有角色的 ***/
//        List<SystemUserDepartmentRoleRelation> departmentRoleRelations = systemUserDepartmentRoleUd.systemUserDepartmentRoleRelationBySystemUserId(context.getSystemUser().getId());
//
//        if (null == departmentRoleRelations) {
//            /*** TODO 如果使用权限，则为false  不使用权限，则为true ***/
//            return false;
//        }
//        /*** 保存当前登录用户的所有权限码 ***/
//        Set<String> thisUserPermissionCodes = new HashSet<>();
//
//        for (SystemUserDepartmentRoleRelation relation : departmentRoleRelations) {
//            List<SystemDepartmentRolePermission> departmentRolePermissions = this.systemDepartmentRolePermissionUd.systemDepartmentRolePermissionGroupBydepartmentRoleId(relation.getDepartmentRoleRelationId());
//            if (CollectionUtils.isEmpty(departmentRolePermissions)) {
//                continue;
//            }
//            /*** 根据部门角色权限 thisUserPermissionCodes.equals("")关系得到权限id列表 ***/
//            List<Long> ids = departmentRolePermissions.stream().map(e -> e.getSystemPermissionId()).collect(Collectors.toList());
//            /*** 添加当前权限到权限码 ***/
//
//            ids.forEach(e -> {
//                SystemPermissionDto per = this.permissionUd.systemPermissionById(e);
//                if (null != per) {
//                    thisUserPermissionCodes.add(per.getGroupCode());
//                }
//            });
//        }
//        /*** 有操作权限 ***/
//        return thisUserPermissionCodes.contains(permissionCode);
//        /*** 无操作权限 ***/
//    }
    @Override
    public boolean preHandle(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse, Object handler) throws Exception {
        if (handler instanceof HandlerMethod) {
            /*** 获取控制器的名字 ***/
            HandlerMethod handlerMethod = (HandlerMethod) handler;
            String usedControllerName = handlerMethod.getBean().getClass().getName();
            String projectControllerName = "com.account.move.controller";
            String loginControllerName = "com.account.move.controller.UserLoginController";
            if (StringUtils.isEmpty(usedControllerName) || !usedControllerName.startsWith(projectControllerName)) {
                return true;
            }
            /*** 如果是登录控制器,则不予校验 ***/
            boolean isLogin = usedControllerName.indexOf(loginControllerName) >= 0;
            if (isLogin) {
                return true;
            }

            String token = AdminCommonMethod.getUserToken();
            if (StringUtils.isEmpty(token)) {
                this.loginAgainInfo(httpServletRequest, httpServletResponse);
                return false;
            }
            CheckContext context = new CheckContext();
            context.setHandler(handler);
            context.setToken(AdminCommonMethod.getUserToken());
            /*** 如果没有登录则提示用户登录 ***/
            if (!this.whetherIsLogin(context)) {
                log.info("检测到用户未登录");
                this.loginAgainInfo(httpServletRequest, httpServletResponse);
                return false;
            }
            /*** 权限校验 ***/
//            if (this.whetherHasPermission(context)) {
//                return true;
//            }
            /*** 告知前端没有操作权限 ***/
            //this.returnNoPermission(httpServletRequest, httpServletResponse);
            return true;
            /***  TODO 后续加权限后此处默认登录失败  ***/
        } else {
            return true;
        }
    }

    /**
     * 由于token验证失败，因此返回的错误信息
     *
     * @param httpServletRequest 跟客户端的连接句柄
     * @param response           跟客户端的相应句柄
     * @return void
     * @Description
     * @Date
     * @author writer
     **/
//    private void returnNoPermission(HttpServletRequest httpServletRequest, HttpServletResponse response) {
//        try {
//            String coding = httpServletRequest.getCharacterEncoding();
//            String contextType = "application/json";
//            response.setContentType(contextType);
//            response.setCharacterEncoding(coding);
//            PrintWriter writer = response.getWriter();
//            R r = R.failed(ErrorCode.AUTHOR_FAIL);
//            String jsonStr = JsonUtils.serializeToString(r);
//            writer.print(jsonStr);
//            writer.close();
//        } catch (Exception e) {
//            log.error("管理后台控制台,权限校验失败,返回信息写入错误", e);
//        }
//    }

    /**
     * 告知前端需要登录
     *
     * @param httpServletRequest 跟客户端的连接句柄
     * @param response           跟客户端的相应句柄
     * @return void
     * @Description
     * @Date *
     * @author writer
     **/
    private void loginAgainInfo(HttpServletRequest httpServletRequest, HttpServletResponse response) {
        try {
            String coding = httpServletRequest.getCharacterEncoding();
            String contextType = "application/json";
            response.setContentType(contextType);
            response.setCharacterEncoding(coding);
            PrintWriter writer = response.getWriter();
            R r = R.failed(ErrorCode.LOGIN_PLEASE);
            String jsonStr = JsonUtils.serializeToString(r);
            writer.print(jsonStr);
            writer.close();
        } catch (Exception e) {
            log.error("管理后台,权限校验失败,返回信息写入错误", e);
        }
    }
}
