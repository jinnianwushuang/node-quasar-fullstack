package com.account.move.vo.telegrambusiness;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import org.hibernate.validator.constraints.Length;

import javax.validation.constraints.NotNull;

/**
 * @author writer
 * @title: VerifyCodeVo
 * @projectName collectUser
 * @description: 发送验证码的vo
 * @date 2021/12/821:22
 */
@Data
public class VerifyCodeVo {

    @ApiModelProperty("待发送的验证码")
    @NotNull(message = "验证码不能为空")
    @Length(min = 2, max = 6, message = "验证码的长度取值范围只能是[2,6]")
    private String verifyCode;
}
