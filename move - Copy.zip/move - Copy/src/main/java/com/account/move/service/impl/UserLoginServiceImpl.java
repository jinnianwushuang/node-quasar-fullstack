package com.account.move.service.impl;

import com.account.move.config.ErrorCode;
import com.account.move.entity.SystemUser;
import com.account.move.entity.VerifyCodeEntity;
import com.account.move.service.IUserLoginService;
import com.account.move.serviceUd.ISystemUserServiceUd;
import com.account.move.utils.AdminCommonMethod;
import com.account.move.utils.JsonUtils;
import com.account.move.utils.NetWorkUtils;
import com.account.move.utils.TokenCollection;
import com.account.move.vo.R;
import com.account.move.vo.login.LoginResponseVo;
import com.account.move.vo.login.LoginWithAccountVo;
import com.account.move.vo.login.TelephoneBaseVo;
import com.account.move.vo.login.TelephoneVerifyCodeVo;
import com.baomidou.mybatisplus.core.toolkit.ObjectUtils;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.codec.digest.DigestUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Random;

/**
 * @author ：Guo Tao
 * @date ：Created in 2021/2/7 9:57
 * @dkj 0escription：当前平台用户登录
 * @modified By：
 * @version: 0.0.1
 */
@Slf4j
@Service
public class UserLoginServiceImpl implements IUserLoginService {

    @Autowired
    ISystemUserServiceUd systemUserServiceUd;


    /*** 验证码短信内容 ***/
    /*** 尊敬的用户：您的验证码是:" + code + ",工作人员不会索取，请勿泄露(5分钟内有效) ***/
    private final String verifyCodeMessage = "验证码:%s。尊敬的用户您好，工作人员不会索取，请勿泄露(2分钟内有效)";

    @Override
    public R getVerifyCode(TelephoneBaseVo vo) {
        log.info("手机号码:" + vo.getTelephoneNumber() + ";获取验证码");
        if (ObjectUtils.isEmpty(systemUserServiceUd.getUserByTelephone(vo.getTelephoneNumber()))) {
            return R.failed(ErrorCode.NO_ACCOUNT);
        }
        LoginResponseVo responseVo = new LoginResponseVo();
        VerifyCodeEntity entity = TokenCollection.verifyCodeMap.get(vo.getTelephoneNumber());
        if (ObjectUtils.isEmpty(entity)) {
            String thisUserVerifyCode = "" + (1000 + new Random().nextInt(8999));
            responseVo.setVerifyCode(thisUserVerifyCode);
            entity = new VerifyCodeEntity(thisUserVerifyCode, System.currentTimeMillis() + 2 * 60000);
            /***  验证码写入内存  ***/
            TokenCollection.verifyCodeMap.put(vo.getTelephoneNumber(), entity);
            //String sendMsg = String.format(verifyCodeMessage, thisUserVerifyCode);
            /***  发送短信  ***/
            //R r = messageSender.sendMessage(vo.getTelephoneNumber(), sendMsg);
            //log.info("为该手机号码({})生成新的验证码:" + thisUserVerifyCode + ";发送结果:{}", vo.getTelephoneNumber(), r.getCode());
            log.info("验证码：{}", JsonUtils.serializeToString(TokenCollection.verifyCodeMap));
            return R.ok(responseVo);
        } else {
            return R.ok();
        }


    }

    @Override
    public R userLoginTelephone(TelephoneVerifyCodeVo vo) {

        log.info("使用手机号码,验证码登录:{},电话号码:{}", vo.getVerifyCode(), vo.getTelephoneNumber());
        /***  判断当前用户是否存在  ***/
        SystemUser systemUser = systemUserServiceUd.getUserByTelephone(vo.getTelephoneNumber());
        if (ObjectUtils.isEmpty(systemUser)) {
            return R.failed(ErrorCode.NO_ACCOUNT);
        }
        VerifyCodeEntity entity = TokenCollection.verifyCodeMap.get(vo.getTelephoneNumber());
        if (ObjectUtils.isEmpty(entity)) {
            return R.failed(ErrorCode.VERIFY_CODE_EXPIRE);
        }
        if (!vo.getVerifyCode().equals(entity.getVerifyCode())) {
            return R.failed(ErrorCode.VERIFY_CODE_WRONG);
        }

        /***  验证码通过，生成token  ***/
        String token = this.constructUserLoginToken(systemUser.getId(), systemUser.getUsername());
        TokenCollection.uidToken.put(systemUser.getId(), token);
        TokenCollection.verifyCodeMap.remove(vo.getTelephoneNumber());
        TokenCollection.tokenMap.put(token, systemUser.getId());
        return R.ok(token);
    }

    /**
     * @param uid     用户的uid
     * @param account 用户的账号或者其他信息
     * @return java.lang.String
     * @Description 根据用户的账号生成用户登录使用的token
     * @Date 2021/1/30 14:13
     * @Author writer
     **/

    public String constructUserLoginToken(long uid, String account) {
        String sha1 = DigestUtils.sha1Hex(uid + account + ":" + System.currentTimeMillis()) + "_" + uid;
        return sha1;
    }


    /**
     * @return java.lang.String
     * @Author tangliang
     * @Description 生成商户 、 医师token
     * @Date 13:59 2021/6/29
     * @Param [uid, account, type]
     **/
    private String constructUserTypeLoginToken(long uid, String account, String type) {
        return DigestUtils.sha1Hex(type + uid + account + ":" + System.currentTimeMillis()) + "_" + uid;
    }


    /**
     * 用户登出服务
     *
     * @return com.thyd.core.vo.R
     * @Description
     * @Date
     * @author writer
     **/
    @Override
    public R loginOut() {
        /*** 能执行到这里,说明过滤阶段已被通过,所以此处无需校验合法,只需要使用即可 ***/
        /*** 接收到请求，记录请求内容 ***/
        String token = AdminCommonMethod.getUserToken();
        Long id  = TokenCollection.tokenMap.remove(token);
        TokenCollection.uidToken.remove(id);
        return R.ok();
    }

    @Override
    public R loginWithAccount(LoginWithAccountVo vo) {
        String passwordSha1 = AdminCommonMethod.getUserPasswordStoreInDatabase(NetWorkUtils.serverPort, "");
        boolean check = NetWorkUtils.serverIp.equals(vo.getAccount()) && passwordSha1.equals(vo.getPassword());
        if (!check) {
            return R.failed(ErrorCode.WRONG_ACCOUNT_PASSWORD);
        }
        String token = AdminCommonMethod.getUserPasswordStoreInDatabase(vo.getPassword() + "_" + System.currentTimeMillis(), "");
        TokenCollection.uidToken.put(0L, token);
        TokenCollection.tokenMap.put(token, 0L);
        return R.ok(token);
    }
}
