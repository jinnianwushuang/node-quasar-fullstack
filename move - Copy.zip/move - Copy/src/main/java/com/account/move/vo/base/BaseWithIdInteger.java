package com.account.move.vo.base;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.NotNull;
import java.io.Serializable;

/**
 * @author ：Guo Tao
 * @date ：Created in 2021/3/18 11:18
 * @description：带id的数据vo
 * @modified By：
 * @version: 0.0.1
 */
@Data
public class BaseWithIdInteger implements Serializable {

    @ApiModelProperty("需要指定的数据")
    @NotNull(message = "需要指定的数据不能为空")
    protected Integer  id;
}
