package com.account.move.vo.telegrambusiness;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.NotNull;

@Data
public class EditGroupVo {

    @ApiModelProperty("被编辑的群id")
    private Long chatId;

    @ApiModelProperty("被编辑的群标题")
    @NotNull(message = "聊天群的备注信息不能未空")
    private String remark;
}
