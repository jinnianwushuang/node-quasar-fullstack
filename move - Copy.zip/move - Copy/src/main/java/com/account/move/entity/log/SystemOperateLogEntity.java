package com.account.move.entity.log;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * @author ：Guo Tao
 * @date ：Created in 2021/4/16 8:36
 * @description：系统日志保存对象
 * @modified By：
 * @version: 0.0.1
 */
@Data
public class SystemOperateLogEntity {

    @ApiModelProperty("系统用户id")
    private Long userId;

    @ApiModelProperty("操作人员真实姓名")
    private String realName;

    @ApiModelProperty("操作人员账号")
    private String userName;

    @ApiModelProperty("服务器的url地址:ip_port")
    private String serverUrl;

    @ApiModelProperty("模块码称")
    private String moduleCode;

    @ApiModelProperty("模块名称")
    private String moduleName;

    @ApiModelProperty("操作码")
    private String operationCode;

    @ApiModelProperty("操作名称")
    private String operationName;

    @ApiModelProperty("方法名称")
    private String method;

    @ApiModelProperty("操作的参数")
    private String params;

    @ApiModelProperty("操作结果")
    private Boolean  operateResult;

    @ApiModelProperty("失败原因")
    private String  failReason;

    @ApiModelProperty("备注信息")
    private String remark;

    @ApiModelProperty("操作发生时的时间戳(精确到毫秒)")
    private Long operationTime;

    @ApiModelProperty("创建时间(yyyy-MM-dd HH:mm:ss)")
    private String createDate;

    @ApiModelProperty("操作的url地址")
    private String operationUrl;

    @ApiModelProperty("服务器的地址")
    private String severUrl;

    @ApiModelProperty("操作者使用的ip")
    private String operationIp;
}
