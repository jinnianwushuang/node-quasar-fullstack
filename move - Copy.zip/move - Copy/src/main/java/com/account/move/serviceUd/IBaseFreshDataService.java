package com.account.move.serviceUd;

import java.util.Set;

/**
 * @author ：Guo Tao
 * @date ：Created in 2021/3/10 16:01
 * @description：定时刷新数据的服务接口
 * @modified By：
 * @version: 0.0.1
 */
public interface IBaseFreshDataService {
    /**
     * 定时更新内存中的数据的接口
     * @Description
     * @Date
     * @param
     * @return void
     * @author writer
     **/
    public void reload();

    /**
     * 是否需要重新加载当前服务所维护的数据
     * @Description
     * @Date
     * @param updateBasicDataList  被更新的数据类型
     * @return boolean true:需要重新加载;false:不需要重新加载
     * @author writer
     **/
    public boolean needReload(Set<String> updateBasicDataList);

}
