package com.account.move;


import com.account.move.tg.TgService;
import lombok.extern.slf4j.Slf4j;
import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.scheduling.annotation.EnableScheduling;
import springfox.documentation.swagger2.annotations.EnableSwagger2;

@Slf4j
@EnableSwagger2
@SpringBootApplication(scanBasePackages = {"com.account.move"})
@EnableScheduling
public class AccountCheckApplication {
    public static void main(String[] args) {

        SpringApplication.run(AccountCheckApplication.class, args);
        try {
            TgService.start();
        }catch (Exception e) {
            log.error(e.getMessage() + "\r\n" + e.getStackTrace());
        }

    }
}
