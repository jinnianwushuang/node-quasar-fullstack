package com.account.move.controller;

import com.account.move.annotations.SystemLogType;
import com.account.move.service.IUserLoginService;
import com.account.move.vo.R;
import com.account.move.vo.login.LoginWithAccountVo;
import com.account.move.vo.login.TelephoneBaseVo;
import com.account.move.vo.login.TelephoneVerifyCodeVo;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

/**
 * @author writer
 * @title: UserLoginController
 * @projectName checkAccount
 * @description: TODO
 * @date 2021/12/1412:34
 */
@Slf4j
@RestController
@RequestMapping("api/login")
@Api(value = "用户登录登出控制器", tags = {"用户登录登出控制器"})
public class UserLoginController {

    @Autowired
    IUserLoginService userLoginService;

    // @PostMapping("/getVerifyCode")
    @ApiOperation(value = "获取验证码", notes = "获取验证码")
    public R getVerifyCode(@RequestBody @Validated TelephoneBaseVo vo) {
        return userLoginService.getVerifyCode(vo);
    }

    @PostMapping("/LoginWithAccount")
    @ApiOperation(value = "使用账号密码登陆系统", notes = "使用账号密码登陆系统")
    @SystemLogType(moduleCode = "TgService", moduleName = "TG业务", operationCode = "LoginWithAccount", operationName = "使用验证码登录")
    public R LoginWithAccount(@RequestBody @Validated LoginWithAccountVo vo) {
        return userLoginService.loginWithAccount(vo);
    }

    //@PostMapping("/loginWithVerifyCode")
    @ApiOperation(value = "使用验证码登录", notes = "使用验证码登录")
    public R loginWithVerifyCode(@RequestBody @Validated TelephoneVerifyCodeVo vo) {
        return userLoginService.userLoginTelephone(vo);
    }

    @GetMapping("/logOut")
    @ApiOperation(value = "退出登录", notes = "退出登录")
    @SystemLogType(moduleCode = "TgService", moduleName = "TG业务", operationCode = "logOut", operationName = "退出登录")
    public R logOut() {
        return userLoginService.loginOut();
    }
}
