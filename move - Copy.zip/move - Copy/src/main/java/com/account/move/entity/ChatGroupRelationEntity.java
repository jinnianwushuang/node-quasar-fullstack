package com.account.move.entity;


import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@Data
public class ChatGroupRelationEntity {

    @ApiModelProperty("聊天对象的id")
    private long chatId;

    @ApiModelProperty("群组的id")
    private long groupId;

    @ApiModelProperty("群标题")
    private String title;

    public ChatGroupRelationEntity(long chatId, long groupId, String title) {
        this.chatId = chatId;
        this.groupId = groupId;
        this.title = title;
    }
}
