package com.account.move.config;

public interface TaskInfoInterface {

    String id = "_id";

    /*** 群组id 的字段名称    ***/
    String superGroupId = "superGroupId";

    /*** 快照生成时间    ***/
    String groupSnapDate = "createDate";

    /*** 用户id存放在不同的字段，每个字段最多的用户数据个数    ***/
    Integer userIdNumberPerIndex = 1000;

    /*** 用于标记用户是否被邀请到某个群的字段前缀.前缀加群组id构成的字段标记这个用户是否被邀请至指定的群。    ***/
    String userInvitedSucceed = "userInvitedSucceed";

    /*** 邀请的错误信息. 记录用户被邀请到某个群 发生错误的的字段前缀. 前缀加群组id构成的字段 记录邀请发生的错误信息 ***/
    String userInvitedErrorMsg = "userInvitedErrorMsg";

    /***   邀请用户进度  ***/
    String stepForIndex = "stepForIndex";

    /*** 查询的错误信息    ***/
    String queryErrorMsg = "queryErrorMsg";

    /*** 保存邀请用户的快照信息 collection 名称    ***/
    String inviteGroupCollectionName = "inviteGroup";
}
