package com.account.move.config;

import io.swagger.annotations.ApiModelProperty;

/**
 * @author writer
 * @title: SystemUserSomeSegment
 * @projectName tegcheck
 * @description: TODO
 * @date 2021/11/2820:16
 */
public interface SystemUserSomeSegment {

    String uid = "id";

    @ApiModelProperty(value = "token")
    String token = "token";

    @ApiModelProperty(value = "用户名")
    String username = "username";

    @ApiModelProperty(value = "盐")
    String salt = "salt";

    @ApiModelProperty(value = "邮箱")
    String email = "email";

    @ApiModelProperty(value = "手机号")
    String mobile = "mobile";

    @ApiModelProperty(value = "状态(  0：禁用   1：正常)")
    String usedStatus = "usedStatus";

    @ApiModelProperty(value = "部门ID")
    String departmentId = "departmentId";
}