package com.account.move.entity;

import lombok.Data;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

@Data
public class AddContactsContext {

    Map<Long, Object> operateResult;


    public AddContactsContext() {
        this.operateResult = new ConcurrentHashMap<>();
    }

}
