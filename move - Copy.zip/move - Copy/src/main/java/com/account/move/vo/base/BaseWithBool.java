package com.account.move.vo.base;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.NotNull;
import java.io.Serializable;

/**
 * @author ：Guo Tao
 * @date ：Created in 2021/3/18 11:18
 * @description：带id的数据vo
 * @modified By：
 * @version: 0.0.1
 */
@Data
public class BaseWithBool implements Serializable {

    @ApiModelProperty("入参参数")
    @NotNull(message = "参数对象不能为空")
    protected Boolean data;
}
