package com.account.move.config;



import com.account.move.annotations.SystemLogType;
import com.account.move.entity.SystemUser;
import com.account.move.entity.log.SystemExceptionLog;
import com.account.move.entity.log.SystemOperateLogEntity;
import com.account.move.serviceUd.ISystemUserServiceUd;
import com.account.move.utils.*;
import com.account.move.vo.R;
import lombok.extern.slf4j.Slf4j;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.AfterThrowing;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;
import org.aspectj.lang.reflect.MethodSignature;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.stereotype.Service;
import org.springframework.web.context.request.RequestAttributes;
import org.springframework.web.context.request.RequestContextHolder;

import javax.servlet.http.HttpServletRequest;
import java.lang.reflect.Method;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

/**
 * @author ：Guo Tao
 * @date ：Created in 2021/3/22 17:59
 * @description：记录操作日志的切面
 * @modified By：
 * @version: 0.0.1
 */
@Slf4j
@Aspect
@Service
public class SystemOperationLogAspect   {

    @Autowired
    MongoTemplate mongoTemplate;

    @Autowired
    ISystemUserServiceUd systemUserServiceUd;

    @Pointcut("@annotation(com.account.move.annotations.SystemLogType)")
    public void operationLogPointCut() {

    }

    /**
     * 设置操作异常切入点记录异常日志 扫描所有controller包下操作
     */
    @Pointcut("execution(* com.account.move.controller..*.*(..))")
    public void operationExceptionLogPointCut() {
    }

    /**
     * 正常返回通知，拦截用户操作日志，连接点正常执行完成后执行， 如果连接点抛出异常，则不会执行
     *
     * @param joinPoint    切入点
     * @param returnResult 返回结果
     */
    @AfterReturning(value = "operationLogPointCut()", returning = "returnResult")
    public void saveOperateLog(JoinPoint joinPoint, Object returnResult) {
        RequestAttributes requestAttributes = RequestContextHolder.getRequestAttributes();
        HttpServletRequest request = (HttpServletRequest) requestAttributes
                .resolveReference(RequestAttributes.REFERENCE_REQUEST);

        SystemOperateLogEntity operateLog = new SystemOperateLogEntity();
        operateLog.setServerUrl(NetWorkUtils.serverUrl);
        operateLog.setUserName(NetWorkUtils.serverUrl);
        operateLog.setRealName(NetWorkUtils.serverUrl);
        try {
            /*** operateLog.setOperateId(UuidUtil.getTimeBasedUuid().toString()); ***/

            /***  从切面织入点处通过反射机制获取织入点处的方法 ***/
            MethodSignature signature = (MethodSignature) joinPoint.getSignature();
            /*** 获取切入点所在的方法 ***/
            Method method = signature.getMethod();
            /*** 获取操作 ***/
            SystemLogType opLog = method.getAnnotation(SystemLogType.class);
            if (opLog != null) {
                /***  BeanUtils.copyProperties(opLog, operateLog);***/
                operateLog.setModuleCode(opLog.moduleCode());
                operateLog.setModuleName(opLog.moduleName());
                operateLog.setOperationCode(opLog.operationCode());
                operateLog.setOperationName(opLog.operationName());
            }
            /*** 获取请求的类名 ***/
            String className = joinPoint.getTarget().getClass().getName();
            /*** 获取请求的方法名 ***/
            String methodName = method.getName();
            methodName = className + "." + methodName;
            /***  请求方法 ***/
            operateLog.setMethod(methodName);
            /*** 请求的参数 ***/
            String[] parameterNames = signature.getParameterNames();
            Object[] args = joinPoint.getArgs();
            Map<String, Object> paraMap = new HashMap<>();
            int size = args.length;
            for (int i = 0; i < size; i++) {
                if (null != args[i]) {
                    String context = args[i].toString();
                    /*** 防止数据过长,占用太多空间() ***/
                    if (context.length() > 100) {
                        paraMap.put(parameterNames[i], context.substring(0, 50));
                    } else {
                        paraMap.put(parameterNames[i], args[i]);
                    }
                }
            }
            paraMap.remove("request");
            paraMap.remove("password");
            log.info("本次日志涉及在参数：{}", paraMap.keySet());
            /*** 将参数所在的数组转换成json ***/
            String params = JsonUtils.serializeToString(paraMap);
            operateLog.setParams(params);
            /***   请求用户ID
            SystemUser user = this.getSystemUserByToken();
            if (null != user) {
                operateLog.setUserId(user.getId());
                operateLog.setRealName(user.getRealName());
                operateLog.setUserName(user.getUsername());
            }***/
            operateLog.setOperateResult(true);
            /*** 记录操作结果 ***/
            R r = (R) returnResult;
            if (null != r && r.getCode() != 0) {
                operateLog.setOperateResult(false);
                operateLog.setFailReason(r.getMsg());
            }
            operateLog.setOperationTime(System.currentTimeMillis());
            String currentDate = TimeUtils.stampToTimeYmdHmsWithUnderLine(operateLog.getOperationTime());
            operateLog.setCreateDate(currentDate);
            operateLog.setOperationUrl(request.getRequestURI());
            operateLog.setOperationIp(this.getIPAddress(request));
            mongoTemplate.save(operateLog);
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    /**
     * 根据获取请求中的ip地址
     *
     * @param request
     * @return
     */
    public String getIPAddress(HttpServletRequest request) {
        try {
            String remoteAddress = "";
            if (request != null) {
                remoteAddress = request.getHeader("X-Forwarded-For");
                if (remoteAddress == null || "".equals(remoteAddress)) {
                    remoteAddress = request.getRemoteAddr();
                }
            }
            remoteAddress = remoteAddress != null && remoteAddress.contains(",") ? remoteAddress.split(",")[0] : remoteAddress;
            return remoteAddress;
        } catch (Exception e) {
            return null;
        }
    }

    /**
     * 根据操作连接中的token 取用户信息
     *
     * @return com.thyd.core.db.users.entity.UserEntity
     * @Description
     * @Date
     * @author writer
     **/
    private SystemUser getSystemUserByToken() {
        String token = AdminCommonMethod.getUserToken();
        Long uid = TokenCollection.tokenMap.get(token);
        SystemUser user =  systemUserServiceUd.getUserById(uid);
        return user;
    }

    /**
     * 异常返回通知，用于拦截异常日志信息 连接点抛出异常后执行
     *
     * @param joinPoint 切入点
     * @param e         异常信息
     */
    @AfterThrowing(pointcut = "operationExceptionLogPointCut()", throwing = "e")
    public void saveExceptionLog(JoinPoint joinPoint, Throwable e) {
        RequestAttributes requestAttributes = RequestContextHolder.getRequestAttributes();
        /***  从获取RequestAttributes中获取HttpServletRequest的信息 ***/
        HttpServletRequest request = (HttpServletRequest) requestAttributes
                .resolveReference(RequestAttributes.REFERENCE_REQUEST);

        SystemExceptionLog exceptionLog = new SystemExceptionLog();
        try {
            /*** 从切面织入点处通过反射机制获取织入点处的方法 ***/
            MethodSignature signature = (MethodSignature) joinPoint.getSignature();
            /***  获取切入点所在的方法 ***/
            Method method = signature.getMethod();
            /***获取请求的类名  ***/
            String className = joinPoint.getTarget().getClass().getName();
            /*** 获取请求的方法名 ***/
            String methodName = method.getName();
            methodName = className + "." + methodName;

            String[] parameterNames = signature.getParameterNames();
            Object[] args = joinPoint.getArgs();
            Map<String, Object> paraMap = new HashMap<>();
            int size = args.length;
            for (int i = 0; i < size; i++) {
                if (null != args[i]) {
                    String context = args[i].toString();
                    /*** 防止数据过长,占用太多空间() ***/
                    if (context.length() > 100) {
                        paraMap.put(parameterNames[i], context.substring(0, 50));
                    } else {
                        paraMap.put(parameterNames[i], args[i]);
                    }
                }
            }
            /*** 将参数所在的数组转换成json ***/
            String params = JsonUtils.serializeToString(paraMap);
            exceptionLog.setMethod(methodName);
            exceptionLog.setParams(params);

            SystemUser user = this.getSystemUserByToken();
            if (null != user) {
                exceptionLog.setUserId(user.getId());
                exceptionLog.setRealName(NetWorkUtils.serverUrl);
                exceptionLog.setUserName(user.getUsername());
            }
            exceptionLog.setErrorMessage(this.stackTraceToString(e.getClass().getName(), e.getMessage(), e.getStackTrace()));
            exceptionLog.setOperationTime(System.currentTimeMillis());
            SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
            Date date = new Date(System.currentTimeMillis());
            String currentDate = simpleDateFormat.format(date);
            exceptionLog.setCreateDate(currentDate);
            exceptionLog.setOperationUrl(request.getRequestURI());
            exceptionLog.setOperationIp(this.getIPAddress(request));
            mongoTemplate.save(exceptionLog);
        } catch (Exception e2) {
            e2.printStackTrace();
        }
    }


    /**
     * 转换异常信息为字符串
     *
     * @param exceptionName    异常名称
     * @param exceptionMessage 异常信息
     * @param elements         堆栈信息
     */
    public String stackTraceToString(String exceptionName, String exceptionMessage, StackTraceElement[] elements) {
        StringBuffer stringBuffer = new StringBuffer();
        for (StackTraceElement stet : elements) {
            stringBuffer.append(stet + "\n");
        }
        String message = exceptionName + ":" + exceptionMessage + "\n\t" + stringBuffer.toString();
        return message;
    }
}