package com.account.move.utils;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import lombok.Data;

import java.util.ArrayList;
import java.util.List;

/**
 * @author ：Guo Tao
 * @date ：Created in 2021/3/9 9:22
 * @description：分页相关的工具
 * @modified By：
 * @version: 0.0.1
 */
@Data
public class PageUtils {
    public static <T> List<T> subList(List<T> list, long size, long pageNum){
        StartEnd startEnd = get(size, pageNum, list.size());
        if(!startEnd.checkValidate()){
            return new ArrayList<>();
        }
        return list.subList(startEnd.getStart(), startEnd.getEnd());
    }

    public static Page checkPage(Page page) {
        if (page == null) {
            page = new Page();
        } else {
            if (page.getCurrent() < 1) {
                page.setCurrent(1);
            }
            if (page.getSize() < 1) {
                page.setSize(10);
            }
        }
        return page;
    }

    public static StartEnd get(int size, int pageNum) {
        int start = (size * (pageNum - 1));
        int end = start + size;
        return new StartEnd((size * (pageNum - 1)), start + size);
    }


    public static StartEnd get(int size, int pageNum, int total) {
        int start = (size * (pageNum - 1));
        if (start >= total) {
            return new StartEnd(0, 0);
        }
        int min = Math.min(total, start + size);
        return new StartEnd(start, min);
    }

    public static StartEnd get(long size, long pageNum) {
        long start = (size * (pageNum - 1));
        return new StartEnd((size * (pageNum - 1)), start + size);
    }

    public static StartEnd get(long size, long pageNum, long total) {
        long start = (size * (pageNum - 1));
        if (start >= total) {
            return new StartEnd(0, 0);
        }
        long min = Math.min(total, start + size);
        return new StartEnd((size * (pageNum - 1)), min);
    }

    public static StartEnd getByReversePage(int size, int pageNum, int total) {
        long start = (size * (pageNum - 1));
        if (start >= total) {
            return new StartEnd(0, 0);
        }
        long min = Math.min(total, start + size);
        return getByReverseOrder((size * (pageNum - 1)), min, total);
    }

    public static StartEnd getByReversePage(long size, long pageNum, long total) {
        return getByReversePage((int) size, (int) pageNum, (int) total);
    }

    public static StartEnd getByReverseOrder(int start, int end, int total) {
        if (start >= total || start >= end) {
            return new StartEnd(0, 0);
        }
        int min = Math.min(total, end);
        return new StartEnd(total - min, total - start);
    }

    public static StartEnd getByReverseOrder(long start, long end, long total) {
        return getByReverseOrder((int) start, (int) end, (int) total);
    }

    public static StartEnd newEntry(int start, int end, int total) {
        if (start < 0) {
            start = 0;
        }
        int min = Math.min(total, end);
        if (start >= min) {
            return new StartEnd(0, 0);
        }
        return new StartEnd(start, min);
    }

    public static StartEnd newEntry(int start, int end) {
        return newEntry(start, end, end);
    }

    public static StartEnd newEntry(long start, long end) {
        return newEntry((int) start, (int) end);
    }

    public static StartEnd newEntry(long start, long end, long total) {
        return newEntry((int) start, (int) end, (int) total);
    }

    @Data
    public static class StartEnd {

        int start;

        int end;

        public StartEnd(int start, int end) {
            this.start = start;
            this.end = end;
        }

        public StartEnd(long start, long end) {
            this.start = (int) start;
            this.end = (int) end;
        }

        public boolean checkValidate() {
            if (end > start) {
                return true;
            }
            return false;
        }
    }
}
