package com.account.move.vo.base;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import lombok.Data;

/**
 * @ClassNmae BasePage
 * @Description  基础查询vo
 * @Author writer
 * @Author writer
 * @Date 2021/2/11  15:45
 **/
@Data
public class BasePage<T> extends Page {

    public BasePage(long current, long size) {
        super(current, size);
    }

    public BasePage() {
    }

}
