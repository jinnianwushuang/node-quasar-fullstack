package com.account.move.service;

import com.account.move.vo.task.InviteTaskRequestVo;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;

public interface IInviteTaskService {

    Page queryInviteTask(InviteTaskRequestVo vo);

    boolean deleteById(String id);
}
