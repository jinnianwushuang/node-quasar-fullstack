package com.account.move.vo.telegrambusiness;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import org.hibernate.validator.constraints.Length;

import javax.validation.constraints.NotNull;

/**
 * @author writer
 * @title: TgLoginVo
 * @projectName collectUser
 * @description: 添加tg电话号码的vo
 * @date 2021/12/816:40
 */
@Data
public class TgLoginVo {

    @ApiModelProperty(value = "区号")
    @Length(min = 1, max = 4, message = "电话号码信息的区号长度必须在[1,4]范围内")
    @NotNull(message = "电话号码信息的区号不能为空")
    private String regionCode;

    @ApiModelProperty(value = "电话号码")
    @Length(min = 5, max = 20, message = "电话号码长度必须在[5,20]范围内")
    @NotNull(message = "电话号码不能为空")
    private String phoneNumber;
}
