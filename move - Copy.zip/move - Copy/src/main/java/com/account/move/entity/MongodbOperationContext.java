package com.account.move.entity;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.data.util.Pair;

import java.util.List;

/**
 * @author writer
 * @title: MongodbOperationContext
 * @projectName checkAccount
 * @description: mongodb 桶操作上下文
 * @date 2021/12/1317:00
 */
@Data
public class MongodbOperationContext {

    @ApiModelProperty("设计的collection名称")
    String collectionName;

    @ApiModelProperty("具体的操作")
    List<Pair<Query, Update>> operationList;

    public MongodbOperationContext(String collectionName, List<Pair<Query, Update>> operationList) {
        this.collectionName = collectionName;
        this.operationList = operationList;
    }

    public MongodbOperationContext() {
    }
}
