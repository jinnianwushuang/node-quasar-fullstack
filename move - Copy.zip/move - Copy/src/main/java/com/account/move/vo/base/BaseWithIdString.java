package com.account.move.vo.base;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.NotNull;
import java.io.Serializable;

/**
 * @author ：Guo Tao
 * @date ：Created in 2021/3/18 11:18
 * @description：仅带一个字符串的入参对象
 * @modified By：
 * @version: 0.0.1
 */
@Data
public class BaseWithIdString implements Serializable {

    @ApiModelProperty("id")
    @NotNull(message = "参数不能为空")
    private String id;
}
