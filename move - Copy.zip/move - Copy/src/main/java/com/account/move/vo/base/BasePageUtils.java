package com.account.move.vo.base;

/**
 * @ClassNmae BasePageUtils
 * @Description
 * @Author liubaohong
 * @Date 2021/3/26  9:28
 **/

public class BasePageUtils {
    public static BasePage checkPage(BasePage page) {
        if (page == null) {
            page = new BasePage();
        } else {
            if (page.getCurrent() < 1) {
                page.setCurrent(1);
            }
            if (page.getSize() < 1) {
                page.setSize(10);
            }
        }
        return page;
    }
}
