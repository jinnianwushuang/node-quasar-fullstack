package com.account.move.entity;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * @author writer
 * @title: VerifyCodeEntity
 * @projectName checkAccount
 * @description:
 * @date 2021/12/1415:23
 */
@Data
public class VerifyCodeEntity {

    @ApiModelProperty("验证码")
    private String verifyCode;

    @ApiModelProperty("过期时间戳(单位：毫秒)")
    private Long expireTime;

    public VerifyCodeEntity(String verifyCode, Long expireTime) {
        this.verifyCode = verifyCode;
        this.expireTime = expireTime;
    }
}
