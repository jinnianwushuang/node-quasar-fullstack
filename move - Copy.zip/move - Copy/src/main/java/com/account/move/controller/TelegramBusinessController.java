package com.account.move.controller;

import com.account.move.annotations.SystemLogType;
import com.account.move.entity.AddContactVo;
import com.account.move.service.ITelegramBusinessService;
import com.account.move.vo.R;
import com.account.move.vo.base.BaseWithId;
import com.account.move.vo.telegrambusiness.*;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

/**
 * @author writer
 * @title: TelegramBussinessController
 * @projectName collectUser
 * @description: 关于电报通讯软件的具体业务
 * @date 2021/12/818:14
 */

@Slf4j
@RestController
@RequestMapping("api/tgBusiness")
@Api(value = "关于电报通讯软件的具体业务", tags = {"关于电报通讯软件的具体业务"})
public class TelegramBusinessController {

    @Autowired
    private ITelegramBusinessService telegramBusinessService;

    /*****
     * @description: 准备登录某个电话号码的tg账号(必须保证当前电话号码的tg账号是非登录状态), 该消息发送后需要等待几秒钟后，
     *
     * @param vo  需要登录的电话号码id的对象
     * @return com.account.core.vo.R
     * @throws
     * @author writer
     * @date 2021/12/8 19:45
     ****/
    @PostMapping("/login")
    @ApiOperation(value = "根据电话号码ID准备登录tg", notes = "根据电话号码ID准备登录tg")
    @SystemLogType(moduleCode = "TgService", moduleName = "TG业务", operationCode = "login", operationName = "账号登陆")
    public R readyLoginByTelephoneNumber(@RequestBody @Validated TgLoginVo vo) {
        return telegramBusinessService.readyLoginByTelephoneNumber(vo);
    }

    /*****
     * @description: 指定号码发送登录请求后，tg会受到验证码，该方法发送验证码服务器
     * @param vo  业务参数vo
     * @return com.account.core.vo.R
     * @throws
     * @author writer
     * @date 2021/12/8 19:45
     ****/
    @PostMapping("/verifyCode")
    @ApiOperation(value = "根据电话号码ID发送tg验证码", notes = "根据电话号码ID发送tg验证码")
    @SystemLogType(moduleCode = "TgService", moduleName = "TG业务", operationCode = "verifyCode", operationName = "发送验证码")
    public R verifyCode(@RequestBody @Validated VerifyCodeVo vo) {
        return telegramBusinessService.sendVerifyCode(vo.getVerifyCode());
    }

    /*******
     * @description: 退出登录的接口
     * @return com.account.core.vo.R
     * @throws
     * @author writer
     * @date 2021/12/8 20:51
     ****/
    @GetMapping("/logout")
    @ApiOperation(value = "用户退出登录", notes = "用户退出登录")
    @SystemLogType(moduleCode = "TgService", moduleName = "TG业务", operationCode = "logout", operationName = "用户退出登录")
    public R logout() {
        return telegramBusinessService.logout();
    }


    /*******
     * @description: 查询系统概览信息
     * @return com.account.core.vo.R
     * @throws
     * @author writer
     * @date 2021/12/8 20:51
     ****/
    @GetMapping("/overView")
    @ApiOperation(value = "系统概览", notes = "系统概览")
    @SystemLogType(moduleCode = "TgService", moduleName = "TG业务", operationCode = "overView", operationName = "系统概览")
    public R overView() {
        return telegramBusinessService.overView();
    }


    /******
     * @description: 新建群组
     * @param vo     新建群组的参数
     * @return com.account.core.vo.R
     * @throws
     * @author writer
     * @date 2021/12/8 20:49
     ****/
    @PostMapping("/createNewGroup")
    @ApiOperation(value = "新建群组", notes = "新建群组")
    @SystemLogType(moduleCode = "TgService", moduleName = "TG业务", operationCode = "createNewGroup", operationName = "新建群组")
    public R createNewGroup(@RequestBody @Validated AddGroupVo vo) {
        return telegramBusinessService.createNewGroup(vo.getTitle(), vo.getDescription(), vo.getIsChannel(), vo.isForImport());
    }

    @PostMapping("/queryGroup")
    @ApiOperation(value = "查询群组信息", notes = "查询群组信息")
    public R queryGroup(@RequestBody @Validated QueryGroupVo page) {
        return telegramBusinessService.queryGroup(page);
    }

    @PostMapping("/queryGroupMember")
    @ApiOperation(value = "查询群组的用户信息", notes = "查询群组的用户信息")
    @SystemLogType(moduleCode = "TgService", moduleName = "TG业务", operationCode = "queryGroupMember", operationName = "补充群组的用户信息")
    public R queryGroupMember(@RequestBody @Validated BaseWithId vo) {
        return telegramBusinessService.queryGroupMember(vo.getId());
    }

    /*****
     * @description: 将指定群的用户采集到 目标群组
     * @param vo   数据迁移操作参数
     * @return com.account.core.vo.R
     * @throws
     * @author writer
     * @date 2021/12/8 20:15
     ****/
    @PostMapping("/migrate")
    @ApiOperation(value = "将指定群的用户采集到目标群组", notes = "将指定群的用户采集到目标群组")
    @SystemLogType(moduleCode = "TgService", moduleName = "TG业务", operationCode = "migrateUserToGroup", operationName = "将指定群的用户采集到目标群组")
    public R migrateUserToGroup(@RequestBody @Validated MigrateGroupVo vo) {
        return telegramBusinessService.migrateUserToGroup(vo.getSrcGroupId(), vo.getDstGroupId());
    }


    @PostMapping("/addMemberToGroup")
    @ApiOperation(value = "添加某个用户到某个聊天", notes = "添加某个用户到某个聊天")
    @SystemLogType(moduleCode = "TgService", moduleName = "TG业务", operationCode = "addMemberToGroup", operationName = "添加某个用户到指定聊天群")
    public R addMemberToGroup(long chatId, long userId) {
        return telegramBusinessService.addMemberToGroup(chatId, userId);
    }

    @PostMapping("/getChatMember")
    @ApiOperation(value = "查询群组里边某个用户", notes = "查询群组里边某个用户")

    public R getChatMember(long userId, long chatId) {
        return telegramBusinessService.getChatMember(userId, chatId);
    }


    @PostMapping("/addContact")
    @ApiOperation(value = "添加某个用户到联系人", notes = "添加某个用户到联系人")
    public R addContact(@RequestBody @Validated AddContactVo vo) {
        return telegramBusinessService.addContact(vo);
    }

    @PostMapping("/inviteMultiUser")
    @ApiOperation(value = "同时邀请多个人", notes = "同时邀请多个人")
    public R inviteMultiUser(@RequestBody AddMultiUser vo) {
        /***    用户id列表
         912927615       //正常添加
         1906138760      //正常添加
         1022684096      //正常添加
         1853076769      //正常添加
         2123366021      //"User not found
         2130066479  // 隐私设置无法添加

         聊天群id
         -1001553377303
         ***/
        return telegramBusinessService.inviteMultiUser(vo.getChatId(), vo.getUserIds());
    }

}
