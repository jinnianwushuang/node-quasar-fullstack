package com.account.move.service;


import com.account.move.vo.R;
import com.account.move.vo.login.LoginWithAccountVo;
import com.account.move.vo.login.TelephoneBaseVo;
import com.account.move.vo.login.TelephoneVerifyCodeVo;

/**
 * @author ：Guo Tao
 * @date ：Created in 2021/2/7 9:48
 * @description：当前平台用户登录服务
 * @modified By：
 * @version: 0.0.1
 */
public interface IUserLoginService {

    /**
     * Create by: writer
     * Description:  根据手机号码获取验证码
     *
     * @param vo 获取验证码的参数vo
     * @return R 操作结果vo
     * Create time:
     */
    R getVerifyCode(TelephoneBaseVo vo);

    /**
     * Create by: writer
     * Description:  当前平台用户登录vo
     *
     * @param vo 当前平台登录vo
     * @return Create time:
     */
    R userLoginTelephone(TelephoneVerifyCodeVo vo);

    /**
     * 用户登出服务
     *
     * @param
     * @return com.thyd.core.vo.R
     * @Description
     * @Date
     * @author writer
     **/
    R loginOut();

    R loginWithAccount(LoginWithAccountVo vo);
}
