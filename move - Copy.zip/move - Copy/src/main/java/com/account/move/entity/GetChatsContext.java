package com.account.move.entity;

import lombok.Data;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

@Data
public class GetChatsContext {

    Map<Long, Object> chatsMap;


    public GetChatsContext() {
        this.chatsMap = new ConcurrentHashMap<>();
    }

}
