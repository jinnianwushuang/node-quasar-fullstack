package com.account.move.entity;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.util.concurrent.ConcurrentHashMap;

/*** 给指定超级群组上下文的    ***/

@Data
public class AddChatMemberContext {

    @ApiModelProperty("需要从 这个群邀请用户的id")
    private Long srcChatId;

    @ApiModelProperty("需要降用户邀请到群的id")
    private Long dstChatId;

    @ApiModelProperty("邀请用户失败的错误信息")
    private ConcurrentHashMap<Long, String> errorMsg;

    @ApiModelProperty("邀请的用户id")
    private ConcurrentHashMap<Long, String> succeed;

    public AddChatMemberContext(Long dstChatId) {
        this.dstChatId = dstChatId;
        this.errorMsg = new ConcurrentHashMap<>();
        this.succeed = new ConcurrentHashMap<>();
    }
}
