package com.account.move.utils;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.*;
import org.springframework.util.ObjectUtils;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.List;
import java.util.Map;

/**
 * @ClassNmae JsonUtil
 * @Description json工具类
 * @autho writer
 * @Date 2020/4/22  9:53
 **/
public class JsonUtils {

    public static ObjectMapper objectMapper = new ObjectMapper();


    static {
        /*** 序列化的时候序列对象的所有属性 ***/
        objectMapper.setSerializationInclusion(JsonInclude.Include.ALWAYS);

        /***反序列化的时候如果多了其他属性,不抛出异常***/
        objectMapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);

        /***如果是空对象的时候,不抛异常***/
        objectMapper.configure(SerializationFeature.FAIL_ON_EMPTY_BEANS, false);

        /*** 取消时间的转化格式,默认是时间戳,可以取消,同时需要设置要表现的时间格式***/
        objectMapper.configure(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS, false);
        objectMapper.setDateFormat(new SimpleDateFormat("yyyy-MM-dd HH:mm:ss"));

    }

    public static String serializeToString(Object o) {
        if (o == null) {
            return null;
        }
        try {
            return objectMapper.writeValueAsString(o);
        } catch (JsonProcessingException e) {
            e.printStackTrace();
        }
        return null;
    }


    public static <T> T parseObject(String json, Class<T> cla) {
        if (json == null || json.equals("")) {
            return null;
        }
        try {
            return objectMapper.readValue(json, cla);
        } catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }

    public static <T> List<T> parseObjectList(String json, Class<T> cla) {
        if (json == null || json.equals(""))
            return null;
        try {
            JavaType javaType = JsonUtils.objectMapper.getTypeFactory().constructParametricType(List.class, cla);
            List<T> list = JsonUtils.objectMapper.readValue(json, javaType);
            return list;
        } catch (IOException e) {
            e.printStackTrace();
        }
        return null;

    }

    /**
     * @param json    json 字符串
     * @param nodeKey json 字符串中的某个 key 值
     * @return java.lang.String nodeKey 对应的 value
     * @description 指定 json 字符串取出某个 key 对应的 value
     * @author liubaohong
     * @date 2021/5/14
     */
    public static String getStringNode(String json, String nodeKey) {
        ObjectMapper mapper = new ObjectMapper();
        try {
            JsonNode node = mapper.readTree(json);
            JsonNode data = node.get(nodeKey);

            if (ObjectUtils.isEmpty(data)) {
                return "";
            }
            return data.asText();
        } catch (Exception e) {
            e.printStackTrace();
        }

        return "";
    }

    /**
     * @param jsonStr json 字符串
     * @return java.util.Map<java.lang.Object, java.lang.Object> json 对应的 map
     * @description 将 jsopn 字符串转换为 map
     * @author liubaohong
     * @date 2021/5/14
     */
    public static Map<String, Object> jsonToMap(String jsonStr, Class<?> valueClass) {
        try {
            Map<String, Object> map = objectMapper.readValue(jsonStr, Map.class);
            return map;
        } catch (JsonParseException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } catch (JsonMappingException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        return null;
    }
}
