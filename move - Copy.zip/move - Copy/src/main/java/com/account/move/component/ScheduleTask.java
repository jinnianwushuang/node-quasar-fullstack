package com.account.move.component;


import com.account.move.config.TaskInfoInterface;
import com.account.move.entity.*;
import com.account.move.tg.TgService;
import com.account.move.utils.AdminCommonMethod;
import com.account.move.utils.TokenCollection;
import lombok.extern.slf4j.Slf4j;
import org.drinkless.tdlib.TdApi;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.data.util.Pair;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.util.CollectionUtils;
import org.springframework.util.ObjectUtils;

import java.lang.reflect.Field;
import java.util.*;

/**
 * @author writer
 * @title: ScheduleTask
 * @projectName checkAccount
 * @description:
 * @date 2021/12/1221:56
 */

@Slf4j
@Configuration
@EnableScheduling
public class ScheduleTask {

    @Autowired
    MongoTemplate mongoTemplate;


    private Map<String, List<Field>> fieldMaps = new HashMap<>();

    @Scheduled(cron = "0/5 * * * * ?")
    //或直接指定时间间隔，例如：5秒
    //@Scheduled(fixedRate=5000)
    public void updateInfo() {
        updateOrInsertTgAccountData();
        updateTgAccount();

    }

    /*** 上述是upsert    ***/
    public void updateOrInsertTgAccountData() {
        /***
         * 1.处理用户信息；
         * 2. 处理超级群组信息;
         * 3. 处理聊天信息
         *                     && TdApi.AuthorizationStateWaitCode.CONSTRUCTOR == account.getAuthorizationState().getConstructor()
         * 2.仅处理更新的用户信息，简单群组信息；超级群组信息,更新后的数据冲更新列表中删除
         * ***/

        List<MongodbOperationContext> contexts = new ArrayList<>();
        /*** 处理用户信息    ***/
        this.updateUserInfo(contexts);

        /*** 处理聊天相关的信息    ***/
        this.updateChatInfo(contexts);
        /*** 更新数据库    ***/
        contexts.forEach(e -> {
            if (!CollectionUtils.isEmpty(e.getOperationList())) {
                AdminCommonMethod.updateOrInsertBulkOperation(mongoTemplate, e);
            }
        });
    }

    /*** 现在是update    ***/
    private void updateTgAccount() {

        List<MongodbOperationContext> contexts = new ArrayList<>();

        List<Pair<Query, Update>> userOperationList = new ArrayList<>();
        /*** 降超级群的信息补充到对应的聊天中    ***/
        Map<Long, TdApi.SupergroupFullInfo> superGroupFullInfoMap = TgService.supergroupsFullInfo;
        Set<Long> superGroupIds = superGroupFullInfoMap.keySet();
        superGroupIds.forEach(e -> userOperationList.add(this.constructQueryUpdatePairForChatMemberCount(e, superGroupFullInfoMap.get(e))));
        log.info("更新超级群组id列表:{}", superGroupIds);
        contexts.add(new MongodbOperationContext(TdApi.Chat.class.getSimpleName(), userOperationList));
        /*** 更新数据库    ***/
        contexts.forEach(e -> {
            if (!CollectionUtils.isEmpty(e.getOperationList())) {
                AdminCommonMethod.updateBulkOperation(mongoTemplate, e);
            }
        });

    }

    private void updateUserInfo(List<MongodbOperationContext> contexts) {
        /***  更新用户信息  ***/
        List<Pair<Query, Update>> userOperationList = new ArrayList<>();
        Map<Long, TdApi.User> users = TgService.users;
        Map<Long, TdApi.UserFullInfo> fullInfo = TgService.usersFullInfo;
        Set<Long> userIds = users.keySet();
        userIds.forEach(e -> {
            userOperationList.add(this.constructQueryUpdatePair(e, users.get(e)));
        });
        userIds.forEach(
                e -> {
                    users.remove(e);
                }
        );
        userIds = fullInfo.keySet();
        userIds.forEach(e -> {
            userOperationList.add(this.constructQueryUpdatePair(e, fullInfo.get(e)));
        });
        userIds.forEach(
                e -> {
                    fullInfo.remove(e);
                }
        );
        contexts.add(new MongodbOperationContext(TdApi.User.class.getSimpleName(), userOperationList));
    }

    private void updateSuperGroupInfo(List<MongodbOperationContext> contexts) {
        /***  处理超级群组消息 ***/
        List<Pair<Query, Update>> superGroupOperationList = new ArrayList<>();
        Map<Long, TdApi.Supergroup> superGroupMap = TgService.supergroups;
        Map<Long, TdApi.SupergroupFullInfo> superGroupFullInfoMap = TgService.supergroupsFullInfo;
        Set<Long> superGroupIds = superGroupMap.keySet();
        superGroupIds.forEach(e -> superGroupOperationList.add(this.constructQueryUpdatePair(e, superGroupMap.get(e))));
        superGroupIds.forEach(e -> superGroupMap.remove(e));
        superGroupIds = superGroupFullInfoMap.keySet();
        log.info("update groupFullInfo. keys:{}", superGroupFullInfoMap.keySet());
        superGroupIds.forEach(e -> superGroupOperationList.add(this.constructQueryUpdatePairForSuperGroup(e, superGroupFullInfoMap.get(e))));
        contexts.add(new MongodbOperationContext(TdApi.Supergroup.class.getSimpleName(), superGroupOperationList));
    }

    private void updateChatInfo(List<MongodbOperationContext> contexts) {
        /***  更新超级群组的title  ***/
        List<Pair<Query, Update>> userOperationList = new ArrayList<>();
        Map<Long, TdApi.Chat> chatGroup = TgService.chats;
        Set<Long> chatIds = chatGroup.keySet();
        log.info("更新聊天的信息的id列表: {}", chatIds);
        chatIds.forEach(e -> userOperationList.add(this.constructQueryUpdatePair(e, chatGroup.get(e))));

        contexts.add(new MongodbOperationContext(TdApi.Chat.class.getSimpleName(), userOperationList));
    }

    private Pair<Query, Update> constructQueryUpdatePair(Long superGroupId, ChatGroupRelationEntity entity) {
        Update update = new Update();
        if (entity.getChatId() != 0) {
            update.set("linkedChatId", entity.getChatId());
        }
        update.set("title", entity.getTitle());
        return Pair.of(Query.query(Criteria.where("_id").is(superGroupId)), update);
    }

    private Pair<Query, Update> constructQueryUpdatePair(Long chatId, TdApi.Chat chat) {
        Update update = new Update();
        update.set("title", chat.title);
        if (!ObjectUtils.isEmpty(chat.photo)) {
            update.set("photo", chat.photo.big.remote.id);
        }
        update.set("unreadCount", chat.unreadCount);
        update.set("messageTtlSetting", chat.messageTtlSetting);
        update.set("notificationSettings", chat.notificationSettings);
        update.set("themeName", chat.themeName);
        update.set("actionBar", chat.actionBar);
        update.set("pendingJoinRequests", chat.pendingJoinRequests);
        TdApi.ChatTypeSupergroup chatTypeSupergroup = (TdApi.ChatTypeSupergroup) chat.type;
        update.set("superGroupId", chatTypeSupergroup.supergroupId);
        update.set("replyMarkupMessageId", chat.replyMarkupMessageId);
        update.set("clientData", chat.clientData);
        return Pair.of(Query.query(Criteria.where("_id").is(chatId)), update);
    }

    private Pair<Query, Update> constructQueryUpdatePair(Long userId, TdApi.User user) {
        Update update = new Update();
        update.set("firstName", user.firstName);
        update.set("lastName", user.lastName);
        update.set("username", user.username);
        update.set("phoneNumber", user.phoneNumber);
        update.set("status", user.status);
        update.set("type", user.type);
        update.set("profilePhoto", user.profilePhoto);
        update.set("isMutualContact", user.isMutualContact);
        update.set("isVerified", user.isVerified);
        update.set("restrictionReason", user.restrictionReason);
        update.set("languageCode", user.languageCode);
        return Pair.of(Query.query(Criteria.where("_id").is(userId)), update);
    }

    private Pair<Query, Update> constructQueryUpdatePair(Long userId, TdApi.UserFullInfo user) {
        Update update = new Update();
        update.set("isBlocked", user.isBlocked);
        update.set("canBeCalled", user.canBeCalled);
        update.set("supportsVideoCalls", user.supportsVideoCalls);
        update.set("needPhoneNumberPrivacyException", user.needPhoneNumberPrivacyException);
        update.set("bio", user.bio);
        update.set("shareText", user.shareText);
        update.set("description", user.description);
        update.set("groupInCommonCount", user.groupInCommonCount);
        return Pair.of(Query.query(Criteria.where("_id").is(userId)), update);
    }

    private Pair<Query, Update> constructQueryUpdatePair(Long userId, TdApi.Supergroup group) {
        Update update = new Update();
        update.set("username", group.username);
        update.set("date", group.date);
        update.set("status", group.status);
        update.set("memberCount", group.memberCount);


        update.set("hasLinkedChat", group.hasLinkedChat);
        update.set("hasLocation", group.hasLocation);
        update.set("signMessages", group.signMessages);
        update.set("isSlowModeEnabled", group.isSlowModeEnabled);


        update.set("isChannel", group.isChannel);
        update.set("isBroadcastGroup", group.isBroadcastGroup);
        update.set("isVerified", group.isVerified);
        update.set("restrictionReason", group.restrictionReason);
        update.set("isScam", group.isScam);
        update.set("isFake", group.isFake);
        return Pair.of(Query.query(Criteria.where("_id").is(userId)), update);
    }

    private Pair<Query, Update> constructQueryUpdatePair(Long userId, TdApi.SupergroupFullInfo group) {
        Update update = new Update();
        update.set("description", group.description);
        //log.info("超级群组：id:{},description:{}, group.linkedChatId：{}", userId, group.description, group.linkedChatId);
        update.set("memberCount", group.memberCount);
        update.set("administratorCount", group.administratorCount);
        update.set("restrictedCount", group.restrictedCount);
        update.set("bannedCount", group.bannedCount);
        update.set("slowModeDelay", group.slowModeDelay);

        if (group.linkedChatId != 0) {
            update.set("linkedChatId", group.linkedChatId);
        }

        update.set("canGetMembers", group.canGetMembers);
        update.set("canSetUsername", group.canSetUsername);
        update.set("canSetStickerSet", group.canSetStickerSet);
        update.set("canSetLocation", group.canSetLocation);
        update.set("canGetStatistics", group.canGetStatistics);
        update.set("isAllHistoryAvailable", group.isAllHistoryAvailable);
        update.set("stickerSetId", group.stickerSetId);
        update.set("upgradedFromBasicGroupId", group.upgradedFromBasicGroupId);
        update.set("upgradedFromMaxMessageId", group.upgradedFromMaxMessageId);
        return Pair.of(Query.query(Criteria.where("_id").is(userId)), update);
    }


    private Pair<Query, Update> constructQueryUpdatePairForSuperGroup(Long userId, TdApi.SupergroupFullInfo group) {
        Update update = new Update();
        update.set("description", group.description);
        //log.info("超级群组：id:{},description:{}, group.linkedChatId：{}", userId, group.description, group.linkedChatId);
        update.set("memberCount", group.memberCount);
        update.set("administratorCount", group.administratorCount);
        update.set("restrictedCount", group.restrictedCount);
        update.set("bannedCount", group.bannedCount);
        update.set("slowModeDelay", group.slowModeDelay);

        if (group.linkedChatId != 0) {
            update.set("linkedChatId", group.linkedChatId);
        }

        update.set("canGetMembers", group.canGetMembers);
        update.set("canSetUsername", group.canSetUsername);
        update.set("canSetStickerSet", group.canSetStickerSet);
        update.set("canSetLocation", group.canSetLocation);
        update.set("canGetStatistics", group.canGetStatistics);
        update.set("isAllHistoryAvailable", group.isAllHistoryAvailable);
        update.set("stickerSetId", group.stickerSetId);
        update.set("upgradedFromBasicGroupId", group.upgradedFromBasicGroupId);
        update.set("upgradedFromMaxMessageId", group.upgradedFromMaxMessageId);
        return Pair.of(Query.query(Criteria.where("_id").is(userId)), update);
    }


    private Pair<Query, Update> constructQueryUpdatePairForChatMemberCount(Long groupId, TdApi.SupergroupFullInfo group) {
        Update update = new Update();
        update.set("description", group.description);
        update.set("memberCount", group.memberCount);
        update.set("administratorCount", group.administratorCount);
        update.set("restrictedCount", group.restrictedCount);
        update.set("bannedCount", group.bannedCount);
        update.set("slowModeDelay", group.slowModeDelay);

        if (group.linkedChatId != 0) {
            update.set("linkedChatId", group.linkedChatId);
        }
        if (!ObjectUtils.isEmpty(group.inviteLink)) {
            update.set("inviteLink", group.inviteLink.inviteLink);
        }
        update.set("canGetMembers", group.canGetMembers);
        update.set("canSetUsername", group.canSetUsername);
        update.set("canSetStickerSet", group.canSetStickerSet);
        update.set("canSetLocation", group.canSetLocation);
        update.set("canGetStatistics", group.canGetStatistics);
        update.set("isAllHistoryAvailable", group.isAllHistoryAvailable);
        update.set("stickerSetId", group.stickerSetId);
        update.set("upgradedFromBasicGroupId", group.upgradedFromBasicGroupId);
        update.set("upgradedFromMaxMessageId", group.upgradedFromMaxMessageId);
        return Pair.of(Query.query(Criteria.where("superGroupId").is(groupId)), update);
    }


    @Scheduled(cron = "0/1 * * * * ?")
    public void cleanExpireDataInMemory() {
        /***
         * 1.处理过期的token
         * 2.处理过期的验证码
         * ***/
        Set<String> keys = TokenCollection.verifyCodeMap.keySet();
        keys.forEach(e -> {
            VerifyCodeEntity verifyCodeEntity = TokenCollection.verifyCodeMap.get(e);
            if (verifyCodeEntity.getExpireTime() <= System.currentTimeMillis()) {
                verifyCodeEntity.setExpireTime(null);
                verifyCodeEntity.setVerifyCode(null);
                TokenCollection.verifyCodeMap.remove(e);
            }
        });
    }


    /*** 邀请用户加入群的 定时任务    ***/
    @Scheduled(cron = "0 */30 * * * ?")
    public void inviteUserToGroup() {
        log.info("每2分钟一次的邀请任务开始执行");
        Query query = Query.query(Criteria.where("leftUserNumber").exists(true).gt(0));
        query.with(Sort.by(Sort.Order.desc("createTimeStamp")));
        Pageable pageable = PageRequest.of(0, 1);
        InviteTaskEntity entity = mongoTemplate.findOne(query.with(pageable), InviteTaskEntity.class);
        if (ObjectUtils.isEmpty(entity)) {
            log.info("每2分钟一次的邀请任务执行结束");
            return;
        }
        /*** 找到本次需要邀请的用户id    ***/
        Set<Long> inviteUserIds = this.getInvitedUserIdByTask(entity);
        if (CollectionUtils.isEmpty(inviteUserIds)) {
            log.info("每2分钟一次的邀请任务执行结束");
            return;
        }
        /*** 构造本次邀请的上下文对象    ***/
        AddChatMemberContext contextAdd = new AddChatMemberContext(entity.getDstChatId());
        long begin = System.currentTimeMillis();
        inviteUserIds.forEach(e -> {
            if (!TgService.getHaveAuthorization()) {
                return;
            }
            TgService.addMemberToGroup(entity.getDstChatId(), e, contextAdd);
            try {
                int times = 1000 + new Random().nextInt(2000);
                Thread.sleep(2000 + times);
            } catch (Exception error) {
                log.error("邀请用户入群功能，降频休息时报错", error.getMessage());
            }
        });
        long end = System.currentTimeMillis();
        /*** 邀请结果写入mongodb    ***/
        /*** 添加邀请记录到邀请任务    ***/
        InviteOperationRecord record = new InviteOperationRecord();
        record.setInviteError(contextAdd.getErrorMsg().size());
        record.setInviteSucceed(contextAdd.getSucceed().size());
        record.setBeginTimeStamp(begin);
        record.setEndTimeStamp(end);
        record.setInviteTotal(inviteUserIds.size());
        Update update = new Update();
        update.addToSet("inviteOperationRecord", record);
        update.inc("invitedUserNumber", inviteUserIds.size());
        update.inc("leftUserNumber", -inviteUserIds.size());
        update.inc("step", 1);
        Query queryUpdate = Query.query(Criteria.where("_id").is(entity.getId()));
        mongoTemplate.updateFirst(queryUpdate, update, InviteTaskEntity.class);

        MongodbOperationContext context = new MongodbOperationContext();
        context.setCollectionName(AdminCommonMethod.constructChatUserInfoCollectionName(entity.getSrcChatId()));
        context.setOperationList(new ArrayList<>());

        String errorMsgSegment = TaskInfoInterface.userInvitedErrorMsg + "_" + entity.dstChatId;
        String userInvitedSegment = TaskInfoInterface.userInvitedSucceed + "_" + entity.dstChatId;

        /*** 处理错误;    ***/
        contextAdd.getErrorMsg().forEach((k, v) -> {
            Query queryU = Query.query(Criteria.where("_id").is(k));
            Update updateU = new Update();
            updateU.set(errorMsgSegment, v);
            context.getOperationList().add(Pair.of(queryU, updateU));
        });

        /*** 处理邀请发送成功的记录    ***/
        contextAdd.getSucceed().forEach((k, v) -> {
            Query queryU = Query.query(Criteria.where("_id").is(k));
            Update updateU = new Update();
            updateU.set(userInvitedSegment, "succeed");
            context.getOperationList().add(Pair.of(queryU, updateU));
        });
        /*** 邀请结果写入    ***/
        AdminCommonMethod.updateOrInsertBulkOperation(mongoTemplate, context);
        log.info("每2分钟一次的邀请任务执行结束");
    }

    /*** 根据邀请任务查询需要邀请的用户id    ***/
    private Set<Long> getInvitedUserIdByTask(InviteTaskEntity entity) {
        Query query = Query.query(Criteria.where("_id").exists(true).ne(0));
        /*** 0保存的是时间戳列表    ***/
        String errorMsgSegment = TaskInfoInterface.userInvitedErrorMsg + "_" + entity.dstChatId;
        /*** 邀请到某个群没有报错    ***/
        query.addCriteria(Criteria.where(errorMsgSegment).exists(false));
        /*** 还没有邀请到某个群中    ***/
        String userInvitedSegment = TaskInfoInterface.userInvitedSucceed + "_" + entity.dstChatId;
        query.addCriteria(Criteria.where(userInvitedSegment).exists(false));
        query.with(Sort.by(Sort.Order.desc("_id")));
        long count = mongoTemplate.count(query, Map.class, AdminCommonMethod.constructChatUserInfoCollectionName(entity.getSrcChatId()));
        log.info("collection:{};剩余未处理用户:{}", AdminCommonMethod.constructChatUserInfoCollectionName(entity.getSrcChatId()), count);
        Pageable pageable = PageRequest.of(0, InviteTaskEntity.userNumberPerInvite);
        List<Map> userIds = mongoTemplate.find(query.with(pageable), Map.class, AdminCommonMethod.constructChatUserInfoCollectionName(entity.getSrcChatId()));
        Set<Long> needInvitedUserIds = new HashSet<>();
        userIds.forEach(e -> {
            if (ObjectUtils.isEmpty(e.get("_id"))) {
                return;
            }
            String id = e.get("_id").toString();
            needInvitedUserIds.add(Long.parseLong(id));

        });
        return needInvitedUserIds;
    }
}
