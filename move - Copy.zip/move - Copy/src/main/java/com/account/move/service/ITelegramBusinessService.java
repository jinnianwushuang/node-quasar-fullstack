package com.account.move.service;

import com.account.move.entity.AddContactVo;
import com.account.move.vo.R;
import com.account.move.vo.base.BaseWithId;
import com.account.move.vo.telegrambusiness.EditGroupVo;
import com.account.move.vo.telegrambusiness.QueryGroupVo;
import com.account.move.vo.telegrambusiness.TgLoginVo;

import java.util.List;

/**
 * @author writer
 * @title: ITelegramBusinessService
 * @projectName collectUser
 * @description: 关于电报通讯软件的具体业务接口实现
 * 输入号码准备登录; 输入验证码; 迁移群组; 新建群组; 退出登录；
 * @date 2021/12/818:17
 */
public interface ITelegramBusinessService {

    /*****
     * @description: 准备登录某个电话号码的tg账号(必须保证当前电话号码的tg账号是非登录状态), 该消息发送后需要等待几秒钟后，
     *
     * @param vo  需要登录的电话号码id
     * @return com.account.core.vo.R
     * @throws
     * @author writer
     * @date 2021/12/8 19:45
     ****/
    R readyLoginByTelephoneNumber(TgLoginVo vo);

    /*****
     * @description: 指定号码发送登录请求后，tg会受到验证码，该方法发送验证码服务器
     * @param verifyCode        该号码的验证码
     * @return com.account.core.vo.R
     * @throws
     * @author writer
     * @date 2021/12/8 19:45
     ****/
    R sendVerifyCode(String verifyCode);

    R queryGroupMember(long chatId);

    /*****
     * @description: 将指定群的用户采集到 目标群组
     * @param srcChatId  需要被采集用户的群组id列表
     * @param dstChatId  需要将用户采集到指定群组的id列表
     * @return com.account.core.vo.R
     * @throws
     * @author writer
     * @date 2021/12/8 20:15
     ****/
    R migrateUserToGroup(Long srcChatId, Long dstChatId);

    /*****
     * @description: 编辑超级群的信息
     * @param vo   被编辑的群信息vo
     * @return com.account.core.vo.R
     * @throws
     * @author writer
     * @date 2021/12/8 20:15
     ****/
    R editChat(EditGroupVo vo);

    /******
     * @description: 新建群组
     * @param title            群组标题
     * @param description      群组的描述
     * @param forImport        未知
     * @return com.account.core.vo.R
     * @throws
     * @author writer
     * @date 2021/12/8 20:49
     ****/
    R createNewGroup(String title, String description, boolean isChannel, boolean forImport);

    /*******
     * @description: 退出登录
     * @return com.account.core.vo.R
     * @throws
     * @author writer
     * @date 2021/12/8 20:51
     ****/
    R logout();

    /*******
     * @description: 查询系统概览信息
     * @return com.account.core.vo.R
     * @throws
     * @author writer
     * @date 2021/12/8 20:51
     ****/
    R overView();

    /*******
     * @description: 退出登录
     * @return com.account.core.vo.R
     * @throws
     * @author writer
     * @date 2021/12/8 20:51
     ****/
    R clean();

    R queryGroup(QueryGroupVo page);

    R groupDetail(BaseWithId vo);

    R addMemberToGroup(long chatId, long userId);

    R addContact(AddContactVo vo);

    R getChatMember(long userId, long chatId);

    R inviteMultiUser(long chatId, List<Long> userIds);
}
