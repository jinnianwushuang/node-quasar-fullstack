package com.account.move.vo.login;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import org.hibernate.validator.constraints.Length;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

/**
 * @author ：Guo Tao
 * @date ：Created in 2021/2/22 16:43
 * @description：使用手机号码的基础vo
 * @modified By：
 * @version: 0.0.1
 */
@Data
public class TelephoneBaseVo {

    @ApiModelProperty(value = "电话号码",notes = "使用正确电话号码")
    @Length(min = 11, max = 11, message = "手机号码长度有误")
    @NotNull(message = "手机号码不能为空")
    @Pattern(regexp = "^1[3-9][0-9]{9}$", message = "手机号码错误")
    protected String telephoneNumber;

}
