package com.account.move.entity;

import lombok.Data;

@Data
public class AddContactVo {

    private String regionCode;

    private String telephoneNumber;

    private Long  userId;

}
