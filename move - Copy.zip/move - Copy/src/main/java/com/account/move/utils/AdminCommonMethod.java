package com.account.move.utils;

import com.account.move.config.CommonConstants;
import com.account.move.config.SystemUserSomeSegment;
import com.account.move.entity.MongodbOperationContext;
import com.mongodb.bulk.BulkWriteResult;
import org.springframework.data.mongodb.core.BulkOperations;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.util.CollectionUtils;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import javax.servlet.http.HttpServletRequest;

import org.apache.shiro.crypto.hash.SimpleHash;



/**
 * @author ：Guo Tao
 * @date ：Created in 2021/4/15 10:07
 * @description：管理后台通用方法类
 * @modified By：
 * @version:
 */
public class AdminCommonMethod {

    public static String getUserToken(String tokenName) {
        /*** 接收到请求，记录请求内容 ***/
        ServletRequestAttributes attributes = (ServletRequestAttributes) RequestContextHolder.getRequestAttributes();
        HttpServletRequest request = attributes.getRequest();
        /*** 在http请求中获取当前医生的 token token 医生在当前系统的 登录token ***/
        return request.getHeader(tokenName);
    }

    public static String getUserToken() {
        return getUserToken(SystemUserSomeSegment.token);
    }


    /*** 构造存放群组用户信息的collection name    ***/
    public  static  String constructChatUserInfoCollectionName(Long superGroupId) {
        return CommonConstants.chatUserInfo + "_" + superGroupId;
    }

    /**
     * 根据前端提供的用户密码和盐值 生成需要存在数据库中的密码
     *
     * @param password:前端提供的用户密码; salt:密码的盐值
     * @return java.lang.String
     * @Description
     * @Date
     * @author writer
     **/
    public static String getUserPasswordStoreInDatabase(String password, String salt) {
        String passwordInDatabase = new SimpleHash("SHA-1", password, salt, CommonConstants.normalUserPasswordHashTimes).toHex();
        return passwordInDatabase;
    }

    public static BulkWriteResult updateOrInsertBulkOperation(MongoTemplate mongoTemplate, MongodbOperationContext context) {
        if (CollectionUtils.isEmpty(context.getOperationList())) {
            return null;
        }
        BulkOperations operations = mongoTemplate.bulkOps(BulkOperations.BulkMode.UNORDERED, context.getCollectionName());
        operations.upsert(context.getOperationList());
        return operations.execute();
    }


    public static BulkWriteResult updateBulkOperation(MongoTemplate mongoTemplate, MongodbOperationContext context) {
        if (CollectionUtils.isEmpty(context.getOperationList())) {
            return null;
        }
        BulkOperations operations = mongoTemplate.bulkOps(BulkOperations.BulkMode.UNORDERED, context.getCollectionName());
        operations.updateMulti(context.getOperationList());
        return operations.execute();
    }


}
