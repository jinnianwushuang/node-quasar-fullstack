
package com.account.move.config;

/**
 * @author lengleng
 * @date 2019/2/1
 */
public interface CommonConstants {

	/*** 用户手动创建tg群组时所使用序列号，防止弄错群组名称    ***/
	String  createSerialIdKey = "createSerialId";

	/*** 存放 群组所属用户id 的collection 名称前缀  ***/
	String chatUserInfo = "chatUserInfo";

	/*** 普通用户密码hash值和盐值进行sha1处理的次数 ***/
	Integer normalUserPasswordHashTimes = 5;

	/*** 手机号码或者账号的前多少位作为 一级的key. 剩余的字符数作为hash的子key ***/
	Integer lengthCharacterKey = 5;

	/*** 指的是message 消息延迟多少毫秒消费   ***/
	Integer messageMilliSecondDelay = 2000;

	/*** 保存系统少量信息的 mongodb collection 名称   ***/
	Long systemReserveMaxId  = 1000001L;

	/*** 连接地址的分隔符  ***/
	String urlSeparator = "/";

	/*** 官网服务器类型的 key ***/
	String homeUrlKey = "home";

	/*** 分享服务器类型的 key ***/
	String shareKey = "share";
	/**
	 * 删除
	 */
	String STATUS_DEL = "1";
	/**
	 * 正常
	 */
	String STATUS_NORMAL = "0";

	/**
	 * 锁定
	 */
	String STATUS_LOCK = "9";

	/**
	 * 菜单树根节点
	 */
	Integer MENU_TREE_ROOT_ID = -1;

	/**
	 * 菜单
	 */
	String MENU = "0";

	/**
	 * 编码
	 */
	String UTF8 = "UTF-8";

	/**
	 * JSON 资源
	 */
	String CONTENT_TYPE = "application/json; charset=utf-8";

	/**
	 * 前端工程名
	 */
	String FRONT_END_PROJECT = "pig-ui";

	/**
	 * 后端工程名
	 */
	String BACK_END_PROJECT = "pig";

	/**
	 * 成功标记
	 */
	Integer SUCCESS = 0;
	/**
	 * 失败标记
	 */
	Integer FAIL = 1;

	/**
	 * 验证码前缀
	 */
	String DEFAULT_CODE_KEY = "DEFAULT_CODE_KEY_";

	/**
	 * 当前页
	 */
	String CURRENT = "current";

	/**
	 * size
	 */
	String SIZE = "size";
}
