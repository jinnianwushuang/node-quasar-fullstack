package com.account.move.vo.telegrambusiness;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import org.hibernate.validator.constraints.Length;

import javax.validation.constraints.NotNull;

/**
 * @author writer
 * @title: AddGroupVo
 * @projectName collectUser
 * @description:
 * @date 2021/12/821:28
 */
@Data
public class AddGroupVo {

    @ApiModelProperty("群组名称")
    @NotNull(message = "群组名称不能为空")
    @Length(message = "群组名称长度的取值范围只能是[5,20]")
    private String title;

    @ApiModelProperty("群组介绍")
    @NotNull(message = "群组介绍不能为空")
    @Length(message = "群组介绍长度的取值范围只能是[10,1000]")
    private String description;

    @ApiModelProperty("是否未频道(true:是;false:不是频道)")
    private Boolean isChannel = false;

    @ApiModelProperty("暂时不知道")
    private boolean forImport = false;
}
