package com.account.move.service.impl;

import com.account.move.config.CommonConstants;
import com.account.move.config.ErrorCode;
import com.account.move.config.TgState;
import com.account.move.entity.*;
import com.account.move.service.IInviteTaskService;
import com.account.move.service.ISystemLogService;
import com.account.move.service.ITelegramBusinessService;
import com.account.move.tg.TgService;
import com.account.move.utils.AdminCommonMethod;
import com.account.move.utils.JsonUtils;
import com.account.move.utils.TimeUtils;
import com.account.move.vo.R;
import com.account.move.vo.base.BasePage;
import com.account.move.vo.base.BaseWithId;
import com.account.move.vo.log.SystemLogRequestVo;
import com.account.move.vo.task.InviteTaskRequestVo;
import com.account.move.vo.telegrambusiness.EditGroupVo;
import com.account.move.vo.telegrambusiness.QueryGroupVo;
import com.account.move.vo.telegrambusiness.TgLoginVo;
import lombok.extern.slf4j.Slf4j;
import org.drinkless.tdlib.TdApi;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.data.util.Pair;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;
import org.springframework.util.ObjectUtils;
import org.springframework.util.StringUtils;

import javax.annotation.PostConstruct;
import java.util.*;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicLong;

/**
 * @author writer
 * @title: TelegramBusinessServiceImpl
 * @projectName collectUser
 * @description:
 * @date 2021/12/820:52
 */
@Slf4j
@Service
public class TelegramBusinessServiceImpl implements ITelegramBusinessService {

    private AtomicLong serialId;

    @Autowired
    ISystemLogService systemLogService;

    @Autowired
    MongoTemplate mongoTemplate;

    @Autowired
    IInviteTaskService inviteTaskService;

    private ThreadPoolExecutor executor;

    @PostConstruct
    public void initial() {
        this.serialId = new AtomicLong();
        this.executor = new ThreadPoolExecutor(1, 2, 1000l, TimeUnit.SECONDS,
                new LinkedBlockingQueue<Runnable>(10));
    }

    /*****
     * @description: 准备登录某个电话号码的tg账号(必须保证当前电话号码的tg账号是非登录状态), 该消息发送后需要等待几秒钟后，
     *
     * @param vo  需要登录的电话号码id
     * @return com.account.core.vo.R
     * @throws
     * @author writer
     * @date 2021/12/8 19:45
     ****/
    @Override
    public R readyLoginByTelephoneNumber(TgLoginVo vo) {
        if (ObjectUtils.isEmpty(TgService.getAuthorizationState())) {
            return R.failed(ErrorCode.STATUS_NOT_WAIT_TELEPHONE);
        }

        if (TdApi.AuthorizationStateWaitPhoneNumber.CONSTRUCTOR == TgService.getAuthorizationState().getConstructor()) {
            TgService.sendTelephoneNumber(vo.getRegionCode(), vo.getPhoneNumber());
        } else {
            return R.failed(ErrorCode.STATUS_NOT_WAIT_TELEPHONE);
        }
        for (int i = 0; i < 10; i++) {
            try {
                Thread.sleep(200);
            } catch (Exception e) {
                log.error("Thread.sleep(50) 操作失败", e);
            }
            /***   ***/
            /***  如果账号状态处于登录成功的状态   ***/
            if (!ObjectUtils.isEmpty(TgService.getAuthorizationState()) && TdApi.AuthorizationStateWaitCode.CONSTRUCTOR == TgService.getAuthorizationState().getConstructor()) {
                return R.ok("操作成功,请输入验证码");
            }
        }
        log.info("登陆,输入账号后的状态：{}", TgService.getAuthorizationState());
        /*** 长时间未处理返回tg服务器无响应    ***/
        return R.failed(ErrorCode.SERVER_NO_RESPONSE);
    }


    /*****
     * @description: 指定号码发送登录请求后，tg会受到验证码，该方法发送验证码服务器
     * @param verifyCode        该号码的验证码
     * @return com.account.core.vo.R
     * @throws
     * @author writer
     * @date 2021/12/8 19:45
     ****/
    @Override
    public R sendVerifyCode(String verifyCode) {
        if (ObjectUtils.isEmpty(TgService.getAuthorizationState())) {
            return R.failed(ErrorCode.STATUS_NOT_WAIT_VERIFY_CODE);
        }
        if (TdApi.AuthorizationStateWaitCode.CONSTRUCTOR == TgService.getAuthorizationState().getConstructor()) {
            TgService.sendVerifyCode(verifyCode);
        } else {
            return R.failed(ErrorCode.STATUS_NOT_WAIT_VERIFY_CODE);
        }
        for (int i = 0; i < 20; i++) {
            try {
                Thread.sleep(50);
            } catch (Exception e) {
                log.error("操作失败", e);
            }
            /***   ***/
            /***  如果账号状态处于登录成功的状态   ***/
            if (!ObjectUtils.isEmpty(TgService.getAuthorizationState()) && TdApi.AuthorizationStateReady.CONSTRUCTOR == TgService.getAuthorizationState().getConstructor()) {
                return R.ok("登陆成功");
            }
        }
        return R.failed(ErrorCode.SERVER_NO_RESPONSE);
    }

    @Override
    public R queryGroupMember(long chatId) {
        Query query = Query.query(Criteria.where("_id").is(chatId));
        Map groupData = mongoTemplate.findOne(query, Map.class, TdApi.Chat.class.getSimpleName());
        if (CollectionUtils.isEmpty(groupData)) {
            return R.failed(ErrorCode.EMPTY_DATA);
        }
        /*** 做校验:
         *    不能是channel,必须可以查看用户信息,必须是超级群，用户个数大于1;
         *
         * ***/
        if (ObjectUtils.isEmpty(groupData.get("superGroupId"))) {
            return R.failed(ErrorCode.CHAT_NO_GROUP_ID);
        }
        if (ObjectUtils.isEmpty(groupData.get("memberCount"))) {
            return R.failed(ErrorCode.CHAT_NO_MEMBER_COUNT);
        }
        Long superGroupId = Long.parseLong(groupData.get("superGroupId").toString());
        Integer memberCount = Integer.parseInt(groupData.get("memberCount").toString());
        /*** 查询用户信息:
         * 1. 构造查询上下文,讲上下文传给查询群组用户的方法;
         * 2. 使用  ChatMembersFilterAdministrators 查询过滤掉管理员
         * 2. 最多等待5秒钟，查看查询的用户个数;
         * ***/
        GetSuperGroupMemberContext queryContext = new GetSuperGroupMemberContext(superGroupId, memberCount);
        int maxPerQuery = 200;
        int times = (queryContext.getMemberCount() + maxPerQuery - 1) / maxPerQuery;
        for (int i = 0; i < times; i++) {
            try {
                log.info("查询聊天:{}的用户信息;times:{};offset:{},limit:{}", chatId, i, i * maxPerQuery, maxPerQuery);

                TgService.getSuperGroupMembers(queryContext, i * maxPerQuery, maxPerQuery);
                Thread.sleep(50);
            } catch (Exception e) {
                log.error("查询过程中休息，操作失败", e);
            }
            if (queryContext.getWhetherFinish().get()) {
                break;
            }
            if (queryContext.getErrorMsg().keySet().size() > 0) {
                return R.failed(queryContext.getErrorMsg().keySet());
            }
        }

        MongodbOperationContext mongodbContext = new MongodbOperationContext();
        /*** ;;;;    ***/
        mongodbContext.setCollectionName(AdminCommonMethod.constructChatUserInfoCollectionName(chatId));
        List<Pair<Query, Update>> operationList = new ArrayList<>();
        mongodbContext.setOperationList(operationList);
        long timeStamp = System.currentTimeMillis();
        queryContext.getGroupMember().keySet().forEach(e -> {
            Query queryOp = Query.query(Criteria.where("_id").is(e));
            Update update = new Update();
            update.set("timeStamp", timeStamp);
            operationList.add(Pair.of(queryOp, update));
        });
        /*** 用户信息写入数据库    ***/
        AdminCommonMethod.updateOrInsertBulkOperation(mongoTemplate, mongodbContext);
        /***   更新群组信息  ***/
        Query queryOp = Query.query(Criteria.where("_id").is(chatId));
        Update update = new Update();
        update.set("actualUserCount", queryContext.getUpdatedMemberCount().get());
        update.set("actualUserCountModifyTime", System.currentTimeMillis());
        operationList.add(Pair.of(queryOp, update));
        /*** 写错误日志到    ***/
        Set<String> errorMsg = queryContext.getErrorMsg().keySet();
        if (errorMsg.size() > 1) {
            log.info("_%s", JsonUtils.serializeToString(errorMsg));
            return R.failed(errorMsg);
        }
        return R.ok();
    }

    public R checkChatValidate(Map srcGroup, Map dstGroup) {

        if (!(boolean) srcGroup.get("canGetMembers")) {
            return R.failed(ErrorCode.SOURCE_GROUP_CAN_NOT_QUERY);
        }
        int memberCount = Integer.parseInt(srcGroup.get("memberCount").toString());
        if (memberCount < 2) {
            return R.failed(ErrorCode.GROUP_MEMBER_ONLY_ONE);
        }
        return null;
    }

    /*****
     * @description: 将指定群的用户采集到 目标群组
     * @param srcChatId  需要被采集用户的群组id列表
     * @param dstChatId  需要将用户采集到指定群组的id列表
     * @return com.account.core.vo.R
     * @throws
     * @author writer
     * @date 2021/12/8 20:15
     ****/
    @Override
    public R migrateUserToGroup(Long srcChatId, Long dstChatId) {
        /*** 操作步骤：
         * 1. 做数据校验：
         * 2.查询用户信息;
         * 3.做邀请;
         * ***/
        Query query = Query.query(Criteria.where("_id").in(Arrays.asList(srcChatId, dstChatId)));
        List<Map> datas = mongoTemplate.find(query, Map.class, TdApi.Chat.class.getSimpleName());
        /*** 做校验:
         * 1. srcGroupId 不能是channel,必须可以查看用户信息,必须是超级群，用户个数大于1;
         * 2. dstChatId 不能是channel;         *
         * ***/
        Map srcGroup = null;
        Map dstGroup = null;
        for (Map groupData : datas) {
            if (CollectionUtils.isEmpty(groupData)) {
                return R.failed(ErrorCode.EMPTY_DATA);
            }
            if (Long.parseLong(groupData.get("_id").toString()) == srcChatId) {
                srcGroup = groupData;
            }
            if (Long.parseLong(groupData.get("_id").toString()) == dstChatId) {
                dstGroup = groupData;
            }
        }
        R r = this.checkChatValidate(srcGroup, dstGroup);
        if (!ObjectUtils.isEmpty(r)) {
            return r;
        }
        /***     ***/
        /*** 做邀请
         * 1. 生成邀请任务；
         *  ***/
        String id = "" + srcChatId + "_" + dstChatId + "_" + TimeUtils.stampToTimeYmdh(TimeUtils.alignTo1Hour(System.currentTimeMillis()));
        if (0 != mongoTemplate.count(Query.query(Criteria.where("_id").is(id)), InviteTaskEntity.class)) {
            return R.failed(ErrorCode.DST_SRC_REPEATED_20_MINUTES);
        }
        executor.execute(() -> collectGroupUser(srcChatId));
        InviteTaskEntity entity = new InviteTaskEntity();
        entity.setId(id);
        entity.setSrcChatId(srcChatId);
        entity.setSrcChatTitle(srcGroup.get("title").toString());
        entity.setDstChatId(dstChatId);
        entity.setDstChatTitle(dstGroup.get("title").toString());
        entity.setMemberCount(Integer.parseInt(srcGroup.get("memberCount").toString()));
        Query queryCount = Query.query(Criteria.where("_id").exists(true));

        String collectionName = AdminCommonMethod.constructChatUserInfoCollectionName(srcChatId);
        long count = mongoTemplate.count(queryCount, collectionName);
        entity.setActualMemberCount((int) count);
        entity.setLeftUserNumber((int) count);
        entity.setStep(0);
        entity.setCreateTimeStamp(System.currentTimeMillis());
        mongoTemplate.save(entity);
        /*** 返回消息
         *
         *  ***/
        return R.ok();
    }

    private void collectGroupUser(Long chatId) {
        String collection = AdminCommonMethod.constructChatUserInfoCollectionName(chatId);
        Query query = Query.query(Criteria.where("_id").exists(true));
        long count = mongoTemplate.count(query, collection);
        if (count == 0) {
            this.queryGroupMember(chatId);
        }

    }

    @Override
    public R editChat(EditGroupVo vo) {
        Query query = Query.query(Criteria.where("_id").is(vo.getChatId()));
        Update update = new Update();
        if (StringUtils.isEmpty(vo.getRemark())) {
            return R.failed(ErrorCode.NEITHER_EMPTY);
        }
        if (!StringUtils.isEmpty(vo.getRemark())) {
            update.set("remark", vo.getRemark());
        }
        mongoTemplate.updateFirst(query, update, TdApi.Chat.class.getSimpleName());
        return R.ok();
    }

    /******
     * @description: 新建群组
     * @param title            群组标题
     * @param description      群组的描述
     * @param isChannel       频道
     * @param forImport        未知
     * @return com.account.core.vo.R
     * @throws
     * @author writer
     * @date 2021/12/8 20:49
     ****/
    @Override
    public R createNewGroup(String title, String description, boolean isChannel, boolean forImport) {
        long serialIDCheck = serialId.getAndIncrement();
        while (true) {
            Query query = Query.query(Criteria.where(CommonConstants.createSerialIdKey).is(serialIDCheck));
            long count = mongoTemplate.count(query, TdApi.Supergroup.class.getSimpleName());
            if (count == 0) {
                /*** 说明该序列号没有被使用    ***/
                break;
            }
            /*** 如果重复则继续    ***/
            serialIDCheck = serialId.getAndIncrement();
        }
        TgService.createGroup(serialId.getAndIncrement(), title, isChannel, description);

        /*** 最多轮训5秒钟，查询当前创建的群组是否成功，如果成功则返回ok ，否则返回失败    ***/
        for (int i = 0; i < 100; i++) {
            try {
                Thread.sleep(50);
            } catch (Exception e) {
                log.error("操作失败", e);
            }
            /***  如果检测到群组创建成功  ***/
            if (!ObjectUtils.isEmpty(TgService.createGroupResponseMap.get(serialId))) {
                return R.ok("创建成功");
            } else if (!ObjectUtils.isEmpty(TgService.createGroupErrorMap.get(serialId))) {
                TdApi.Error error = TgService.createGroupErrorMap.get(serialId);
                return R.failed(1, error.message, error);
            }
        }
        return R.failed(ErrorCode.SERVER_NO_RESPONSE);
    }

    /*******
     * @description: 新建群组
     * @return com.account.core.vo.R
     * @throws
     * @author writer
     * @date 2021/12/8 20:51
     ****/
    @Override
    public R logout() {
        TgService.logOut();
        TgService.regionNumber = "";
        TgService.telephoneNumber = "";

        for (int i = 0; i < 20; i++) {
            try {
                Thread.sleep(50);
            } catch (Exception e) {
                log.error("操作失败", e);
            }
            /***   ***/
            /***  如果账号状态处于登录成功的状态   ***/
            if (!TgService.getHaveAuthorization() || TdApi.AuthorizationStateLoggingOut.CONSTRUCTOR == TgService.getAuthorizationState().getConstructor()) {
                return R.ok("登出成功");
            }
        }
        return R.failed(ErrorCode.SERVER_NO_RESPONSE);

    }

    @Override
    public R overView() {
        /*** 返回当前系统的登陆状况;
         * 1.登陆状态;(待输入电话号码;待输入验证码(电话号码);登陆中(电话号码);)         *
         * ***/

        OverViewEntity entity = new OverViewEntity();
        AccountLoginEntity accountLoginEntity = new AccountLoginEntity();
        accountLoginEntity.setLoginStatus(TgState.getDescriptionByCode(TgService.getAuthorizationState().getConstructor()));
        accountLoginEntity.setAppCode("");
        if (!StringUtils.isEmpty(TgService.regionNumber)) {
            accountLoginEntity.setTelephoneNumberWithCode("+" + TgService.regionNumber + " " + TgService.telephoneNumber);
        }
        entity.setEntity(accountLoginEntity);
        /***
         * 定时任务执行情况(几个定时任务,执行情况)  ；没有完成的任务,根据创建时间顺序排列3个
         * ***/
        BasePage pageTask = new BasePage(3, 1);
        InviteTaskRequestVo voTask = new InviteTaskRequestVo();
        voTask.setPage(pageTask);
        entity.setInviteTaskEntities(inviteTaskService.queryInviteTask(voTask).getRecords());
        /***
         * 最近的10个操作  当前服务器涉及的最新的10个日志;
         * ***/
        BasePage page = new BasePage(10, 1);
        SystemLogRequestVo vo = new SystemLogRequestVo();
        vo.setPage(page);
        entity.setLastLogs(systemLogService.querySystemOperationLog(vo).getRecords());
        return R.ok(entity);
    }

    @Override
    public R clean() {
        TgService.Close();
        return R.ok();
    }

    @Override
    public R queryGroup(QueryGroupVo vo) {
        BasePage page = vo.getPage();
        Query query = new Query();
        /*** id必须存在    ***/
        query.addCriteria(Criteria.where("_id").exists(true));
        query.addCriteria(Criteria.where("memberCount").exists(true).gt(0));
        query.addCriteria(Criteria.where("superGroupId").exists(true).gt(0));
        if (!StringUtils.isEmpty(vo.getTitle())) {
            query.addCriteria(Criteria.where("title").regex(".*?\\" + vo.getTitle() + ".*"));

        }
        long count = mongoTemplate.count(query, TdApi.Chat.class.getSimpleName());
        query.fields().include("_id");
        query.fields().include("title");
        query.fields().include("description");
        query.fields().include("photo");
        query.fields().include("canGetMembers");
        query.fields().include("memberCount");
        query.fields().include("actualUserCount");
        query.fields().include("actualUserCountModifyTime");
        Pageable pageable = PageRequest.of((int) (page.getCurrent() - 1), (int) page.getSize());
        query.with(Sort.by(Sort.Order.desc("_id")));
        List<Map> systemOperateLogEntities = mongoTemplate.find(query.with(pageable), Map.class, TdApi.Chat.class.getSimpleName());
        page.setRecords(systemOperateLogEntities);
        page.setTotal(count);
        return R.ok(page);
    }

    @Override
    public R groupDetail(BaseWithId vo) {
        return null;
    }

    @Override
    public R addMemberToGroup(long chatId, long userId) {

        AddChatMemberContext contextAdd = new AddChatMemberContext(chatId);
        TgService.addMemberToGroup(chatId, userId, contextAdd);
        try {
            Thread.sleep(1000);
        } catch (Exception e) {

        }
        return R.ok(contextAdd);
    }

    @Override
    public R addContact(AddContactVo vo) {
        AddContactsContext contextAdd = new AddContactsContext();
        if (ObjectUtils.isEmpty(vo.getUserId())) {
            TgService.addContact(vo.getRegionCode() + " " + vo.getTelephoneNumber(), contextAdd);
        } else {
            TgService.addContact(vo.getUserId(), contextAdd);
        }
        for (int i = 0; i < 5; i++) {
            if (!CollectionUtils.isEmpty(contextAdd.getOperateResult())) {
                return R.ok(contextAdd);
            }
            try {
                Thread.sleep(1000);
            } catch (Exception e) {

            }
        }
        return R.ok(contextAdd);
    }

    @Override
    public R getChatMember(long userId, long chatId) {
        AddContactsContext contextAdd = new AddContactsContext();
        TgService.getChatMember(userId, chatId, contextAdd);
        for (int i = 0; i < 5; i++) {
            if (!CollectionUtils.isEmpty(contextAdd.getOperateResult())) {
                return R.ok(contextAdd);
            }
            try {
                Thread.sleep(1000);
            } catch (Exception e) {

            }
        }
        return R.ok(contextAdd);
    }


    @Override
    public R inviteMultiUser(long chatId, List<Long> userIds) {
        AddContactsContext contextAdd = new AddContactsContext();
        TgService.addChatMembers(chatId, userIds, contextAdd);
        try {
            Thread.sleep(1000);
        } catch (Exception e) {

        }
        return R.ok(contextAdd);
    }
}
