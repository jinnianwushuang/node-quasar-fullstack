package com.account.move.vo.login;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * @ClassNmae LoginResponseVo
 * @Description
 * @Author liubaohong
 * @Date 2021/3/17  10:52
 **/
@Data
@ApiModel(value="登录成功返回信息", description="登录成功返回信息vo")
public class LoginResponseVo {

    @ApiModelProperty(value = "token",notes = "token")
    private String token;

    @ApiModelProperty(value = "验证码",notes = "验证码")
    private String verifyCode;

    @ApiModelProperty(value = "userId",notes = "userId")
    private Long userId;

    public LoginResponseVo() {
        this.token = "";
        this.verifyCode = "";
        this.userId = 0L;
    }


}
