package com.account.move.controller;

import com.account.move.annotations.SystemLogType;
import com.account.move.service.IInviteTaskService;
import com.account.move.service.ISystemLogService;
import com.account.move.vo.R;
import com.account.move.vo.base.BaseWithIdString;
import com.account.move.vo.log.SystemLogRequestVo;
import com.account.move.vo.task.InviteTaskRequestVo;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * @author writer
 * @title: InviteTaskController
 * @projectName checkAccount
 * @description:
 * @date 2021/12/1412:34
 */
@Slf4j
@RestController
@RequestMapping("api/task")
@Api(value = "邀请用户定时任务控制器", tags = {"邀请用户定时任务控制器"})
public class InviteTaskController {

    @Autowired
    IInviteTaskService inviteTaskService;

    @PostMapping("/query")
    @ApiOperation(value = "获取验证码", notes = "获取验证码")
    public R query(@RequestBody @Validated InviteTaskRequestVo vo) {
        return R.ok(inviteTaskService.queryInviteTask(vo));
    }

    @PostMapping("/deleteById")
    @ApiOperation(value = "根据id删除任务", notes = "根据id删除任务")
    @SystemLogType(moduleCode = "TgService", moduleName = "TG业务", operationCode = "deleteById", operationName = "根据id删除任务")
    public R deleteById(@RequestBody @Validated BaseWithIdString vo) {
        return R.ok(inviteTaskService.deleteById(vo.getId()));
    }

}
