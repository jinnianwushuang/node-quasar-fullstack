package com.account.move.vo.login;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import org.hibernate.validator.constraints.Length;

import javax.validation.constraints.NotNull;

/**
 * @author ：Guo Tao
 * @date ：Created in 2021/2/22 16:45
 * @description：使用电话号码和验证码登录的vo
 * @modified By：
 * @version: 0.0.1
 */
@Data
@ApiModel(value = "使用电话号码和验证码登录的vo", description = "使用电话号码和验证码登录的vo")
public class TelephoneVerifyCodeVo extends TelephoneBaseVo {

    @ApiModelProperty(value = "验证码")
    @Length(min = 4, message = "请输入6位验证码")
    @NotNull(message = "验证码不能为空")
    private String verifyCode;
}
