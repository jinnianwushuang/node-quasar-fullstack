package com.account.move.entity;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@Data
public class AccountLoginEntity {

    @ApiModelProperty("app类型编码")
    private String  appCode;

    @ApiModelProperty("登陆状态")
    private String  loginStatus;

    @ApiModelProperty("带国家编号的电话号码")
    private String  telephoneNumberWithCode;

}
