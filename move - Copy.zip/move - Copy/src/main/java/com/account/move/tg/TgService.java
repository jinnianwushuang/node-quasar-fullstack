//
// Copyright Aliaksei Levin (levlam@telegram.org), Arseny Smirnov (arseny30@gmail.com) 2014-2021
//
// Distributed under the Boost Software License, Version 1.0. (See accompanying
// file LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)
//

package com.account.move.tg;

import com.account.move.entity.AddChatMemberContext;
import com.account.move.entity.AddContactsContext;
import com.account.move.entity.GetChatsContext;
import com.account.move.entity.GetSuperGroupMemberContext;
import lombok.extern.slf4j.Slf4j;
import org.drinkless.tdlib.Client;
import org.drinkless.tdlib.TdApi;

import java.io.BufferedReader;
import java.io.IOError;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

/**
 * Example class for TDLib usage from Java.
 */
@Slf4j
public final class TgService {
    private static Client client = null;

    private static TdApi.AuthorizationState authorizationState = null;
    private static volatile boolean haveAuthorization = false;
    private static volatile boolean needQuit = false;

    /*** 电话号码    ***/
    public static String telephoneNumber;

    /*** 区号    ***/
    public static String regionNumber;

    private static final Client.ResultHandler defaultHandler = new DefaultHandler();

    /*** 创建群组的错误信息; key : serialId, value:错误信息    ***/
    public static final ConcurrentMap<Long, TdApi.Error> createGroupErrorMap = new ConcurrentHashMap<>();

    /*** 创建群组的结果信息; key : serialId, value:操作信息    ***/
    public static final ConcurrentMap<Long, TdApi.Ok> createGroupResponseMap = new ConcurrentHashMap<>();

    private static final Lock authorizationLock = new ReentrantLock();

    private static final Condition gotAuthorization = authorizationLock.newCondition();

    public static final ConcurrentMap<Long, TdApi.User> users = new ConcurrentHashMap<Long, TdApi.User>();
    public static final ConcurrentMap<Long, TdApi.BasicGroup> basicGroups = new ConcurrentHashMap<Long, TdApi.BasicGroup>();
    public static final ConcurrentMap<Long, TdApi.Supergroup> supergroups = new ConcurrentHashMap<Long, TdApi.Supergroup>();
    private static final ConcurrentMap<Integer, TdApi.SecretChat> secretChats = new ConcurrentHashMap<Integer, TdApi.SecretChat>();

    public static final ConcurrentMap<Long, TdApi.Chat> chats = new ConcurrentHashMap<Long, TdApi.Chat>();
    private static final NavigableSet<OrderedChat> mainChatList = new TreeSet<OrderedChat>();
    private static boolean haveFullMainChatList = false;

    public static final ConcurrentMap<Long, TdApi.UserFullInfo> usersFullInfo = new ConcurrentHashMap<Long, TdApi.UserFullInfo>();
    public static final ConcurrentMap<Long, TdApi.BasicGroupFullInfo> basicGroupsFullInfo = new ConcurrentHashMap<Long, TdApi.BasicGroupFullInfo>();
    public static final ConcurrentMap<Long, TdApi.SupergroupFullInfo> supergroupsFullInfo = new ConcurrentHashMap<Long, TdApi.SupergroupFullInfo>();

    /*** 需要关注标题的基础群组id map； key:需要关注的群组id;value:空字符串。 项目启动时设置    ***/
    // public static final ConcurrentMap<Long, String> basicGroupsNeedTitle = new ConcurrentHashMap<>();

    /*** 需要关注标题的超级群组id map； key:需要关注的群组id;value:空字符串。项目启动时设置    ***/
    // public static final ConcurrentMap<Long, String> supergroupsNeedTitle = new ConcurrentHashMap<>();

    /*** 保存普通群组和聊天对象的对应关系. key: 普通群组id; value:群组聊天对象信息    ***/
    // public static final ConcurrentMap<Long, ChatGroupRelationEntity> basicGroupsChatRelationMap = new ConcurrentHashMap<>();

    /*** 保存超级群组和聊天对象的对应关系. key: 超级群组id; value:群组聊天对象信息 . 存储超级群时发现，有些群无法查找用户，暂时注释掉   ***/
    // public static final ConcurrentMap<Long, ChatGroupRelationEntity> supergroupsChatRelationMap = new ConcurrentHashMap<>();

    /*** 保存修改了标题的聊天对象 信息; id:chatId; value:title   ***/
    public static final ConcurrentMap<Long, String> updateGroupTitleMap = new ConcurrentHashMap<>();

    private static final String newLine = System.getProperty("line.separator");
    private static final String commandsLine = "Enter command (gcs - GetChats, gc <chatId> - GetChat, me - GetMe, sm <chatId> <message> - SendMessage, lo - LogOut, ng - newGroup): ";
    private static volatile String currentPrompt = null;

    static {
        try {
            System.loadLibrary("tdjni");
        } catch (UnsatisfiedLinkError e) {
            e.printStackTrace();
        }
    }


    private static void setChatPositions(TdApi.Chat chat, TdApi.ChatPosition[] positions) {
        synchronized (mainChatList) {
            synchronized (chat) {
                for (TdApi.ChatPosition position : chat.positions) {
                    if (position.list.getConstructor() == TdApi.ChatListMain.CONSTRUCTOR) {
                        boolean isRemoved = mainChatList.remove(new OrderedChat(chat.id, position));
                        assert isRemoved;
                    }
                }

                chat.positions = positions;

                for (TdApi.ChatPosition position : chat.positions) {
                    if (position.list.getConstructor() == TdApi.ChatListMain.CONSTRUCTOR) {
                        boolean isAdded = mainChatList.add(new OrderedChat(chat.id, position));
                        assert isAdded;
                    }
                }
            }
        }
    }


    private static void onAuthorizationStateUpdated(TdApi.AuthorizationState authorizationState) {
        if (authorizationState != null) {
            System.out.println(authorizationState);
            log.info("onAuthorizationStateUpdated authorizationState.{}", authorizationState);
            TgService.authorizationState = authorizationState;
        }
        switch (TgService.authorizationState.getConstructor()) {
            case TdApi.AuthorizationStateWaitTdlibParameters.CONSTRUCTOR:
                TdApi.TdlibParameters parameters = new TdApi.TdlibParameters();
                parameters.databaseDirectory = "tdlib";
                parameters.useMessageDatabase = true;
                parameters.useSecretChats = true;
                parameters.apiId = 94575;
                parameters.apiHash = "a3406de8d171bb422bb6ddf3bbd800e2";
                parameters.systemLanguageCode = "en";
                parameters.deviceModel = "Desktop";
                parameters.applicationVersion = "2.0";
                parameters.enableStorageOptimizer = true;

                client.send(new TdApi.SetTdlibParameters(parameters), new AuthorizationRequestHandler());
                break;
            case TdApi.AuthorizationStateWaitEncryptionKey.CONSTRUCTOR:
                client.send(new TdApi.CheckDatabaseEncryptionKey(), new AuthorizationRequestHandler());
                break;
            case TdApi.AuthorizationStateWaitPhoneNumber.CONSTRUCTOR: {
                /*** TODO 需要返回的账号状态    ***/
//                Throwable ex = new Throwable();
//                StackTraceElement[] stackElements = ex.getStackTrace();
//                StringBuffer sb = new StringBuffer();
//
//                if (stackElements != null) {
//                    for (int i = 0; i < stackElements.length; i++) {
//                        sb.append(newLine);
//                        sb.append(stackElements[i].getClassName() + "    ");
//                        sb.append(stackElements[i].getFileName() + "    ");
//                        sb.append(stackElements[i].getLineNumber() + "    ");
//                        sb.append(stackElements[i].getMethodName());
//                        sb.append("-----------------------------------");
//                    }
//                }
                log.info("AuthorizationStateWaitPhoneNumber ");
//                String phoneNumber = promptString("Please enter phone number: ");
//                client.send(new TdApi.SetAuthenticationPhoneNumber(phoneNumber, null), new AuthorizationRequestHandler());
                break;
            }
            case TdApi.AuthorizationStateWaitOtherDeviceConfirmation.CONSTRUCTOR: {
                String link = ((TdApi.AuthorizationStateWaitOtherDeviceConfirmation) TgService.authorizationState).link;
                log.info("Please confirm this login link on another device: " + link);
                break;
            }
            case TdApi.AuthorizationStateWaitCode.CONSTRUCTOR: {
//                /*** TODO 需要返回的账号状态    ***/
//
//                Throwable ex = new Throwable();
//                StackTraceElement[] stackElements = ex.getStackTrace();
//                StringBuffer sb = new StringBuffer();
//
//                if (stackElements != null) {
//                    for (int i = 0; i < stackElements.length; i++) {
//                        sb.append(newLine);
//                        sb.append(stackElements[i].getClassName() + "    ");
//                        sb.append(stackElements[i].getFileName() + "    ");
//                        sb.append(stackElements[i].getLineNumber() + "    ");
//                        sb.append(stackElements[i].getMethodName());
//                        sb.append("-----------------------------------");
//                    }
//                }
//                log.info("AuthorizationStateWaitCode stack:{}", sb.toString());
//
//                String code = promptString("Please enter authentication code: ");
//                client.send(new TdApi.CheckAuthenticationCode(code), new AuthorizationRequestHandler());
                break;
            }
            case TdApi.AuthorizationStateWaitRegistration.CONSTRUCTOR: {
//                String firstName = promptString("Please enter your first name: ");
//                String lastName = promptString("Please enter your last name: ");
//                client.send(new TdApi.RegisterUser(firstName, lastName), new AuthorizationRequestHandler());
                break;
            }
            case TdApi.AuthorizationStateWaitPassword.CONSTRUCTOR: {
//                String password = promptString("Please enter password: ");
//                client.send(new TdApi.CheckAuthenticationPassword(password), new AuthorizationRequestHandler());
                break;
            }
            case TdApi.AuthorizationStateReady.CONSTRUCTOR:
                haveAuthorization = true;
                authorizationLock.lock();
                try {
                    gotAuthorization.signal();
                } finally {
                    authorizationLock.unlock();
                }
                break;
            case TdApi.AuthorizationStateLoggingOut.CONSTRUCTOR:
                haveAuthorization = false;
                log.info("Logging out");
                break;
            case TdApi.AuthorizationStateClosing.CONSTRUCTOR:
                haveAuthorization = false;
                log.info("Closing");
                break;
            case TdApi.AuthorizationStateClosed.CONSTRUCTOR:
                log.info("Closed");
                if (!needQuit) {
                    client = Client.create(new UpdateHandler(), null, null); // recreate client after previous has closed
                }
                break;
            default:
                log.error("Unsupported authorization state:" + newLine + TgService.authorizationState);
        }
    }

    public static boolean getHaveAuthorization() {
        return haveAuthorization;
    }

    /******
     * @description: 新建群组
     * @param title            群组标题
     * @param isChannel       频道
     * @param description      群组的描述
     * @return com.account.core.vo.R
     * @throws
     * @author writer
     * @date 2021/12/8 20:49
     ****/
    public static void createGroup(Long serialId, String title, boolean isChannel, String description) {
        TdApi.CreateNewSupergroupChat createNewSuperGroupChat = new TdApi.CreateNewSupergroupChat(title, isChannel, description, null, false);
        client.send(createNewSuperGroupChat, new CreateGroupHandler(serialId));
    }

    public static TdApi.AuthorizationState getAuthorizationState() {
        return TgService.authorizationState;
    }

    /*** 添加用户到群    ***/
    public static void addMemberToGroup(long chatId, long userId, AddChatMemberContext contextAdd) {
        client.send(new TdApi.AddChatMember(chatId, userId, 5), new AddMemberChatHandler(contextAdd, userId));
    }


    public static void addContact(long userId, AddContactsContext context) {
        TdApi.Contact contact = new TdApi.Contact();
        contact.userId = userId;
        contact.firstName = "firstName：" + userId;
        contact.lastName = "lastName：" + userId;
        contact.vcard = "vcard：" + userId;
        client.send(new TdApi.AddContact(contact, false), new AddContactHandler(context, userId));
    }

    public static void addContact(String  telephoneNumber, AddContactsContext context) {
        TdApi.Contact contact = new TdApi.Contact();
        contact.firstName = "firstName：" + telephoneNumber;
        contact.lastName = "lastName：" + telephoneNumber;
        contact.vcard = "vcard：" + telephoneNumber;
        contact.phoneNumber = telephoneNumber;
        client.send(new TdApi.AddContact(contact, false), new AddContactHandler(context, telephoneNumber));
    }


    public static void getChatMember(long userId, long chatId, AddContactsContext context) {
        TdApi.MessageSenderUser memberId = new TdApi.MessageSenderUser();
        memberId.userId = userId;
        client.send(new TdApi.GetChatMember(chatId, memberId), new GetChatMemberHandler(context, userId, chatId));
    }


    public static void addChatMembers(long chatId, List<Long> userIds, AddContactsContext context) {
        long[] arrays = new long[userIds.size()];
        for(int i = 0 ; i < userIds.size();i++) {
            arrays[i] = userIds.get(i);
        }
        client.send(new TdApi.AddChatMembers(chatId, arrays ), new AddMembersChatHandler(context, userIds , chatId));
    }


    public static void logOut() {
        haveAuthorization = false;
        client.send(new TdApi.LogOut(), defaultHandler);
    }

    public static void Close() {
        client.send(new TdApi.Close(), defaultHandler);
    }

    /******
     * @description: 查找指定超级群的用户
     * @param context            查询用户操作的上下文
     * @return void
     * @throws
     * @author writer
     * @date 2021/12/8 20:49
     ****/
    private static void getSuperGroupMembers(GetSuperGroupMemberContext context, int memberCount) {
        long chatId = context.getSrcGroupId();
        TdApi.SearchChatMembers getChatMember = new TdApi.SearchChatMembers(chatId, "", memberCount, new TdApi.ChatMembersFilterMembers());
        client.send(getChatMember, new GetMemberHandler(context));
    }

    public static void getSuperGroupMembers(GetSuperGroupMemberContext context, int offset, int limit) {
        long chatId = context.getSrcGroupId();
        TdApi.GetSupergroupMembers getChatMember = new TdApi.GetSupergroupMembers(chatId, null, offset, limit);
        client.send(getChatMember, new GetMemberHandler(context));

    }

    public static void sendVerifyCode(String verifyCode) {
        client.send(new TdApi.CheckAuthenticationCode(verifyCode), new AuthorizationRequestHandler());
    }

    public static void sendTelephoneNumber(String regionNumber, String telephoneNumber) {
        TgService.regionNumber = regionNumber;
        TgService.telephoneNumber = telephoneNumber;
        client.send(new TdApi.SetAuthenticationPhoneNumber(regionNumber + " " + telephoneNumber, null), new AuthorizationRequestHandler());

    }

    private static int toInt(String arg) {
        int result = 0;
        try {
            result = Integer.parseInt(arg);
        } catch (NumberFormatException ignored) {
        }
        return result;
    }

    private static long getChatId(String arg) {
        long chatId = 0;
        try {
            chatId = Long.parseLong(arg);
        } catch (NumberFormatException ignored) {
        }
        return chatId;
    }

    private static void getCommand() {
        System.out.print(commandsLine);
        currentPrompt = commandsLine;
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
        String str = "";
        try {
            str = reader.readLine();
        } catch (IOException e) {
            e.printStackTrace();
        }
        currentPrompt = null;

        String[] commands = str.split(" ", 2);
        try {
            switch (commands[0]) {
                case "gcs": {
                    int limit = 20;
                    if (commands.length > 1) {
                        limit = toInt(commands[1]);
                    }
                    getMainChatList(limit);
                    break;
                }
                case "gc":
                    client.send(new TdApi.GetChat(getChatId(commands[1])), defaultHandler);
                    break;
                case "me":
                    client.send(new TdApi.GetMe(), defaultHandler);
                    break;
                case "sm": {
                    String[] args = commands[1].split(" ", 2);
                    sendMessage(getChatId(args[0]), args[1]);
                    break;
                }
                case "lo":
                    haveAuthorization = false;
                    client.send(new TdApi.LogOut(), defaultHandler);
                    break;
                case "ng":
                    createGroup(System.currentTimeMillis(), "测试群组标题", false, "测试群组的描述");
                    break;
                case "qs":
                    String msg = "无账号";
                    if (null == authorizationState) {

                    } else if (TdApi.AuthorizationStateWaitPhoneNumber.CONSTRUCTOR == authorizationState.getConstructor()) {
                        msg = "待输入电话号码";
                    } else if (TdApi.AuthorizationStateWaitCode.CONSTRUCTOR == authorizationState.getConstructor()) {
                        msg = "待输入验证码";
                    } else if (TdApi.AuthorizationStateReady.CONSTRUCTOR == authorizationState.getConstructor()) {
                        msg = "登陆中";
                    }
                    log.info("当前账号状态：" + msg);
                    break;
                default:
                    log.error("Unsupported command: " + str);

            }
        } catch (ArrayIndexOutOfBoundsException e) {
            log.info("Not enough arguments");
        }
    }

    private static void getMainChatList(final int limit) {
        synchronized (mainChatList) {
            if (!haveFullMainChatList && limit > mainChatList.size()) {
                // send GetChats request if there are some unknown chats and have not enough known chats
                client.send(new TdApi.LoadChats(new TdApi.ChatListMain(), limit - mainChatList.size()), new Client.ResultHandler() {
                    @Override
                    public void onResult(TdApi.Object object) {
                        switch (object.getConstructor()) {
                            case TdApi.Error.CONSTRUCTOR:
                                if (((TdApi.Error) object).code == 404) {
                                    synchronized (mainChatList) {
                                        haveFullMainChatList = true;
                                    }
                                } else {
                                    log.info("Receive an error for GetChats:" + newLine + object);
                                }
                                break;
                            case TdApi.Ok.CONSTRUCTOR:
                                // chats had already been received through updates, let's retry request
                                getMainChatList(limit);
                                break;
                            default:
                                log.error("Receive wrong response from TDLib:" + newLine + object);
                        }
                    }
                });
                return;
            }

            java.util.Iterator<OrderedChat> iter = mainChatList.iterator();

            log.info("First " + limit + " chat(s) out of " + mainChatList.size() + " known chat(s):");
            for (int i = 0; i < limit && i < mainChatList.size(); i++) {
                long chatId = iter.next().chatId;
//                TdApi.Chat chat = chats.get(chatId);
//                synchronized (chat) {
//                    log.info(chatId + ": " + chat.title);
//                }
            }
            log.info("");
        }
    }

    private static void sendMessage(long chatId, String message) {
        // initialize reply markup just for testing
        TdApi.InlineKeyboardButton[] row = {new TdApi.InlineKeyboardButton("https://telegram.org?1", new TdApi.InlineKeyboardButtonTypeUrl()), new TdApi.InlineKeyboardButton("https://telegram.org?2", new TdApi.InlineKeyboardButtonTypeUrl()), new TdApi.InlineKeyboardButton("https://telegram.org?3", new TdApi.InlineKeyboardButtonTypeUrl())};
        TdApi.ReplyMarkup replyMarkup = new TdApi.ReplyMarkupInlineKeyboard(new TdApi.InlineKeyboardButton[][]{row, row, row});

        TdApi.InputMessageContent content = new TdApi.InputMessageText(new TdApi.FormattedText(message, null), false, true);
        client.send(new TdApi.SendMessage(chatId, 0, 0, null, replyMarkup, content), defaultHandler);
    }

    public static void main(String[] args) throws InterruptedException {
        System.out.println("main");
        start();
    }

    public static void start() throws InterruptedException {
        log.info("start");
        // disable TDLib log
        Client.execute(new TdApi.SetLogVerbosityLevel(0));
        if (Client.execute(new TdApi.SetLogStream(new TdApi.LogStreamFile("tdlib.log", 1 << 27, false))) instanceof TdApi.Error) {
            throw new IOError(new IOException("Write access to the current directory is required"));
        }

        // create client
        client = Client.create(new UpdateHandler(), null, null);

        // test Client.execute
        defaultHandler.onResult(Client.execute(new TdApi.GetTextEntities("@telegram /test_command https://telegram.org telegram.me @gif @test")));

        // main loop
        int times = 0;
        // main loop
        while (!needQuit) {
            // await authorization
            authorizationLock.lock();
            try {
                while (!haveAuthorization) {
                    gotAuthorization.await();
                }
            } finally {
                authorizationLock.unlock();
            }

            while (haveAuthorization) {
                Thread.sleep(10000);
                log.info("TgService " + times++);
            }
        }
    }

    private static class OrderedChat implements Comparable<OrderedChat> {
        final long chatId;
        final TdApi.ChatPosition position;

        OrderedChat(long chatId, TdApi.ChatPosition position) {
            this.chatId = chatId;
            this.position = position;
        }

        @Override
        public int compareTo(OrderedChat o) {
            if (this.position.order != o.position.order) {
                return o.position.order < this.position.order ? -1 : 1;
            }
            if (this.chatId != o.chatId) {
                return o.chatId < this.chatId ? -1 : 1;
            }
            return 0;
        }

        @Override
        public boolean equals(Object obj) {
            OrderedChat o = (OrderedChat) obj;
            return this.chatId == o.chatId && this.position.order == o.position.order;
        }
    }


    /**
     * 查询群组用户id的业务句柄
     */
    private static class GetMemberHandler implements Client.ResultHandler {

        /*** 操作上下文   ***/
        GetSuperGroupMemberContext context;

        @Override
        public void onResult(TdApi.Object object) {
            switch (object.getConstructor()) {
                case TdApi.ChatMembers.CONSTRUCTOR:
                    TdApi.ChatMembers members = (TdApi.ChatMembers) object;
                    int length = members.members.length;
                    if(0 == length) {
                        this.context.getWhetherFinish().set(true);
                    }else {
                        this.context.getUpdatedMemberCount().getAndAdd(length);
                    }
                    Map<Long, Long> memberMap = new HashMap<>();
                    for (int i = 0; i < length; i++) {
                        TdApi.ChatMember chatMember = members.members[i];
                        if (TdApi.MessageSenderUser.CONSTRUCTOR == chatMember.memberId.getConstructor()) {
                            TdApi.MessageSenderUser user = (TdApi.MessageSenderUser) chatMember.memberId;
                            memberMap.put(user.userId, user.userId);
                        }
                    }
                    this.context.getGroupMember().putAll(memberMap);
                    log.info("被查询用户的聊天id:{},此时更新的用户个数有：{}", context.getSrcGroupId(), this.context.getUpdatedMemberCount().get());
                    break;
                case TdApi.Error.CONSTRUCTOR:
                    TdApi.Error error = (TdApi.Error) object;
                    this.context.getErrorMsg().put(error.message, error.message);
                    log.info("GetMemberHandler,  srcChatId:" + this.context.getSrcGroupId() + "__" + ".id:" + object.getConstructor() + object.toString());
                    break;
                default:
                    context.getErrorMsg().put("", object);
                    log.info("GetMemberHandler,  srcChatId:" + this.context.getSrcGroupId() + "__" + ".id:" + object.getConstructor() + object.toString());
            }
        }

        public GetMemberHandler(GetSuperGroupMemberContext context) {
            this.context = context;
        }
    }

    private static class DefaultHandler implements Client.ResultHandler {
        @Override
        public void onResult(TdApi.Object object) {
            log.info(object.toString());
        }
    }

    private static class AddMemberChatHandler implements Client.ResultHandler {

        AddChatMemberContext context;

        Long userId;

        public AddMemberChatHandler(AddChatMemberContext contextAdd, Long userId) {
            this.context = contextAdd;
            this.userId = userId;
        }

        @Override
        public void onResult(TdApi.Object object) {
            switch (object.getConstructor()) {
                case TdApi.Error.CONSTRUCTOR:
                    TdApi.Error error = (TdApi.Error) object;
                    log.info("userId:{},errorMsg:{}", this.userId, error.message);
                    context.getErrorMsg().put(this.userId, error.message);
                    break;
                case TdApi.Ok.CONSTRUCTOR:
                    context.getSucceed().put(this.userId, this.userId.toString());
                    log.info("invite userId:{},succeed", this.userId);
                    break;
                default:
                    context.getErrorMsg().put(this.userId, "object.getConstructor：" + object.getConstructor());
                    log.info("AddMemberChatHandler handler. id:" + object.getConstructor() + " ;" + object.toString());
            }
        }
    }

    private static class AddMembersChatHandler implements Client.ResultHandler {

        AddContactsContext context;

        List<Long> userIds;

        long chatId;

        public AddMembersChatHandler(AddContactsContext contextAdd, List<Long> userIds, long chatId) {
            this.context = contextAdd;
            this.userIds = userIds;
            this.chatId = chatId;
        }

        @Override
        public void onResult(TdApi.Object object) {
            switch (object.getConstructor()) {
                case TdApi.Error.CONSTRUCTOR:
                    TdApi.Error error = (TdApi.Error) object;
                    userIds.forEach(e->{
                        context.getOperateResult().put(e, error.message);
                    });
                    log.info("userId:{},chatId:{},errorMsg:{}", this.userIds, chatId, error.message);
                    break;
                case TdApi.Ok.CONSTRUCTOR:
                    userIds.forEach(e->{
                        context.getOperateResult().put(e, object.toString());
                    });
                    log.info("invite userId:{},succeed", object.toString());
                    break;
                default:
                    userIds.forEach(e->{
                        context.getOperateResult().put(e, "object.getConstructor：" + object.getConstructor());
                    });
                    log.info("AddMemberChatHandler handler. id:" + object.getConstructor() + " ;" + object.toString());
            }
        }
    }

    private static class GetChatsHandler implements Client.ResultHandler {

        GetChatsContext context;

        public GetChatsHandler(GetChatsContext getContext) {
            this.context = getContext;
        }

        @Override
        public void onResult(TdApi.Object object) {
            switch (object.getConstructor()) {
                case TdApi.Error.CONSTRUCTOR:
                    TdApi.Error error = (TdApi.Error) object;
                    log.info("GetChatsHandler,errorMsg:{}", error.message);
                    break;
                case TdApi.Ok.CONSTRUCTOR:
                    log.info("GetChatsHandler invite ,succeed");
                    break;
                default:
                    context.getChatsMap().put(1L, object);
                    log.info("GetChatsHandler handler. id:" + object.getConstructor());
            }
        }
    }

    private static class AddContactHandler implements Client.ResultHandler {

        AddContactsContext context;

        Long userId;

        String  phoneNumber;

        public AddContactHandler(AddContactsContext getContext, long userId) {
            this.context = getContext;
            this.userId = userId;
            this.phoneNumber = "";
        }

        public AddContactHandler(AddContactsContext getContext, String phoneNumber) {
            this.context = getContext;
            this.phoneNumber = phoneNumber;
            this.userId = 0L;
        }

        @Override
        public void onResult(TdApi.Object object) {
            switch (object.getConstructor()) {
                case TdApi.Error.CONSTRUCTOR:
                    TdApi.Error error = (TdApi.Error) object;
                    context.getOperateResult().put(userId, error.message);
                    log.info("AddContactHandler,userId:{}, phoneNumber:{}, errorMsg:{}", userId, phoneNumber, error.message);
                    break;
                case TdApi.Ok.CONSTRUCTOR:
                    context.getOperateResult().put(userId, object);
                    log.info("AddContactHandler ,userId:{}phoneNumber:{}, ok ", userId, phoneNumber);
                    break;
                default:
                    context.getOperateResult().put(userId, object);
                    log.info("AddContactHandler ,userId:{}phoneNumber:{}, .other:{} ", userId, phoneNumber, object.getConstructor());
            }
        }
    }


    private static class GetChatMemberHandler implements Client.ResultHandler {

        AddContactsContext context;

        long userId;

        long chatId;

        public GetChatMemberHandler(AddContactsContext getContext, long userId, long chatId) {
            this.context = getContext;
            this.userId = userId;
            this.chatId = chatId;
        }

        @Override
        public void onResult(TdApi.Object object) {
            switch (object.getConstructor()) {
                case TdApi.Error.CONSTRUCTOR:
                    TdApi.Error error = (TdApi.Error) object;
                    context.getOperateResult().put(userId, error.message);
                    log.info("GetChatMemberHandler,userId:{}, errorMsg:{}", userId, error.message);
                    break;
                case TdApi.Ok.CONSTRUCTOR:
                    context.getOperateResult().put(userId, object);
                    log.info("GetChatMemberHandler ,userId:{}", userId);
                    break;
                default:
                    context.getOperateResult().put(userId, object);
                    log.info("GetChatMemberHandler handler. id:" + object.getConstructor());
            }
        }
    }

    private static class CreateGroupHandler implements Client.ResultHandler {
        /*** 操作序列号   ***/
        public Long serialID;

        public CreateGroupHandler(Long serialID) {
            this.serialID = serialID;
        }

        @Override
        public void onResult(TdApi.Object object) {
            switch (object.getConstructor()) {
                case TdApi.Error.CONSTRUCTOR:
                    TdApi.Error error = (TdApi.Error) object;
                    createGroupErrorMap.put(this.serialID, error);
                    break;
                case TdApi.Ok.CONSTRUCTOR:
                    TdApi.Ok ok = (TdApi.Ok) object;
                    createGroupResponseMap.put(this.serialID, ok);
                    break;
                default:
                    log.info("create group handler. id:" + object.getConstructor() + " ;" + object.toString());
            }

        }
    }

    private static class UpdateHandler implements Client.ResultHandler {
        @Override
        public void onResult(TdApi.Object object) {
            switch (object.getConstructor()) {
                case TdApi.UpdateAuthorizationState.CONSTRUCTOR:
                    log.info("UpdateHandler call onAuthorizationStateUpdated：{}", ((TdApi.UpdateAuthorizationState) object).authorizationState);
                    onAuthorizationStateUpdated(((TdApi.UpdateAuthorizationState) object).authorizationState);
                    break;

                case TdApi.UpdateUser.CONSTRUCTOR:
                    TdApi.UpdateUser updateUser = (TdApi.UpdateUser) object;
                    users.put(updateUser.user.id, updateUser.user);
                    break;
                case TdApi.UpdateUserStatus.CONSTRUCTOR: {
                    TdApi.UpdateUserStatus updateUserStatus = (TdApi.UpdateUserStatus) object;
                    TdApi.User user = users.get(updateUserStatus.userId);
                    synchronized (user) {
                        user.status = updateUserStatus.status;
                    }
                    break;
                }
                case TdApi.UpdateBasicGroup.CONSTRUCTOR:
                    TdApi.UpdateBasicGroup updateBasicGroup = (TdApi.UpdateBasicGroup) object;
                    basicGroups.put(updateBasicGroup.basicGroup.id, updateBasicGroup.basicGroup);
                    break;
                case TdApi.UpdateSupergroup.CONSTRUCTOR:
                    TdApi.UpdateSupergroup updateSupergroup = (TdApi.UpdateSupergroup) object;
                    supergroups.put(updateSupergroup.supergroup.id, updateSupergroup.supergroup);
                    break;
                case TdApi.UpdateSecretChat.CONSTRUCTOR:
                    TdApi.UpdateSecretChat updateSecretChat = (TdApi.UpdateSecretChat) object;
                    secretChats.put(updateSecretChat.secretChat.id, updateSecretChat.secretChat);
                    break;
                case TdApi.UpdateChatTitle.CONSTRUCTOR: {
                    TdApi.UpdateChatTitle updateChat = (TdApi.UpdateChatTitle) object;
                    updateGroupTitleMap.put(updateChat.chatId, updateChat.title);
                    break;
                }
//                /*** 该方法可以得到群与 标题的 关联关系    ***/
//                case TdApi.UpdateNewChat.CONSTRUCTOR: {
//                    TdApi.UpdateNewChat updateNewChat = (TdApi.UpdateNewChat) object;
//                    log.info("更新群组标题的消息。{}", updateNewChat.toString());
//                    TdApi.Chat chat = updateNewChat.chat;
//                    if (TdApi.ChatTypeSupergroup.CONSTRUCTOR == chat.type.getConstructor()) {
//                        TdApi.ChatTypeSupergroup type = (TdApi.ChatTypeSupergroup) chat.type;
//                        supergroupsChatRelationMap.put(type.supergroupId, new ChatGroupRelationEntity(chat.id, type.supergroupId, chat.title));
//                    }
////                    if (TdApi.ChatTypeBasicGroup.CONSTRUCTOR == chat.type.getConstructor()) {
////                        TdApi.ChatTypeBasicGroup type = (TdApi.ChatTypeBasicGroup) chat.type;
////                        basicGroupsChatRelationMap.put(type.basicGroupId, new ChatGroupRelationEntity(chat.id, type.basicGroupId, chat.title));
////                    }
//                    break;
//                }


                case TdApi.UpdateNewChat.CONSTRUCTOR: {
                    TdApi.UpdateNewChat updateNewChat = (TdApi.UpdateNewChat) object;
                    if ((TdApi.ChatTypeSupergroup.CONSTRUCTOR == updateNewChat.chat.type.getConstructor())) {
                        TdApi.ChatTypeSupergroup supergroup = (TdApi.ChatTypeSupergroup) updateNewChat.chat.type;
                        if (!supergroup.isChannel) {
                            /*** 只关注超级群的聊天 ***/
                            chats.put(updateNewChat.chat.id, updateNewChat.chat);
                        }
                    }
                    break;
                }

                case TdApi.UpdateBasicGroupFullInfo.CONSTRUCTOR:
                    TdApi.UpdateBasicGroupFullInfo updateBasicGroupFullInfo = (TdApi.UpdateBasicGroupFullInfo) object;
                    log.info("updateBasicGroupFullInfo.basicGroupFullInfo.id:{};.size:{}", updateBasicGroupFullInfo.basicGroupId, updateBasicGroupFullInfo.basicGroupFullInfo.members.length);
                    basicGroupsFullInfo.put(updateBasicGroupFullInfo.basicGroupId, updateBasicGroupFullInfo.basicGroupFullInfo);
                    break;

                case TdApi.UpdateChatDefaultDisableNotification.CONSTRUCTOR: {
                    TdApi.UpdateChatDefaultDisableNotification update = (TdApi.UpdateChatDefaultDisableNotification) object;
//                    TdApi.Chat chat = chats.get(update.chatId);
//                    synchronized (chat) {
//                        chat.defaultDisableNotification = update.defaultDisableNotification;
//                    }
                    break;
                }
                case TdApi.UpdateChatIsMarkedAsUnread.CONSTRUCTOR: {
                    TdApi.UpdateChatIsMarkedAsUnread update = (TdApi.UpdateChatIsMarkedAsUnread) object;
//                    TdApi.Chat chat = chats.get(update.chatId);
//                    synchronized (chat) {
//                        chat.isMarkedAsUnread = update.isMarkedAsUnread;
//                    }
                    break;
                }
                case TdApi.UpdateUserFullInfo.CONSTRUCTOR:
                    TdApi.UpdateUserFullInfo updateUserFullInfo = (TdApi.UpdateUserFullInfo) object;
                    usersFullInfo.put(updateUserFullInfo.userId, updateUserFullInfo.userFullInfo);
                    break;
                case TdApi.UpdateSupergroupFullInfo.CONSTRUCTOR:
                    TdApi.UpdateSupergroupFullInfo updateSupergroupFullInfo = (TdApi.UpdateSupergroupFullInfo) object;
                    supergroupsFullInfo.put(updateSupergroupFullInfo.supergroupId, updateSupergroupFullInfo.supergroupFullInfo);
                    break;
                default:
                    // print("Unsupported update:" + newLine + object);
            }
        }
    }

    private static class AuthorizationRequestHandler implements Client.ResultHandler {
        @Override
        public void onResult(TdApi.Object object) {
            switch (object.getConstructor()) {
                case TdApi.Error.CONSTRUCTOR:

                    Throwable ex = new Throwable();
                    StackTraceElement[] stackElements = ex.getStackTrace();
                    StringBuffer sb = new StringBuffer();

                    if (stackElements != null) {
                        for (int i = 0; i < stackElements.length; i++) {
                            sb.append(newLine);
                            sb.append(stackElements[i].getClassName() + "    ");
                            sb.append(stackElements[i].getFileName() + "    ");
                            sb.append(stackElements[i].getLineNumber() + "    ");
                            sb.append(stackElements[i].getMethodName());
                            sb.append("-----------------------------------");
                        }
                    }
                    log.info("AuthorizationRequestHandler Error stack:{}", sb.toString());
                    log.info("AuthorizationRequestHandler Receive an error:" + newLine + object);
                    onAuthorizationStateUpdated(null); // repeat last act
                    // ion
                    break;
                case TdApi.Ok.CONSTRUCTOR:
                    // result is already received through UpdateAuthorizationState, nothing to do
                    break;
                default:
                    log.error("Receive wrong response from TDLib:" + newLine + object);
            }
        }
    }
}